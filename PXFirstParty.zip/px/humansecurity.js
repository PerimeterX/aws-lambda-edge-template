var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/ipaddr.js/lib/ipaddr.js
var require_ipaddr = __commonJS({
  "node_modules/ipaddr.js/lib/ipaddr.js"(exports2, module2) {
    (function() {
      var expandIPv6, ipaddr, ipv4Part, ipv4Regexes, ipv6Part, ipv6Regexes, matchCIDR, root, zoneIndex;
      ipaddr = {};
      root = this;
      if (typeof module2 !== "undefined" && module2 !== null && module2.exports) {
        module2.exports = ipaddr;
      } else {
        root["ipaddr"] = ipaddr;
      }
      matchCIDR = function(first, second, partSize, cidrBits) {
        var part, shift;
        if (first.length !== second.length) {
          throw new Error("ipaddr: cannot match CIDR for objects with different lengths");
        }
        part = 0;
        while (cidrBits > 0) {
          shift = partSize - cidrBits;
          if (shift < 0) {
            shift = 0;
          }
          if (first[part] >> shift !== second[part] >> shift) {
            return false;
          }
          cidrBits -= partSize;
          part += 1;
        }
        return true;
      };
      ipaddr.subnetMatch = function(address, rangeList, defaultName) {
        var k, len, rangeName, rangeSubnets, subnet;
        if (defaultName == null) {
          defaultName = "unicast";
        }
        for (rangeName in rangeList) {
          rangeSubnets = rangeList[rangeName];
          if (rangeSubnets[0] && !(rangeSubnets[0] instanceof Array)) {
            rangeSubnets = [rangeSubnets];
          }
          for (k = 0, len = rangeSubnets.length; k < len; k++) {
            subnet = rangeSubnets[k];
            if (address.kind() === subnet[0].kind()) {
              if (address.match.apply(address, subnet)) {
                return rangeName;
              }
            }
          }
        }
        return defaultName;
      };
      ipaddr.IPv4 = function() {
        function IPv4(octets) {
          var k, len, octet;
          if (octets.length !== 4) {
            throw new Error("ipaddr: ipv4 octet count should be 4");
          }
          for (k = 0, len = octets.length; k < len; k++) {
            octet = octets[k];
            if (!(0 <= octet && octet <= 255)) {
              throw new Error("ipaddr: ipv4 octet should fit in 8 bits");
            }
          }
          this.octets = octets;
        }
        IPv4.prototype.kind = function() {
          return "ipv4";
        };
        IPv4.prototype.toString = function() {
          return this.octets.join(".");
        };
        IPv4.prototype.toNormalizedString = function() {
          return this.toString();
        };
        IPv4.prototype.toByteArray = function() {
          return this.octets.slice(0);
        };
        IPv4.prototype.match = function(other, cidrRange) {
          var ref;
          if (cidrRange === void 0) {
            ref = other, other = ref[0], cidrRange = ref[1];
          }
          if (other.kind() !== "ipv4") {
            throw new Error("ipaddr: cannot match ipv4 address with non-ipv4 one");
          }
          return matchCIDR(this.octets, other.octets, 8, cidrRange);
        };
        IPv4.prototype.SpecialRanges = {
          unspecified: [[new IPv4([0, 0, 0, 0]), 8]],
          broadcast: [[new IPv4([255, 255, 255, 255]), 32]],
          multicast: [[new IPv4([224, 0, 0, 0]), 4]],
          linkLocal: [[new IPv4([169, 254, 0, 0]), 16]],
          loopback: [[new IPv4([127, 0, 0, 0]), 8]],
          carrierGradeNat: [[new IPv4([100, 64, 0, 0]), 10]],
          "private": [[new IPv4([10, 0, 0, 0]), 8], [new IPv4([172, 16, 0, 0]), 12], [new IPv4([192, 168, 0, 0]), 16]],
          reserved: [[new IPv4([192, 0, 0, 0]), 24], [new IPv4([192, 0, 2, 0]), 24], [new IPv4([192, 88, 99, 0]), 24], [new IPv4([198, 51, 100, 0]), 24], [new IPv4([203, 0, 113, 0]), 24], [new IPv4([240, 0, 0, 0]), 4]]
        };
        IPv4.prototype.range = function() {
          return ipaddr.subnetMatch(this, this.SpecialRanges);
        };
        IPv4.prototype.toIPv4MappedAddress = function() {
          return ipaddr.IPv6.parse("::ffff:" + this.toString());
        };
        IPv4.prototype.prefixLengthFromSubnetMask = function() {
          var cidr, i, k, octet, stop, zeros, zerotable;
          zerotable = {
            0: 8,
            128: 7,
            192: 6,
            224: 5,
            240: 4,
            248: 3,
            252: 2,
            254: 1,
            255: 0
          };
          cidr = 0;
          stop = false;
          for (i = k = 3; k >= 0; i = k += -1) {
            octet = this.octets[i];
            if (octet in zerotable) {
              zeros = zerotable[octet];
              if (stop && zeros !== 0) {
                return null;
              }
              if (zeros !== 8) {
                stop = true;
              }
              cidr += zeros;
            } else {
              return null;
            }
          }
          return 32 - cidr;
        };
        return IPv4;
      }();
      ipv4Part = "(0?\\d+|0x[a-f0-9]+)";
      ipv4Regexes = {
        fourOctet: new RegExp("^" + ipv4Part + "\\." + ipv4Part + "\\." + ipv4Part + "\\." + ipv4Part + "$", "i"),
        longValue: new RegExp("^" + ipv4Part + "$", "i")
      };
      ipaddr.IPv4.parser = function(string) {
        var match, parseIntAuto, part, shift, value;
        parseIntAuto = function(string2) {
          if (string2[0] === "0" && string2[1] !== "x") {
            return parseInt(string2, 8);
          } else {
            return parseInt(string2);
          }
        };
        if (match = string.match(ipv4Regexes.fourOctet)) {
          return function() {
            var k, len, ref, results;
            ref = match.slice(1, 6);
            results = [];
            for (k = 0, len = ref.length; k < len; k++) {
              part = ref[k];
              results.push(parseIntAuto(part));
            }
            return results;
          }();
        } else if (match = string.match(ipv4Regexes.longValue)) {
          value = parseIntAuto(match[1]);
          if (value > 4294967295 || value < 0) {
            throw new Error("ipaddr: address outside defined range");
          }
          return function() {
            var k, results;
            results = [];
            for (shift = k = 0; k <= 24; shift = k += 8) {
              results.push(value >> shift & 255);
            }
            return results;
          }().reverse();
        } else {
          return null;
        }
      };
      ipaddr.IPv6 = function() {
        function IPv6(parts, zoneId) {
          var i, k, l, len, part, ref;
          if (parts.length === 16) {
            this.parts = [];
            for (i = k = 0; k <= 14; i = k += 2) {
              this.parts.push(parts[i] << 8 | parts[i + 1]);
            }
          } else if (parts.length === 8) {
            this.parts = parts;
          } else {
            throw new Error("ipaddr: ipv6 part count should be 8 or 16");
          }
          ref = this.parts;
          for (l = 0, len = ref.length; l < len; l++) {
            part = ref[l];
            if (!(0 <= part && part <= 65535)) {
              throw new Error("ipaddr: ipv6 part should fit in 16 bits");
            }
          }
          if (zoneId) {
            this.zoneId = zoneId;
          }
        }
        IPv6.prototype.kind = function() {
          return "ipv6";
        };
        IPv6.prototype.toString = function() {
          return this.toNormalizedString().replace(/((^|:)(0(:|$))+)/, "::");
        };
        IPv6.prototype.toRFC5952String = function() {
          var bestMatchIndex, bestMatchLength, match, regex, string;
          regex = /((^|:)(0(:|$)){2,})/g;
          string = this.toNormalizedString();
          bestMatchIndex = 0;
          bestMatchLength = -1;
          while (match = regex.exec(string)) {
            if (match[0].length > bestMatchLength) {
              bestMatchIndex = match.index;
              bestMatchLength = match[0].length;
            }
          }
          if (bestMatchLength < 0) {
            return string;
          }
          return string.substring(0, bestMatchIndex) + "::" + string.substring(bestMatchIndex + bestMatchLength);
        };
        IPv6.prototype.toByteArray = function() {
          var bytes, k, len, part, ref;
          bytes = [];
          ref = this.parts;
          for (k = 0, len = ref.length; k < len; k++) {
            part = ref[k];
            bytes.push(part >> 8);
            bytes.push(part & 255);
          }
          return bytes;
        };
        IPv6.prototype.toNormalizedString = function() {
          var addr, part, suffix;
          addr = function() {
            var k, len, ref, results;
            ref = this.parts;
            results = [];
            for (k = 0, len = ref.length; k < len; k++) {
              part = ref[k];
              results.push(part.toString(16));
            }
            return results;
          }.call(this).join(":");
          suffix = "";
          if (this.zoneId) {
            suffix = "%" + this.zoneId;
          }
          return addr + suffix;
        };
        IPv6.prototype.toFixedLengthString = function() {
          var addr, part, suffix;
          addr = function() {
            var k, len, ref, results;
            ref = this.parts;
            results = [];
            for (k = 0, len = ref.length; k < len; k++) {
              part = ref[k];
              results.push(part.toString(16).padStart(4, "0"));
            }
            return results;
          }.call(this).join(":");
          suffix = "";
          if (this.zoneId) {
            suffix = "%" + this.zoneId;
          }
          return addr + suffix;
        };
        IPv6.prototype.match = function(other, cidrRange) {
          var ref;
          if (cidrRange === void 0) {
            ref = other, other = ref[0], cidrRange = ref[1];
          }
          if (other.kind() !== "ipv6") {
            throw new Error("ipaddr: cannot match ipv6 address with non-ipv6 one");
          }
          return matchCIDR(this.parts, other.parts, 16, cidrRange);
        };
        IPv6.prototype.SpecialRanges = {
          unspecified: [new IPv6([0, 0, 0, 0, 0, 0, 0, 0]), 128],
          linkLocal: [new IPv6([65152, 0, 0, 0, 0, 0, 0, 0]), 10],
          multicast: [new IPv6([65280, 0, 0, 0, 0, 0, 0, 0]), 8],
          loopback: [new IPv6([0, 0, 0, 0, 0, 0, 0, 1]), 128],
          uniqueLocal: [new IPv6([64512, 0, 0, 0, 0, 0, 0, 0]), 7],
          ipv4Mapped: [new IPv6([0, 0, 0, 0, 0, 65535, 0, 0]), 96],
          rfc6145: [new IPv6([0, 0, 0, 0, 65535, 0, 0, 0]), 96],
          rfc6052: [new IPv6([100, 65435, 0, 0, 0, 0, 0, 0]), 96],
          "6to4": [new IPv6([8194, 0, 0, 0, 0, 0, 0, 0]), 16],
          teredo: [new IPv6([8193, 0, 0, 0, 0, 0, 0, 0]), 32],
          reserved: [[new IPv6([8193, 3512, 0, 0, 0, 0, 0, 0]), 32]]
        };
        IPv6.prototype.range = function() {
          return ipaddr.subnetMatch(this, this.SpecialRanges);
        };
        IPv6.prototype.isIPv4MappedAddress = function() {
          return this.range() === "ipv4Mapped";
        };
        IPv6.prototype.toIPv4Address = function() {
          var high, low, ref;
          if (!this.isIPv4MappedAddress()) {
            throw new Error("ipaddr: trying to convert a generic ipv6 address to ipv4");
          }
          ref = this.parts.slice(-2), high = ref[0], low = ref[1];
          return new ipaddr.IPv4([high >> 8, high & 255, low >> 8, low & 255]);
        };
        IPv6.prototype.prefixLengthFromSubnetMask = function() {
          var cidr, i, k, part, stop, zeros, zerotable;
          zerotable = {
            0: 16,
            32768: 15,
            49152: 14,
            57344: 13,
            61440: 12,
            63488: 11,
            64512: 10,
            65024: 9,
            65280: 8,
            65408: 7,
            65472: 6,
            65504: 5,
            65520: 4,
            65528: 3,
            65532: 2,
            65534: 1,
            65535: 0
          };
          cidr = 0;
          stop = false;
          for (i = k = 7; k >= 0; i = k += -1) {
            part = this.parts[i];
            if (part in zerotable) {
              zeros = zerotable[part];
              if (stop && zeros !== 0) {
                return null;
              }
              if (zeros !== 16) {
                stop = true;
              }
              cidr += zeros;
            } else {
              return null;
            }
          }
          return 128 - cidr;
        };
        return IPv6;
      }();
      ipv6Part = "(?:[0-9a-f]+::?)+";
      zoneIndex = "%[0-9a-z]{1,}";
      ipv6Regexes = {
        zoneIndex: new RegExp(zoneIndex, "i"),
        "native": new RegExp("^(::)?(" + ipv6Part + ")?([0-9a-f]+)?(::)?(" + zoneIndex + ")?$", "i"),
        transitional: new RegExp("^((?:" + ipv6Part + ")|(?:::)(?:" + ipv6Part + ")?)" + (ipv4Part + "\\." + ipv4Part + "\\." + ipv4Part + "\\." + ipv4Part) + ("(" + zoneIndex + ")?$"), "i")
      };
      expandIPv6 = function(string, parts) {
        var colonCount, lastColon, part, replacement, replacementCount, zoneId;
        if (string.indexOf("::") !== string.lastIndexOf("::")) {
          return null;
        }
        zoneId = (string.match(ipv6Regexes["zoneIndex"]) || [])[0];
        if (zoneId) {
          zoneId = zoneId.substring(1);
          string = string.replace(/%.+$/, "");
        }
        colonCount = 0;
        lastColon = -1;
        while ((lastColon = string.indexOf(":", lastColon + 1)) >= 0) {
          colonCount++;
        }
        if (string.substr(0, 2) === "::") {
          colonCount--;
        }
        if (string.substr(-2, 2) === "::") {
          colonCount--;
        }
        if (colonCount > parts) {
          return null;
        }
        replacementCount = parts - colonCount;
        replacement = ":";
        while (replacementCount--) {
          replacement += "0:";
        }
        string = string.replace("::", replacement);
        if (string[0] === ":") {
          string = string.slice(1);
        }
        if (string[string.length - 1] === ":") {
          string = string.slice(0, -1);
        }
        parts = function() {
          var k, len, ref, results;
          ref = string.split(":");
          results = [];
          for (k = 0, len = ref.length; k < len; k++) {
            part = ref[k];
            results.push(parseInt(part, 16));
          }
          return results;
        }();
        return {
          parts,
          zoneId
        };
      };
      ipaddr.IPv6.parser = function(string) {
        var addr, k, len, match, octet, octets, zoneId;
        if (ipv6Regexes["native"].test(string)) {
          return expandIPv6(string, 8);
        } else if (match = string.match(ipv6Regexes["transitional"])) {
          zoneId = match[6] || "";
          addr = expandIPv6(match[1].slice(0, -1) + zoneId, 6);
          if (addr.parts) {
            octets = [parseInt(match[2]), parseInt(match[3]), parseInt(match[4]), parseInt(match[5])];
            for (k = 0, len = octets.length; k < len; k++) {
              octet = octets[k];
              if (!(0 <= octet && octet <= 255)) {
                return null;
              }
            }
            addr.parts.push(octets[0] << 8 | octets[1]);
            addr.parts.push(octets[2] << 8 | octets[3]);
            return {
              parts: addr.parts,
              zoneId: addr.zoneId
            };
          }
        }
        return null;
      };
      ipaddr.IPv4.isIPv4 = ipaddr.IPv6.isIPv6 = function(string) {
        return this.parser(string) !== null;
      };
      ipaddr.IPv4.isValid = function(string) {
        var e;
        try {
          new this(this.parser(string));
          return true;
        } catch (error1) {
          e = error1;
          return false;
        }
      };
      ipaddr.IPv4.isValidFourPartDecimal = function(string) {
        if (ipaddr.IPv4.isValid(string) && string.match(/^(0|[1-9]\d*)(\.(0|[1-9]\d*)){3}$/)) {
          return true;
        } else {
          return false;
        }
      };
      ipaddr.IPv6.isValid = function(string) {
        var addr, e;
        if (typeof string === "string" && string.indexOf(":") === -1) {
          return false;
        }
        try {
          addr = this.parser(string);
          new this(addr.parts, addr.zoneId);
          return true;
        } catch (error1) {
          e = error1;
          return false;
        }
      };
      ipaddr.IPv4.parse = function(string) {
        var parts;
        parts = this.parser(string);
        if (parts === null) {
          throw new Error("ipaddr: string is not formatted like ip address");
        }
        return new this(parts);
      };
      ipaddr.IPv6.parse = function(string) {
        var addr;
        addr = this.parser(string);
        if (addr.parts === null) {
          throw new Error("ipaddr: string is not formatted like ip address");
        }
        return new this(addr.parts, addr.zoneId);
      };
      ipaddr.IPv4.parseCIDR = function(string) {
        var maskLength, match, parsed;
        if (match = string.match(/^(.+)\/(\d+)$/)) {
          maskLength = parseInt(match[2]);
          if (maskLength >= 0 && maskLength <= 32) {
            parsed = [this.parse(match[1]), maskLength];
            Object.defineProperty(parsed, "toString", {
              value: function() {
                return this.join("/");
              }
            });
            return parsed;
          }
        }
        throw new Error("ipaddr: string is not formatted like an IPv4 CIDR range");
      };
      ipaddr.IPv4.subnetMaskFromPrefixLength = function(prefix) {
        var filledOctetCount, j, octets;
        prefix = parseInt(prefix);
        if (prefix < 0 || prefix > 32) {
          throw new Error("ipaddr: invalid IPv4 prefix length");
        }
        octets = [0, 0, 0, 0];
        j = 0;
        filledOctetCount = Math.floor(prefix / 8);
        while (j < filledOctetCount) {
          octets[j] = 255;
          j++;
        }
        if (filledOctetCount < 4) {
          octets[filledOctetCount] = Math.pow(2, prefix % 8) - 1 << 8 - prefix % 8;
        }
        return new this(octets);
      };
      ipaddr.IPv4.broadcastAddressFromCIDR = function(string) {
        var cidr, error, i, ipInterfaceOctets, octets, subnetMaskOctets;
        try {
          cidr = this.parseCIDR(string);
          ipInterfaceOctets = cidr[0].toByteArray();
          subnetMaskOctets = this.subnetMaskFromPrefixLength(cidr[1]).toByteArray();
          octets = [];
          i = 0;
          while (i < 4) {
            octets.push(parseInt(ipInterfaceOctets[i], 10) | parseInt(subnetMaskOctets[i], 10) ^ 255);
            i++;
          }
          return new this(octets);
        } catch (error1) {
          error = error1;
          throw new Error("ipaddr: the address does not have IPv4 CIDR format");
        }
      };
      ipaddr.IPv4.networkAddressFromCIDR = function(string) {
        var cidr, error, i, ipInterfaceOctets, octets, subnetMaskOctets;
        try {
          cidr = this.parseCIDR(string);
          ipInterfaceOctets = cidr[0].toByteArray();
          subnetMaskOctets = this.subnetMaskFromPrefixLength(cidr[1]).toByteArray();
          octets = [];
          i = 0;
          while (i < 4) {
            octets.push(parseInt(ipInterfaceOctets[i], 10) & parseInt(subnetMaskOctets[i], 10));
            i++;
          }
          return new this(octets);
        } catch (error1) {
          error = error1;
          throw new Error("ipaddr: the address does not have IPv4 CIDR format");
        }
      };
      ipaddr.IPv6.parseCIDR = function(string) {
        var maskLength, match, parsed;
        if (match = string.match(/^(.+)\/(\d+)$/)) {
          maskLength = parseInt(match[2]);
          if (maskLength >= 0 && maskLength <= 128) {
            parsed = [this.parse(match[1]), maskLength];
            Object.defineProperty(parsed, "toString", {
              value: function() {
                return this.join("/");
              }
            });
            return parsed;
          }
        }
        throw new Error("ipaddr: string is not formatted like an IPv6 CIDR range");
      };
      ipaddr.isValid = function(string) {
        return ipaddr.IPv6.isValid(string) || ipaddr.IPv4.isValid(string);
      };
      ipaddr.parse = function(string) {
        if (ipaddr.IPv6.isValid(string)) {
          return ipaddr.IPv6.parse(string);
        } else if (ipaddr.IPv4.isValid(string)) {
          return ipaddr.IPv4.parse(string);
        } else {
          throw new Error("ipaddr: the address has neither IPv6 nor IPv4 format");
        }
      };
      ipaddr.parseCIDR = function(string) {
        var e;
        try {
          return ipaddr.IPv6.parseCIDR(string);
        } catch (error1) {
          e = error1;
          try {
            return ipaddr.IPv4.parseCIDR(string);
          } catch (error12) {
            e = error12;
            throw new Error("ipaddr: the address has neither IPv6 nor IPv4 CIDR format");
          }
        }
      };
      ipaddr.fromByteArray = function(bytes) {
        var length;
        length = bytes.length;
        if (length === 4) {
          return new ipaddr.IPv4(bytes);
        } else if (length === 16) {
          return new ipaddr.IPv6(bytes);
        } else {
          throw new Error("ipaddr: the binary input is neither an IPv6 nor IPv4 address");
        }
      };
      ipaddr.process = function(string) {
        var addr;
        addr = this.parse(string);
        if (addr.kind() === "ipv6" && addr.isIPv4MappedAddress()) {
          return addr.toIPv4Address();
        } else {
          return addr;
        }
      };
    }).call(exports2);
  }
});

// node_modules/ip-range-check/index.js
var require_ip_range_check = __commonJS({
  "node_modules/ip-range-check/index.js"(exports2, module2) {
    var ipaddr = require_ipaddr();
    module2.exports = check_many_cidrs;
    function check_many_cidrs(addr, range) {
      if (typeof range === "string") {
        return check_single_cidr(addr, range);
      } else if (typeof range === "object") {
        var ip_is_in_range = false;
        for (var i = 0; i < range.length; i++) {
          if (check_single_cidr(addr, range[i])) {
            ip_is_in_range = true;
            break;
          }
        }
        return ip_is_in_range;
      }
    }
    function check_single_cidr(addr, cidr) {
      try {
        var parsed_addr = ipaddr.process(addr);
        if (cidr.indexOf("/") === -1) {
          var parsed_cidr_as_ip = ipaddr.process(cidr);
          if (parsed_addr.kind() === "ipv6" && parsed_cidr_as_ip.kind() === "ipv6") {
            return parsed_addr.toNormalizedString() === parsed_cidr_as_ip.toNormalizedString();
          }
          return parsed_addr.toString() == parsed_cidr_as_ip.toString();
        } else {
          var parsed_range = ipaddr.parseCIDR(cidr);
          return parsed_addr.match(parsed_range);
        }
      } catch (e) {
        return false;
      }
    }
  }
});

// node_modules/centra/model/CentraResponse.js
var require_CentraResponse = __commonJS({
  "node_modules/centra/model/CentraResponse.js"(exports2, module2) {
    module2.exports = class CentraResponse {
      constructor(res, resOptions) {
        this.coreRes = res;
        this.resOptions = resOptions;
        this.body = Buffer.alloc(0);
        this.headers = res.headers;
        this.statusCode = res.statusCode;
      }
      _addChunk(chunk) {
        this.body = Buffer.concat([this.body, chunk]);
      }
      async json() {
        return this.statusCode === 204 ? null : JSON.parse(this.body);
      }
      async text() {
        return this.body.toString();
      }
    };
  }
});

// node_modules/centra/model/CentraRequest.js
var require_CentraRequest = __commonJS({
  "node_modules/centra/model/CentraRequest.js"(exports2, module2) {
    var path = require("path");
    var http = require("http");
    var https = require("https");
    var qs = require("querystring");
    var zlib = require("zlib");
    var { URL: URL2 } = require("url");
    var CentraResponse = require_CentraResponse();
    var supportedCompressions = ["gzip", "deflate", "br"];
    module2.exports = class CentraRequest {
      constructor(url, method = "GET") {
        this.url = typeof url === "string" ? new URL2(url) : url;
        this.method = method;
        this.data = null;
        this.sendDataAs = null;
        this.reqHeaders = {};
        this.streamEnabled = false;
        this.compressionEnabled = false;
        this.timeoutTime = null;
        this.coreOptions = {};
        this.resOptions = {
          "maxBuffer": 50 * 1e6
          // 50 MB
        };
        return this;
      }
      query(a1, a2) {
        if (typeof a1 === "object") {
          Object.keys(a1).forEach((queryKey) => {
            this.url.searchParams.append(queryKey, a1[queryKey]);
          });
        } else
          this.url.searchParams.append(a1, a2);
        return this;
      }
      path(relativePath) {
        this.url.pathname = path.join(this.url.pathname, relativePath);
        return this;
      }
      body(data, sendAs) {
        this.sendDataAs = typeof data === "object" && !sendAs && !Buffer.isBuffer(data) ? "json" : sendAs ? sendAs.toLowerCase() : "buffer";
        this.data = this.sendDataAs === "form" ? qs.stringify(data) : this.sendDataAs === "json" ? JSON.stringify(data) : data;
        return this;
      }
      header(a1, a2) {
        if (typeof a1 === "object") {
          Object.keys(a1).forEach((headerName) => {
            this.reqHeaders[headerName.toLowerCase()] = a1[headerName];
          });
        } else
          this.reqHeaders[a1.toLowerCase()] = a2;
        return this;
      }
      timeout(timeout) {
        this.timeoutTime = timeout;
        return this;
      }
      option(name, value) {
        this.coreOptions[name] = value;
        return this;
      }
      stream() {
        this.streamEnabled = true;
        return this;
      }
      compress() {
        this.compressionEnabled = true;
        if (!this.reqHeaders["accept-encoding"])
          this.reqHeaders["accept-encoding"] = supportedCompressions.join(", ");
        return this;
      }
      send() {
        return new Promise((resolve, reject) => {
          if (this.data) {
            if (!this.reqHeaders.hasOwnProperty("content-type")) {
              if (this.sendDataAs === "json") {
                this.reqHeaders["content-type"] = "application/json";
              } else if (this.sendDataAs === "form") {
                this.reqHeaders["content-type"] = "application/x-www-form-urlencoded";
              }
            }
            if (!this.reqHeaders.hasOwnProperty("content-length")) {
              this.reqHeaders["content-length"] = Buffer.byteLength(this.data);
            }
          }
          const options = Object.assign({
            "protocol": this.url.protocol,
            "host": this.url.hostname.replace("[", "").replace("]", ""),
            "port": this.url.port,
            "path": this.url.pathname + (this.url.search === null ? "" : this.url.search),
            "method": this.method,
            "headers": this.reqHeaders
          }, this.coreOptions);
          let req;
          const resHandler = (res) => {
            let stream = res;
            if (this.compressionEnabled) {
              if (res.headers["content-encoding"] === "gzip") {
                stream = res.pipe(zlib.createGunzip());
              } else if (res.headers["content-encoding"] === "deflate") {
                stream = res.pipe(zlib.createInflate());
              } else if (res.headers["content-encoding"] === "br") {
                stream = res.pipe(zlib.createBrotliDecompress());
              }
            }
            let centraRes;
            if (this.streamEnabled) {
              resolve(stream);
            } else {
              centraRes = new CentraResponse(res, this.resOptions);
              stream.on("error", (err) => {
                reject(err);
              });
              stream.on("aborted", () => {
                reject(new Error("Server aborted request"));
              });
              stream.on("data", (chunk) => {
                centraRes._addChunk(chunk);
                if (this.resOptions.maxBuffer !== null && centraRes.body.length > this.resOptions.maxBuffer) {
                  stream.destroy();
                  reject("Received a response which was longer than acceptable when buffering. (" + this.body.length + " bytes)");
                }
              });
              stream.on("end", () => {
                resolve(centraRes);
              });
            }
          };
          if (this.url.protocol === "http:") {
            req = http.request(options, resHandler);
          } else if (this.url.protocol === "https:") {
            req = https.request(options, resHandler);
          } else
            throw new Error("Bad URL protocol: " + this.url.protocol);
          if (this.timeoutTime) {
            req.setTimeout(this.timeoutTime, () => {
              req.abort();
              if (!this.streamEnabled) {
                reject(new Error("Timeout reached"));
              }
            });
          }
          req.on("error", (err) => {
            reject(err);
          });
          if (this.data)
            req.write(this.data);
          req.end();
        });
      }
    };
  }
});

// node_modules/centra/createRequest.js
var require_createRequest = __commonJS({
  "node_modules/centra/createRequest.js"(exports2, module2) {
    var CentraRequest = require_CentraRequest();
    module2.exports = (url, method) => {
      return new CentraRequest(url, method);
    };
  }
});

// node_modules/phin/lib/phin.js
var require_phin = __commonJS({
  "node_modules/phin/lib/phin.js"(exports2, module2) {
    var { URL: URL2 } = require("url");
    var centra = require_createRequest();
    var phin2 = async (opts) => {
      if (typeof opts !== "string") {
        if (!opts.hasOwnProperty("url")) {
          throw new Error("Missing url option from options for request method.");
        }
      }
      const req = centra(typeof opts === "object" ? opts.url : opts, opts.method || "GET");
      if (opts.headers)
        req.header(opts.headers);
      if (opts.stream)
        req.stream();
      if (opts.timeout)
        req.timeout(opts.timeout);
      if (opts.data)
        req.body(opts.data);
      if (opts.form)
        req.body(opts.form, "form");
      if (opts.compression)
        req.compress();
      if (typeof opts.core === "object") {
        Object.keys(opts.core).forEach((optName) => {
          req.option(optName, opts.core[optName]);
        });
      }
      const res = await req.send();
      if (res.headers.hasOwnProperty("location") && opts.followRedirects) {
        opts.url = new URL2(res.headers["location"], opts.url).toString();
        return await phin2(opts);
      }
      if (opts.stream) {
        res.stream = res;
        return res;
      } else {
        res.coreRes.body = res.body;
        if (opts.parse) {
          if (opts.parse === "json") {
            res.coreRes.body = await res.json();
            return res.coreRes;
          } else if (opts.parse === "string") {
            res.coreRes.body = res.coreRes.body.toString();
            return res.coreRes;
          }
        }
        return res.coreRes;
      }
    };
    phin2.promisified = phin2;
    phin2.unpromisified = (opts, cb) => {
      phin2(opts).then((data) => {
        if (cb)
          cb(null, data);
      }).catch((err) => {
        if (cb)
          cb(err, null);
      });
    };
    phin2.defaults = (defaultOpts) => async (opts) => {
      const nops = typeof opts === "string" ? { "url": opts } : opts;
      Object.keys(defaultOpts).forEach((doK) => {
        if (!nops.hasOwnProperty(doK) || nops[doK] === null) {
          nops[doK] = defaultOpts[doK];
        }
      });
      return await phin2(nops);
    };
    module2.exports = phin2;
  }
});

// src/px/humansecurity.ts
var humansecurity_exports = {};
__export(humansecurity_exports, {
  HumanSecurityEnforcer: () => Enforcer,
  HumanSecurityPostEnforcer: () => PostEnforcer,
  createHumanActivitiesHandler: () => createHumanActivitiesHandler,
  createHumanEnforceHandler: () => createHumanEnforceHandler,
  createHumanFirstPartyHandler: () => createHumanFirstPartyHandler
});
module.exports = __toCommonJS(humansecurity_exports);

// node_modules/perimeterx-js-core/lib/esm/additional_activity_handler/AdditionalActivityHandlerUtils.js
var AdditionalActivityHandlerUtils;
(function(AdditionalActivityHandlerUtils2) {
  AdditionalActivityHandlerUtils2.invokeAdditionalActivityHandler = async (config, context) => {
    if (config.additionalActivityHandler && typeof config.additionalActivityHandler === "function") {
      try {
        context.logger.debug("calling additional activity handler");
        await config.additionalActivityHandler(config.toParams(), context, context.requestData.request.getUnderlyingRequest());
      } catch (e) {
        context.logger.error(`caught additional activity handler error - ${e}`);
      }
    }
  };
})(AdditionalActivityHandlerUtils || (AdditionalActivityHandlerUtils = {}));

// node_modules/perimeterx-js-core/lib/esm/action/Action.js
var Action;
(function(Action2) {
  Action2["PASS_REQUEST"] = "pass_request";
  Action2["TRIGGER_RISK_API"] = "trigger_risk_api";
  Action2["SIMULATED_BLOCK"] = "simulated_block";
  Action2["BLOCK"] = "block";
})(Action || (Action = {}));

// node_modules/perimeterx-js-core/lib/esm/action/ActionPriorityOrder.js
var ACTION_PRIORITY_ORDER = [
  Action.BLOCK,
  Action.SIMULATED_BLOCK,
  Action.TRIGGER_RISK_API,
  Action.PASS_REQUEST
];

// node_modules/perimeterx-js-core/lib/esm/products/utils/ProductName.js
var ProductName;
(function(ProductName2) {
  ProductName2["BOT_DEFENDER"] = "bd";
  ProductName2["ACCOUNT_DEFENDER"] = "ad";
  ProductName2["CODE_DEFENDER"] = "cd";
  ProductName2["CREDENTIAL_INTELLIGENCE"] = "ci";
  ProductName2["HYPE_SALE_CHALLENGE"] = "hsc";
})(ProductName || (ProductName = {}));

// node_modules/perimeterx-js-core/lib/esm/products/utils/ProductPriorityOrder.js
var PRODUCT_PRIORITY_ORDER = [
  ProductName.HYPE_SALE_CHALLENGE,
  ProductName.BOT_DEFENDER,
  ProductName.ACCOUNT_DEFENDER,
  ProductName.CREDENTIAL_INTELLIGENCE,
  ProductName.CODE_DEFENDER
];

// node_modules/perimeterx-js-core/lib/esm/risk_token/constants.js
var COOKIE_SPLIT_DELIMITER = ":";
var COOKIE_V2_NAME = "_px2";
var COOKIE_V3_NAME = "_px3";
var COOKIE_V3_HMAC_INDEX = 0;
var COOKIE_V3_SALT_INDEX = 1;
var COOKIE_V3_ITERATIONS_INDEX = 2;
var COOKIE_V3_PAYLOAD_INDEX = 3;
var COOKIE_V3_PARTS_COUNT = 4;
var COOKIE_V3_MAXIMUM_SALT_LENGTH = 100;

// node_modules/perimeterx-js-core/lib/esm/risk_token/TokenVersion.js
var TokenVersion;
(function(TokenVersion2) {
  TokenVersion2["V2"] = "2";
  TokenVersion2["V3"] = "3";
})(TokenVersion || (TokenVersion = {}));

// node_modules/perimeterx-js-core/lib/esm/risk_token/utils.js
var convertMobileTokenVersionToCookieName = (tokenVersion) => {
  switch (tokenVersion) {
    case TokenVersion.V2:
      return COOKIE_V2_NAME;
    case TokenVersion.V3:
      return COOKIE_V3_NAME;
    default:
      return "";
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_token/TokenParseResult.js
var TokenParseResult;
(function(TokenParseResult2) {
  TokenParseResult2[TokenParseResult2["NONE"] = -1] = "NONE";
  TokenParseResult2[TokenParseResult2["SUCCESSFUL"] = 0] = "SUCCESSFUL";
  TokenParseResult2[TokenParseResult2["DECRYPTION_FAILED"] = 1] = "DECRYPTION_FAILED";
  TokenParseResult2[TokenParseResult2["VALIDATION_FAILED"] = 2] = "VALIDATION_FAILED";
})(TokenParseResult || (TokenParseResult = {}));

// node_modules/perimeterx-js-core/lib/esm/risk_token/token/TokenBase.js
var TokenBase = class {
  config;
  payload;
  cookieString;
  cookieSecret;
  cookieMaxLength;
  isValidated;
  constructor(config, cookieString, isValidated = false, payload) {
    this.config = config;
    this.cookieSecret = config.cookieSecret;
    this.cookieMaxLength = config.riskCookieMaxLength;
    this.cookieString = cookieString;
    this.isValidated = isValidated;
    this.payload = payload;
  }
  async verify(context) {
    if (!this.cookieString) {
      return TokenParseResult.NONE;
    }
    if (this.isValid()) {
      return TokenParseResult.SUCCESSFUL;
    }
    if (this.cookieString.length > this.cookieMaxLength) {
      return TokenParseResult.DECRYPTION_FAILED;
    }
    this.payload = this.payload || await this.decrypt(context);
    if (!this.payload) {
      return TokenParseResult.DECRYPTION_FAILED;
    }
    if (!await this.validate(context)) {
      return TokenParseResult.VALIDATION_FAILED;
    }
    this.isValidated = true;
    return TokenParseResult.SUCCESSFUL;
  }
  isValid() {
    return this.isValidated;
  }
  get tokenString() {
    return this.cookieString;
  }
  get payloadString() {
    return this.payload ? JSON.stringify(this.payload) : "";
  }
  toJSON() {
    return {
      action: this.action,
      cpa: this.cpa,
      hmac: this.hmac,
      isValidated: this.isValidated,
      payloadString: this.payloadString,
      score: this.score,
      timestamp: this.timestamp,
      tokenString: this.tokenString,
      uuid: this.uuid,
      vid: this.vid
    };
  }
};

// node_modules/perimeterx-js-core/lib/esm/http/utils/ContentType.js
var ContentType;
(function(ContentType2) {
  ContentType2["APPLICATION_X_WWW_FORM_URL_ENCODED"] = "application/x-www-form-urlencoded";
  ContentType2["APPLICATION_JSON"] = "application/json";
  ContentType2["APPLICATION_JAVASCRIPT"] = "application/javascript";
  ContentType2["TEXT_PLAIN"] = "text/plain";
  ContentType2["TEXT_HTML"] = "text/html";
  ContentType2["MULTIPART_FORM_DATA"] = "multipart/form-data";
  ContentType2["IMAGE_GIF"] = "image/gif";
})(ContentType || (ContentType = {}));

// node_modules/perimeterx-js-core/lib/esm/http/utils/constants.js
var X_FORWARDED_FOR_HEADER_NAME = "x-forwarded-for";
var USER_AGENT_HEADER_NAME = "user-agent";
var CONTENT_TYPE_HEADER_NAME = "content-type";
var COOKIE_HEADER_NAME = "cookie";
var AUTHORIZATION_HEADER_NAME = "authorization";
var ACCEPT_HEADER_NAME = "accept";
var SET_COOKIE_HEADER_NAME = "set-cookie";
var HOST_HEADER_NAME = "host";
var CACHE_CONTROL_HEADER_NAME = "cache-control";

// node_modules/perimeterx-js-core/lib/esm/http/utils/HttpMethod.js
var HttpMethod;
(function(HttpMethod2) {
  HttpMethod2["GET"] = "GET";
  HttpMethod2["POST"] = "POST";
  HttpMethod2["PUT"] = "PUT";
  HttpMethod2["HEAD"] = "HEAD";
  HttpMethod2["DELETE"] = "DELETE";
  HttpMethod2["OPTIONS"] = "OPTIONS";
  HttpMethod2["CONNECT"] = "CONNECT";
  HttpMethod2["TRACE"] = "TRACE";
  HttpMethod2["PATCH"] = "PATCH";
})(HttpMethod || (HttpMethod = {}));

// node_modules/perimeterx-js-core/lib/esm/http/utils/MinimalResponseUtils.js
var MinimalResponseUtils;
(function(MinimalResponseUtils2) {
  MinimalResponseUtils2.appendHeader = (response, name, value) => {
    return MinimalResponseUtils2.appendHeaders(response, {
      [name]: [value]
    });
  };
  MinimalResponseUtils2.appendHeaders = (response, headers) => {
    const body = response.body;
    const statusCode = response.status;
    const responseHeaders = response.headers;
    const newHeaders = { ...responseHeaders };
    Object.entries(headers).forEach(([name, values]) => {
      newHeaders[name] = (newHeaders[name] || []).concat(values);
    });
    return new MinimalResponseImpl({
      body,
      headers: newHeaders,
      status: statusCode
    });
  };
  MinimalResponseUtils2.from = (response) => {
    return new class {
      body = response.body;
      headers = response.headers;
      status = response.status;
    }();
  };
})(MinimalResponseUtils || (MinimalResponseUtils = {}));

// node_modules/perimeterx-js-core/lib/esm/http/utils/FormDataImpl.js
var FormDataImpl = class {
  data;
  constructor(data) {
    this.data = data ?? {};
  }
  append(name, value) {
    this.data[name] = (this.data[name] || []).concat(value);
  }
  delete(name) {
    delete this.data[name];
  }
  forEach(callbackfn, thisArg) {
    Object.entries(this.data).forEach(([key, values]) => {
      values?.forEach((val) => {
        callbackfn(val, key, this);
      });
    });
  }
  get(name) {
    return this.data[name]?.[0] || null;
  }
  getAll(name) {
    return this.data[name] || [];
  }
  has(name) {
    return this.get(name) !== null;
  }
  set(name, value) {
    if (typeof value === "string") {
      this.data[name] = [value];
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/http/utils/MultipartFormDataUtils.js
var MultipartFormDataUtils;
(function(MultipartFormDataUtils2) {
  MultipartFormDataUtils2.createFormDataWithoutFiles = (rawBody, contentType) => {
    const boundary = MultipartFormDataUtils2.getBoundary(contentType);
    const data = MultipartFormDataUtils2.parseMultipartBodyWithoutFiles(boundary, rawBody);
    return data ? new FormDataImpl(data) : null;
  };
  MultipartFormDataUtils2.getBoundary = (contentTypeValue) => {
    if (!contentTypeValue) {
      return null;
    }
    const BOUNDARY_PREFIX = "boundary=";
    const contentTypeArray = contentTypeValue.split(";").map((el) => el.trim());
    const boundary = contentTypeArray.find((substr) => substr.startsWith(BOUNDARY_PREFIX));
    if (!boundary) {
      return null;
    }
    return boundary.slice(BOUNDARY_PREFIX.length).trim();
  };
  MultipartFormDataUtils2.parseMultipartBodyWithoutFiles = (boundary, rawBody) => {
    if (!rawBody || !boundary) {
      return null;
    }
    const body = {};
    const entries = rawBody.split(boundary);
    for (const item of entries) {
      const filename = item.match(/filename="(.+?)"/)?.[1]?.trim();
      if (filename) {
        continue;
      }
      const name = item.match(/name="(.+?)"/)?.[1]?.trim();
      if (!name) {
        continue;
      }
      const value = item.match(/\r\n\r\n([^\r\n\v]*)\r\n--$/)?.[1]?.trim();
      if (!value) {
        continue;
      }
      body[name] = [value];
    }
    return body;
  };
})(MultipartFormDataUtils || (MultipartFormDataUtils = {}));

// node_modules/perimeterx-js-core/lib/esm/http/utils/MinimalResponseImpl.js
var MinimalResponseImpl = class {
  body;
  headers;
  status;
  constructor(options) {
    this.body = options.body;
    this.headers = options.headers || {};
    this.status = options.status || 200;
  }
};

// node_modules/perimeterx-js-core/lib/esm/http/utils/OutgoingRequestImpl.js
var OutgoingRequestImpl = class {
  body;
  url;
  method;
  headers;
  constructor(options) {
    this.url = options.url;
    this.method = options.method || HttpMethod.GET;
    this.headers = options.headers || {};
    this.body = options.body;
  }
};

// node_modules/perimeterx-js-core/lib/esm/http/interfaces/ReadonlyHeaders.js
var toReadonlyHeaders = (headers) => {
  const readonlyHeaders = {};
  headers.forEach((headerValue, headerName) => {
    const current = readonlyHeaders[headerName] || [];
    readonlyHeaders[headerName] = current.concat([headerValue]);
  });
  return readonlyHeaders;
};
var toMutableHeaders = (headers) => {
  return Object.fromEntries(Object.entries(headers).map(([name, values]) => [name, values.concat()]));
};
var joinHeaderValues = (headers) => {
  return Object.fromEntries(Object.entries(headers).map(([name, values]) => [name, values.join(", ")]));
};

// node_modules/perimeterx-js-core/lib/esm/blocker/BlockerBase.js
var BlockerBase = class {
  statusCode;
  contentType;
  constructor(contentType, statusCode = 403) {
    this.contentType = contentType;
    this.statusCode = statusCode;
  }
  createBlockResponse(context) {
    const status = this.statusCode;
    const headers = this.createHeaders(context);
    const body = this.createBlockBody(context);
    return new MinimalResponseImpl({
      status,
      headers,
      body
    });
  }
  createHeaders(context) {
    return {
      [CONTENT_TYPE_HEADER_NAME]: [this.contentType]
    };
  }
};

// node_modules/perimeterx-js-core/lib/esm/blocker/JsonBlockerBase.js
var JsonBlockerBase = class extends BlockerBase {
  constructor() {
    super(ContentType.APPLICATION_JSON);
  }
  shouldBlock(context) {
    const acceptHeaderValue = context.requestData.request.headers.get(ACCEPT_HEADER_NAME) || "";
    const acceptHeaderContainsJson = acceptHeaderValue?.split(",").some((value) => value.toLowerCase() === ContentType.APPLICATION_JSON);
    return !context.isMobile && acceptHeaderContainsJson;
  }
  createBlockBody(context) {
    return JSON.stringify(this.createJsonPayload(context));
  }
};

// node_modules/perimeterx-js-core/lib/esm/blocker/MobileBlocker.js
var MobileBlocker = class extends BlockerBase {
  config;
  base64Utils;
  template;
  constructor(config, base64Utils, template) {
    super(ContentType.APPLICATION_JSON);
    this.config = config;
    this.base64Utils = base64Utils;
    this.template = template;
  }
  shouldBlock(context) {
    return context.isMobile;
  }
  createBlockBody(context) {
    const blockData = createBlockData(this.config, context, this.base64Utils);
    const html = renderHtml(this.template, blockData);
    return JSON.stringify({
      action: BLOCK_ACTION_TO_WORD_MAP.get(blockData.blockAction),
      uuid: blockData.uuid,
      vid: blockData.vid,
      appId: blockData.appId,
      page: this.base64Utils.base64Encode(html),
      collectorHost: this.config.backendCollectorUrl
    });
  }
};

// node_modules/perimeterx-js-core/lib/esm/blocker/model/BlockAction.js
var BlockAction;
(function(BlockAction2) {
  BlockAction2["CAPTCHA"] = "c";
  BlockAction2["RATE_LIMIT"] = "r";
  BlockAction2["CHALLENGE"] = "j";
  BlockAction2["HYPE_SALE_CHALLENGE"] = "hsc";
  BlockAction2["HYPE_SALE_CHALLENGE_LEGACY"] = "cp";
})(BlockAction || (BlockAction = {}));

// node_modules/perimeterx-js-core/lib/esm/blocker/model/BlockActionToWordMap.js
var BLOCK_ACTION_TO_WORD_MAP = /* @__PURE__ */ new Map([
  [BlockAction.CAPTCHA, "captcha"],
  [BlockAction.RATE_LIMIT, "ratelimit"],
  [BlockAction.CHALLENGE, "challenge"],
  [BlockAction.HYPE_SALE_CHALLENGE, "captcha"]
  // this is what mobile HSC expects
]);

// node_modules/perimeterx-js-core/lib/esm/utils/cookie_parser/StringSplitCookieParser.js
var StringSplitCookieParser = class {
  cookieDelimiter;
  constructor(cookieDelimiter = ";") {
    this.cookieDelimiter = cookieDelimiter;
  }
  parseCookies(...cookieHeaderValues) {
    const cookies = {};
    if (!cookieHeaderValues) {
      return cookies;
    }
    cookieHeaderValues.forEach((value) => {
      Object.assign(cookies, this.parseCookieHeaderValue(value));
    });
    return cookies;
  }
  parseCookieHeaderValue(cookieHeaderValue) {
    if (!cookieHeaderValue || typeof cookieHeaderValue !== "string") {
      return {};
    }
    const cookieEntries = cookieHeaderValue.split(this.cookieDelimiter).map(this.getCookieParts).filter(Boolean);
    const cookies = {};
    cookieEntries.forEach(([cookieName, cookieValue]) => {
      cookies[cookieName] = cookieValue;
    });
    return cookies;
  }
  getCookieParts(cookieString) {
    const COOKIE_SPLITTER = "=";
    const cookie = cookieString.trim();
    const equalIndex = cookie.indexOf(COOKIE_SPLITTER);
    if (equalIndex === -1) {
      return null;
    }
    const cookieKey = cookie.substring(0, equalIndex);
    const cookieValue = cookie.substring(equalIndex + 1);
    if (!cookieKey || !cookieValue) {
      return null;
    }
    return [cookieKey, cookieValue];
  }
};

// node_modules/perimeterx-js-core/lib/esm/utils/Algorithm.js
var Algorithm;
(function(Algorithm2) {
  Algorithm2[Algorithm2["SHA256"] = 0] = "SHA256";
  Algorithm2[Algorithm2["AES_CBC"] = 1] = "AES_CBC";
})(Algorithm || (Algorithm = {}));

// node_modules/perimeterx-js-core/lib/esm/utils/timestamp_hmac_header_validator/DefaultTimestampHmacHeaderValidator.js
var TIMESTAMP_HMAC_HEADER_DELIMITER = ":";
var TIMESTAMP_HMAC_HEADER_PARTS_COUNT = 2;
var DefaultTimestampHmacHeaderValidator = class {
  config;
  secret;
  base64Utils;
  hmacUtils;
  constructor(config, secret, base64Utils, hmacUtils) {
    this.config = config;
    this.secret = secret;
    this.base64Utils = base64Utils;
    this.hmacUtils = hmacUtils;
  }
  async isValid(headerValue, logger) {
    const decodedValue = this.base64Utils.base64Decode(headerValue);
    const splitValue = decodedValue.split(TIMESTAMP_HMAC_HEADER_DELIMITER);
    if (splitValue.length !== TIMESTAMP_HMAC_HEADER_PARTS_COUNT) {
      logger.debug(`malformed timestamp:hmac header: ${decodedValue}`);
      return false;
    }
    const [timestamp, givenHmac] = splitValue;
    if (!await this.isHmacValid(givenHmac, timestamp, logger)) {
      logger.debug(`hmac validation failed. original hmac: ${givenHmac}, timestamp: ${timestamp}.`);
      return false;
    }
    const curUnixTime = +/* @__PURE__ */ new Date();
    const timestampNumber = parseInt ? parseInt(timestamp) : Number(timestamp);
    if (isNaN(timestampNumber) || timestampNumber < curUnixTime) {
      logger.debug(`hmac header timestamp expired: ${timestamp} < ${curUnixTime}`);
      return false;
    }
    return true;
  }
  async isHmacValid(givenHmac, timestamp, logger) {
    try {
      return givenHmac === await this.hmacUtils.createHmac(Algorithm.SHA256, timestamp, this.secret);
    } catch (err) {
      logger.debug(`caught error calculating timestamp:header hmac: ${err}`);
      return false;
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/utils/error/EnforcerErrorName.js
var EnforcerErrorName;
(function(EnforcerErrorName2) {
  EnforcerErrorName2["ENFORCER_ERROR"] = "EnforcerError";
  EnforcerErrorName2["ENFORCER_TIMEOUT_ERROR"] = "EnforcerTimeoutError";
})(EnforcerErrorName || (EnforcerErrorName = {}));

// node_modules/perimeterx-js-core/lib/esm/utils/error/EnforcerError.js
var EnforcerError = class extends Error {
  constructor(message) {
    super(message);
    this.name = EnforcerErrorName.ENFORCER_ERROR;
  }
};

// node_modules/perimeterx-js-core/lib/esm/utils/error/EnforcerTimeoutError.js
var EnforcerTimeoutError = class extends EnforcerError {
  constructor(ms) {
    super(`${typeof ms === "number" ? `${ms}ms ` : ""}timeout reached`);
    this.name = EnforcerErrorName.ENFORCER_TIMEOUT_ERROR;
  }
};

// node_modules/perimeterx-js-core/lib/esm/utils/constants.js
var PXVID_COOKIE_NAME = "_pxvid";
var PXHD_COOKIE_NAME = "_pxhd";
var PXDE_COOKIE_NAME = "_pxde";
var BYPASS_MONITOR_HEADER_VALUE = "1";
var X_PX_AUTHORIZATION_HEADER_NAME = "x-px-authorization";
var X_PX_ORIGINAL_TOKEN_HEADER_NAME = "x-px-original-token";
var X_PX_BYPASS_REASON_HEADER_NAME = "x-px-bypass-reason";
var PUSH_DATA_HMAC_HEADER_NAME = "x-px-pushdata";
var PUSH_DATA_FEATURE_HEADER_NAME = "x-px-feature";
var EMAIL_ADDRESS_REGEX = /^[a-zA-Z0-9_+&*-]+(?:\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,7}$/;
var URL_REGEX = /^(https?\:)\/\/(([^@\s:]+):?([^@\s]*)@)?(([^:\/?#]*)(?:\:([0-9]+))?)([\/]{0,1}[^?#]*)(\?[^#]*|)(#.*|)$/;
var CORE_MODULE_VERSION = "JS Core 0.18.1";

// node_modules/perimeterx-js-core/lib/esm/utils/utils.js
var isValidEnumValue = (options, selection) => {
  return Object.values(options).includes(selection);
};
var isValidUuid = (uuid) => {
  if (!uuid) {
    return false;
  }
  const uuidValidator = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
  return uuidValidator.test(uuid);
};
var isEmailAddress = (string) => {
  return EMAIL_ADDRESS_REGEX.test(string);
};
var getScoreApiDomain = (appId) => `sapi-${appId.toLowerCase()}.perimeterx.net`;
var getCollectorDomain = (appId) => `collector-${appId.toLowerCase()}.perimeterx.net`;
var getAuthorizationHeader = (authToken) => `Bearer ${authToken}`;
var getExtension = (route) => {
  const EXTENSION_INDICATOR = ".";
  if (route.indexOf(EXTENSION_INDICATOR) === -1) {
    return "";
  }
  const cleanPath = route.split("?")[0].split("#")[0];
  const endOfPath = cleanPath.substring(cleanPath.lastIndexOf("/") + 1);
  const extensionIndex = endOfPath.lastIndexOf(EXTENSION_INDICATOR);
  if (extensionIndex === -1 || extensionIndex + 1 === endOfPath.length) {
    return "";
  }
  return endOfPath.substring(extensionIndex);
};
var removeSensitiveFields = (object, sensitiveFields) => {
  const newObj = Object.assign({}, object);
  sensitiveFields.forEach((fieldName) => {
    delete newObj[fieldName];
  });
  return newObj;
};
var removeSensitiveHeaders = (headers, sensitiveHeaderNames) => {
  const ret = toMutableHeaders(headers);
  sensitiveHeaderNames.forEach((name) => {
    delete ret[name];
  });
  return ret;
};
var isRouteInPatterns = (route, patterns) => {
  return patterns.some((pattern) => isRouteMatch(route, pattern));
};
var isRouteMatch = (route, pattern) => {
  if (!route || !pattern) {
    return false;
  }
  if (pattern instanceof RegExp && pattern.test(route)) {
    return true;
  }
  if (typeof pattern === "string" && route.startsWith(pattern)) {
    return true;
  }
  return false;
};
var transferExistingProperties = (fromObj, toObj, propertyMappings) => {
  if (!toObj || !fromObj) {
    return;
  }
  Object.entries(propertyMappings).forEach(([fromObjKey, toObjKey]) => {
    if (typeof fromObj[fromObjKey] !== "string" && fromObj[fromObjKey] != null || typeof fromObj[fromObjKey] === "string" && fromObj[fromObjKey] !== "") {
      toObj[toObjKey] = fromObj[fromObjKey];
    }
  });
};
var getPropertyFromObject = (object, ...keys) => {
  let value = object;
  for (const key of keys) {
    if (value && typeof value === "object") {
      value = value[key];
    } else {
      break;
    }
  }
  return value;
};
var sleep = (ms) => {
  return new Promise((resolve) => setTimeout(resolve, ms));
};
var algoToCryptoString = (algo) => {
  switch (algo) {
    case Algorithm.SHA256:
    default:
      return "sha256";
  }
};

// node_modules/perimeterx-js-core/lib/esm/utils/ModuleMode.js
var ModuleMode;
(function(ModuleMode2) {
  ModuleMode2["MONITOR"] = "monitor";
  ModuleMode2["ACTIVE_BLOCKING"] = "active_blocking";
})(ModuleMode || (ModuleMode = {}));

// node_modules/perimeterx-js-core/lib/esm/utils/VidSource.js
var VidSource;
(function(VidSource2) {
  VidSource2["VID_COOKIE"] = "vid_cookie";
  VidSource2["RISK_COOKIE"] = "risk_cookie";
})(VidSource || (VidSource = {}));

// node_modules/perimeterx-js-core/lib/esm/blocker/utils.js
var renderHtml = (htmlTemplate, blockData) => {
  if (!blockData) {
    return htmlTemplate;
  }
  Object.entries(blockData).forEach(([key, value]) => {
    const replace = `{{${key}}}`;
    const regEx = new RegExp(replace, "g");
    htmlTemplate = htmlTemplate.replace(regEx, `${value}`);
  });
  return htmlTemplate;
};
var createBlockData = (config, context, base64Utils) => {
  const captchaScriptSuffix = "/captcha.js";
  const b64EncodedUrl = base64Utils.base64Encode(context.requestData.url.href);
  const b64HttpMethod = base64Utils.base64Encode(context.requestData.method);
  const captchaParams = `?a=${context.blockAction}&u=${context.uuid}&v=${context.vid || ""}&m=${context.isMobile ? "1" : "0"}&b=${b64EncodedUrl}&h=${b64HttpMethod}`;
  let jsClientSrc = `${config.backendClientUrl}/${config.appId}/main.min.js`;
  let blockScript = `${config.backendCaptchaUrl}/${config.appId}${captchaScriptSuffix}${captchaParams}`;
  let hostUrl = config.backendCollectorUrl;
  if (config.firstPartyEnabled && !context.isMobile) {
    jsClientSrc = getMostCustomizedFirstPartyPath(config, FirstPartySuffix.SENSOR);
    blockScript = `${getMostCustomizedFirstPartyPath(config, FirstPartySuffix.CAPTCHA)}${config.customFirstPartyCaptchaEndpoint ? captchaParams : `${captchaScriptSuffix}${captchaParams}`}`;
    hostUrl = getMostCustomizedFirstPartyPath(config, FirstPartySuffix.XHR);
  }
  const cssRef = config.cssRef ? `<link rel="stylesheet" type="text/css" href="${config.cssRef}" />` : "";
  const jsRef = config.jsRef ? `<script src="${config.jsRef}"></script>` : "";
  const altBlockScript = `${config.altBackendCaptchaUrl}/${config.appId}${captchaScriptSuffix}${captchaParams}`;
  const jsTemplateScriptSrc = `https://captcha.px-cdn.net/${config.appId}/checkpoint.js`;
  return {
    appId: config.appId,
    vid: context.vid || context.requestData?.cookies?.[PXVID_COOKIE_NAME] || "",
    uuid: context.uuid || "",
    isMobile: context.isMobile,
    customLogo: config.customLogo || "",
    blockAction: context.blockAction,
    hostUrl,
    cssRef,
    jsRef,
    jsClientSrc,
    firstPartyEnabled: config.firstPartyEnabled,
    blockScript,
    altBlockScript,
    jsTemplateScriptSrc
  };
};

// node_modules/perimeterx-js-core/lib/esm/risk_token/token/v2/DefaultTokenV2.js
var DefaultTokenV2 = class extends TokenBase {
  base64Utils;
  hmacUtils;
  isHighRisk;
  constructor(config, cookieString, base64Utils, hmacUtils) {
    super(config, cookieString);
    this.base64Utils = base64Utils;
    this.hmacUtils = hmacUtils;
    this.isHighRisk = void 0;
  }
  decrypt(context) {
    try {
      const payload = this.decode(this.cookieString);
      if (payload?.t == null || payload?.h == null || payload?.u == null || payload?.v == null) {
        context.logger.debug(`missing cookie v2 fields: ${JSON.stringify(payload)}`);
        return null;
      }
      return payload;
    } catch (e) {
      context.logger.debug(`cookie v2 decryption failed: ${e}`);
    }
    return null;
  }
  async validate(context) {
    if (typeof this.payload.t !== "number" || !isValidUuid(this.payload.v) || !isValidUuid(this.payload.u) || !this.payload.h) {
      context.logger.debug(`invalid cookie v2 structure: ${JSON.stringify(this.payload)}`);
      return false;
    }
    try {
      const signingFields = this.getSigningFields(context);
      const passHmac = await this.calculateHmac(this.getHashParam("0", signingFields));
      if (passHmac === this.payload.h) {
        this.isHighRisk = false;
        return true;
      }
      const blockHmac = await this.calculateHmac(this.getHashParam("1", signingFields));
      if (blockHmac === this.payload.h) {
        this.isHighRisk = true;
        return true;
      }
      context.logger.debug(`unknown cookie v2 hmac (${this.payload.h}), does not match pass (${passHmac}) or block (${blockHmac})`);
    } catch (e) {
      context.logger.debug(`cookie v2 validation caught error: ${e}`);
    }
    return false;
  }
  decode(cookieString) {
    const decodedCookie = this.base64Utils.base64Decode(cookieString);
    return JSON.parse(decodedCookie);
  }
  getSigningFields(context) {
    return context.isMobile ? "" : context.requestData.userAgent;
  }
  getHashParam(startingValue, signingFields) {
    let hashParam = startingValue;
    if (signingFields) {
      hashParam += signingFields;
    }
    return hashParam;
  }
  async calculateHmac(param) {
    const payload = `${this.payload.t}${this.payload.u}${this.payload.v}${param}`;
    return this.hmacUtils.createHmac(Algorithm.SHA256, payload, this.cookieSecret);
  }
  isExpired() {
    return Date.now() > this.payload?.t;
  }
  isHighScore() {
    return this.isHighRisk;
  }
  get hmac() {
    return this.payload?.h;
  }
  get timestamp() {
    return this.payload?.t;
  }
  get uuid() {
    return this.payload?.u;
  }
  get vid() {
    return this.payload?.v;
  }
  get score() {
    if (this.isValid()) {
      return this.isHighScore() ? 100 : 0;
    }
    return;
  }
  get action() {
    return BlockAction.CAPTCHA;
  }
  get cpa() {
    return;
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_token/token/v3/TokenSignField.js
var TokenSignField;
(function(TokenSignField2) {
  TokenSignField2["SOCKET_IP"] = "s";
  TokenSignField2["USER_AGENT"] = "u";
})(TokenSignField || (TokenSignField = {}));

// node_modules/perimeterx-js-core/lib/esm/risk_token/token/v3/DefaultTokenV3.js
var DefaultTokenV3 = class extends TokenBase {
  maxIterations;
  minIterations;
  blockingScore;
  cipherUtils;
  hmacUtils;
  hash;
  constructor(config, cookieString, cipherUtils, hmacUtils, isValidated = false, payload) {
    super(config, cookieString, isValidated, payload);
    this.maxIterations = config.riskCookieMaxIterations;
    this.minIterations = config.riskCookieMinIterations;
    this.blockingScore = config.blockingScore;
    this.cookieString = cookieString;
    this.cipherUtils = cipherUtils;
    this.hmacUtils = hmacUtils;
  }
  async decrypt(context) {
    try {
      const data = this.cookieString.split(COOKIE_SPLIT_DELIMITER);
      if (data.length !== COOKIE_V3_PARTS_COUNT) {
        context.logger.debug(`invalid cookie v3 structure: ${data}`);
        return null;
      }
      this.hash = data[COOKIE_V3_HMAC_INDEX];
      const salt = data[COOKIE_V3_SALT_INDEX];
      const iterations = parseInt ? parseInt(data[COOKIE_V3_ITERATIONS_INDEX]) : Number(data[COOKIE_V3_ITERATIONS_INDEX]);
      const encryptedCookie = data[COOKIE_V3_PAYLOAD_INDEX];
      if (!iterations || iterations > this.maxIterations || iterations < this.minIterations) {
        context.logger.debug(`invalid cookie v3 iterations: ${iterations} is not between ${this.minIterations} and ${this.maxIterations}`);
        return null;
      }
      if (!salt || typeof salt !== "string" || salt.length > COOKIE_V3_MAXIMUM_SALT_LENGTH) {
        context.logger.debug(`invalid cookie v3 salt: ${salt}`);
        return null;
      }
      if (!encryptedCookie || typeof encryptedCookie !== "string") {
        context.logger.debug(`invalid cookie v3 encrypted payload: ${encryptedCookie}`);
        return null;
      }
      return await this.decryptPayload(encryptedCookie, salt, iterations, context);
    } catch (e) {
      context.logger.debug(`cookie v3 decryption failed: ${e}`);
    }
    return null;
  }
  async decryptPayload(encryptedCookie, salt, iterations, context) {
    try {
      const decryptedCookie = await this.cipherUtils.pbkdf2Decrypt(this.cookieSecret, encryptedCookie, iterations, salt);
      if (!decryptedCookie) {
        context.logger.debug(`cookie v3 decryption returned falsy value: ${decryptedCookie}`);
        return null;
      }
      const payload = JSON.parse(decryptedCookie);
      if (payload?.a == null || payload?.s == null || payload?.t == null || payload?.u == null || payload?.v == null) {
        context.logger.debug(`invalid cookie v3 structure: ${JSON.stringify(payload)}`);
        return null;
      }
      return payload;
    } catch (e) {
      context.logger.debug(`error decrypting cookie v3: ${e}`);
      return null;
    }
  }
  async validate(context) {
    try {
      const signedFields = this.getSignedWithFields(context);
      const hmacStrBase = this.cookieString.substring(this.cookieString.indexOf(COOKIE_SPLIT_DELIMITER) + 1);
      const payload = `${hmacStrBase}${signedFields.join("")}`;
      const hash = await this.hmacUtils.createHmac(Algorithm.SHA256, payload, this.cookieSecret);
      return hash === this.hmac;
    } catch (e) {
      context.logger.debug(`error validating cookie v3: ${e}`);
      return false;
    }
  }
  getSignedWithFields(context) {
    if (context.isMobile) {
      return [];
    } else if (this.payload?.x) {
      return this.payload.x.split("").map((char) => this.getSignedWithField(char, context));
    } else {
      return [context.requestData.userAgent];
    }
  }
  getSignedWithField(char, { requestData }) {
    switch (char) {
      case TokenSignField.SOCKET_IP:
        return requestData.ip;
      case TokenSignField.USER_AGENT:
        return requestData.userAgent;
      default:
        return "";
    }
  }
  isExpired() {
    return Date.now() > this.payload?.t;
  }
  isHighScore() {
    if (!this.payload) {
      return void 0;
    }
    return this.payload.s >= this.blockingScore;
  }
  get timestamp() {
    return this.payload?.t;
  }
  get uuid() {
    return this.payload?.u;
  }
  get vid() {
    return this.payload?.v;
  }
  get score() {
    return this.payload?.s;
  }
  get action() {
    return this.payload?.a;
  }
  get hmac() {
    return this.hash;
  }
  get cpa() {
    return this.payload?.cpa;
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_token/token/serialize/SerializedToken.js
var SerializedToken = class {
  action;
  cpa;
  hmac;
  isValidated;
  payloadString;
  score;
  timestamp;
  tokenString;
  uuid;
  vid;
  blockingScore;
  constructor(config, serializedToken) {
    this.blockingScore = config.blockingScore;
    this.action = serializedToken.action;
    this.cpa = serializedToken.cpa;
    this.hmac = serializedToken.hmac;
    this.isValidated = serializedToken.isValidated;
    this.payloadString = serializedToken.payloadString;
    this.score = serializedToken.score;
    this.timestamp = serializedToken.timestamp;
    this.tokenString = serializedToken.tokenString;
    this.uuid = serializedToken.uuid;
    this.vid = serializedToken.vid;
  }
  isExpired() {
    return Date.now() >= this.timestamp;
  }
  isHighScore() {
    return this.score >= this.blockingScore;
  }
  verify(context) {
    return TokenParseResult.NONE;
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_token/parser/TokenParserBase.js
var TokenParserBase = class {
  config;
  options;
  constructor(config, options) {
    this.config = config;
    this.options = options;
  }
  async parseToken(context) {
    const tokenData = this.initializeToken(context);
    try {
      if (!tokenData.token) {
        context.logger.debug("no token found");
        await this.handleMobileErrorIfNeeded(context, tokenData);
        return tokenData;
      }
      tokenData.tokenParseResult = await tokenData.token.verify(context);
    } catch (e) {
      context.logger.debug(`could not parse token - ${e}`);
      tokenData.tokenParseResult = tokenData.token ? TokenParseResult.DECRYPTION_FAILED : TokenParseResult.NONE;
    }
    return tokenData;
  }
  initializeToken(context) {
    if (context.isMobile) {
      return this.createMobileTokenData(context);
    } else {
      return this.createWebTokenData(context.requestData.cookies);
    }
  }
  createMobileTokenData(context) {
    const { requestData: { request } } = context;
    const mobileToken = request.headers.get(X_PX_AUTHORIZATION_HEADER_NAME);
    const tokenData = {
      tokenParseResult: TokenParseResult.NONE,
      token: this.getMobileToken(mobileToken, context),
      mobileData: {
        originalToken: this.getMobileToken(request.headers.get(X_PX_ORIGINAL_TOKEN_HEADER_NAME), context),
        bypassReason: request.headers.get(X_PX_BYPASS_REASON_HEADER_NAME) || ""
      }
    };
    if (!tokenData.token && /^\d+$/.test(mobileToken)) {
      tokenData.mobileData.mobileError = mobileToken;
    }
    return tokenData;
  }
  getMobileToken(mobileToken, context) {
    try {
      if (!mobileToken || mobileToken?.indexOf(COOKIE_SPLIT_DELIMITER) === -1) {
        return null;
      }
      const [tokenVersion, ...cookieString] = mobileToken.split(COOKIE_SPLIT_DELIMITER);
      const cookieName = convertMobileTokenVersionToCookieName(tokenVersion);
      if (!cookieName) {
        return null;
      }
      return this.createToken(this.config, { [cookieName]: cookieString.join(COOKIE_SPLIT_DELIMITER) }, this.options);
    } catch (e) {
      context.logger.debug(`error extracting mobile token - ${e}, token: ${mobileToken}`);
      return null;
    }
  }
  createWebTokenData(cookies) {
    return {
      tokenParseResult: TokenParseResult.NONE,
      token: this.createToken(this.config, cookies, this.options)
    };
  }
  async handleMobileErrorIfNeeded(context, { mobileData }) {
    if (!mobileData || !mobileData.mobileError || !mobileData.originalToken) {
      return;
    }
    mobileData.originalTokenParseResult = await mobileData.originalToken.verify(context);
    if (mobileData.originalTokenParseResult === TokenParseResult.SUCCESSFUL) {
      mobileData.decodedOriginalToken = mobileData.originalToken.payloadString;
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_token/parser/DefaultTokenV2Parser.js
var DefaultTokenV2Parser = class extends TokenParserBase {
  constructor(config, options) {
    super(config, options);
  }
  createToken(config, cookies, options) {
    if (cookies[COOKIE_V2_NAME]) {
      return new DefaultTokenV2(config, cookies[COOKIE_V2_NAME], options.base64Utils, options.hmacUtils);
    }
    return null;
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_token/parser/DefaultTokenV3Parser.js
var DefaultTokenV3Parser = class extends TokenParserBase {
  constructor(config, options) {
    super(config, options);
  }
  createToken(config, cookies, options) {
    if (cookies[COOKIE_V3_NAME]) {
      return new DefaultTokenV3(config, cookies[COOKIE_V3_NAME], options.cipherUtils, options.hmacUtils);
    }
    return null;
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_token/MobileError.js
var MobileError;
(function(MobileError2) {
  MobileError2["NO_COOKIE"] = "1";
  MobileError2["CONNECTION_ERROR"] = "2";
  MobileError2["CERTIFICATE_PINNING_ERROR"] = "3";
  MobileError2["BYPASS"] = "4";
})(MobileError || (MobileError = {}));

// node_modules/perimeterx-js-core/lib/esm/risk_token/TokenOrigin.js
var TokenOrigin;
(function(TokenOrigin2) {
  TokenOrigin2["COOKIE"] = "cookie";
  TokenOrigin2["HEADER"] = "header";
})(TokenOrigin || (TokenOrigin = {}));

// node_modules/perimeterx-js-core/lib/esm/risk_api/model/RiskStatus.js
var RiskStatus;
(function(RiskStatus2) {
  RiskStatus2[RiskStatus2["FAILURE"] = -1] = "FAILURE";
  RiskStatus2[RiskStatus2["SUCCESS"] = 0] = "SUCCESS";
})(RiskStatus || (RiskStatus = {}));

// node_modules/perimeterx-js-core/lib/esm/risk_api/model/RiskApiCallResult.js
var RiskApiCallResult;
(function(RiskApiCallResult2) {
  RiskApiCallResult2[RiskApiCallResult2["NONE"] = -1] = "NONE";
  RiskApiCallResult2[RiskApiCallResult2["SUCCESSFUL"] = 0] = "SUCCESSFUL";
  RiskApiCallResult2[RiskApiCallResult2["ERROR"] = 1] = "ERROR";
  RiskApiCallResult2[RiskApiCallResult2["TIMEOUT"] = 2] = "TIMEOUT";
})(RiskApiCallResult || (RiskApiCallResult = {}));

// node_modules/perimeterx-js-core/lib/esm/risk_api/model/S2SErrorReason.js
var S2SErrorReason;
(function(S2SErrorReason2) {
  S2SErrorReason2["UNABLE_TO_SEND_REQUEST"] = "unable_to_send_request";
  S2SErrorReason2["BAD_REQUEST"] = "bad_request";
  S2SErrorReason2["SERVER_ERROR"] = "server_error";
  S2SErrorReason2["INVALID_RESPONSE"] = "invalid_response";
  S2SErrorReason2["REQUEST_FAILED_ON_SERVER"] = "request_failed_on_server";
  S2SErrorReason2["UNKNOWN_ERROR"] = "unknown_error";
})(S2SErrorReason || (S2SErrorReason = {}));

// node_modules/perimeterx-js-core/lib/esm/risk_api/risk_response/RiskResponseBase.js
var RiskResponseBase = class {
  response;
  riskResponse;
  constructor(response) {
    this.response = response;
  }
  async validate() {
    try {
      this.riskResponse = await this.response.json();
      return this.status === RiskStatus.SUCCESS && this.validateRiskResponseScore();
    } catch (e) {
      return false;
    }
  }
  get status() {
    return this.riskResponse?.status;
  }
  get action() {
    return this.riskResponse?.action;
  }
  get message() {
    return this.riskResponse?.message;
  }
  get pxhd() {
    return this.riskResponse?.pxhd;
  }
  get uuid() {
    return this.riskResponse?.uuid;
  }
  get dataEnrichment() {
    return this.riskResponse?.data_enrichment;
  }
  get pxhdDomain() {
    return this.riskResponse?.pxhdDomain;
  }
  get additionalRiskInfo() {
    return this.riskResponse?.additional_risk_info;
  }
  get drc() {
    return this.riskResponse?.drc;
  }
  toJSON() {
    return {
      status: this.status,
      action: this.action,
      message: this.message,
      dataEnrichment: this.dataEnrichment,
      pxhd: this.pxhd,
      pxhdDomain: this.pxhdDomain,
      score: this.score,
      drc: this.drc,
      additionalRiskInfo: this.additionalRiskInfo,
      uuid: this.uuid
    };
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_api/risk_response/v2/DefaultRiskResponseV2.js
var DefaultRiskResponseV2 = class extends RiskResponseBase {
  constructor(response) {
    super(response);
  }
  get score() {
    return typeof this.riskResponse?.cookie_cfg_block_result === "undefined" ? void 0 : this.riskResponse?.cookie_cfg_block_result === "1" ? 100 : 0;
  }
  validateRiskResponseScore() {
    return ["0", "1"].includes(this.riskResponse?.cookie_cfg_block_result);
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_api/risk_response/v3/DefaultRiskResponseV3.js
var DefaultRiskResponseV3 = class extends RiskResponseBase {
  constructor(response) {
    super(response);
  }
  get score() {
    return this.riskResponse?.score;
  }
  validateRiskResponseScore() {
    return typeof this.riskResponse?.score === "number";
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_api/risk_response/serialize/SerializedRiskResponse.js
var SerializedRiskResponse = class {
  action;
  additionalRiskInfo;
  dataEnrichment;
  drc;
  message;
  pxhd;
  pxhdDomain;
  score;
  status;
  uuid;
  constructor(riskResponseJson) {
    this.action = riskResponseJson.action;
    this.additionalRiskInfo = riskResponseJson.additionalRiskInfo;
    this.dataEnrichment = riskResponseJson.dataEnrichment;
    this.drc = riskResponseJson.drc;
    this.message = riskResponseJson.message;
    this.pxhd = riskResponseJson.pxhd;
    this.pxhdDomain = riskResponseJson.pxhdDomain;
    this.score = riskResponseJson.score;
    this.status = riskResponseJson.status;
    this.uuid = riskResponseJson.uuid;
  }
  validate() {
    return true;
  }
};

// node_modules/perimeterx-js-core/lib/esm/activities/ActivityType.js
var ActivityType;
(function(ActivityType2) {
  ActivityType2["PAGE_REQUESTED"] = "page_requested";
  ActivityType2["BLOCK"] = "block";
  ActivityType2["ADDITIONAL_S2S"] = "additional_s2s";
  ActivityType2["ENFORCER_TELEMETRY"] = "enforcer_telemetry";
})(ActivityType || (ActivityType = {}));

// node_modules/perimeterx-js-core/lib/esm/activities/utils.js
var createAsyncActivity = (activityType, config, context) => {
  return {
    type: activityType,
    px_app_id: config.appId,
    url: context.requestData.url.href,
    headers: activityType !== ActivityType.ADDITIONAL_S2S ? toHeaderEntryArray(removeSensitiveHeaders(context.requestData.headers, config.sensitiveHeaders)) : void 0,
    pxhd: context.pxhd?.value,
    socket_ip: context.requestData.ip,
    timestamp: Date.now(),
    vid: context.vid,
    details: createActivityDetails(activityType, config, context)
  };
};
var createActivityDetails = (activityType, config, context) => {
  const commonActivityDetails = createCommonActivityDetails(config, context);
  const commonAsyncActivityDetails = createAsyncActivityCommonDetails(context);
  let specificActivityDetails = {};
  switch (activityType) {
    case ActivityType.PAGE_REQUESTED:
      specificActivityDetails = createPageRequestedActivityDetails(context);
      break;
    case ActivityType.BLOCK:
      specificActivityDetails = createBlockActivityDetails(context);
      break;
    case ActivityType.ADDITIONAL_S2S:
      specificActivityDetails = createAdditionalS2SActivityDetails(config, context);
      break;
  }
  return Object.assign(commonActivityDetails, commonAsyncActivityDetails, specificActivityDetails);
};
var createAsyncActivityCommonDetails = (context) => {
  const details = {
    client_uuid: context.uuid
  };
  addRiskApiDataToAsyncActivityCommonDetails(details, context);
  addResponseDataToAsyncActivityCommonDetails(details, context);
  return details;
};
var createCommonActivityDetails = (config, context) => {
  const details = {
    module_version: config.moduleVersion,
    // Note: risk_mode currently reflects only Bot Defender mode
    risk_mode: context.productData.bd?.isMonitoredRequest ? ModuleMode.MONITOR : ModuleMode.ACTIVE_BLOCKING
  };
  addConfigDataToDetails(details, config);
  addRootContextDataToDetails(details, context);
  addRequestDataToDetails(details, context.requestData);
  addTokenDataToDetails(details, context.tokenData);
  addProductDataToDetails(details, context.productData);
  addServerDataToDetails(details, context.serverData);
  addTlsDataToDetails(details, context.tlsData);
  addCustomParametersToDetails(details, context.customParameters);
  return details;
};
var addRootContextDataToDetails = (details, context) => {
  transferExistingProperties(context, details, {
    requestId: "request_id",
    tokenOrigin: "cookie_origin",
    vidSource: "enforcer_vid_source",
    graphqlData: "graphql_operations",
    enforcerStartTime: "enforcer_start_time"
  });
};
var addConfigDataToDetails = (details, config) => {
  if (config.remoteConfigVersion) {
    details.remote_config_version = config.remoteConfigVersion;
  }
};
var addCustomParametersToDetails = (details, customParameters) => {
  if (customParameters) {
    Object.assign(details, customParameters);
  }
};
var addProductDataToDetails = (details, productData) => {
  transferExistingProperties(productData.ad, details, {
    appUserId: "app_user_id",
    additionalFields: "jwt_additional_fields",
    crossTabSession: "cross_tab_session"
  });
  transferExistingProperties(productData.ci, details, {
    hashedUsername: "user",
    hashedPassword: "pass",
    ciVersion: "ci_version",
    ssoStep: "sso_step"
  });
  transferExistingProperties(productData.hsc, details, {
    isTokenHscApproved: "cpa"
  });
};
var addTlsDataToDetails = (details, tlsData) => {
  transferExistingProperties(tlsData, details, {
    tlsProtocol: "tls_protocol",
    tlsServer: "tls_server",
    tlsCipher: "tls_cipher",
    tlsCiphersSha: "tls_ciphers_sha",
    tlsExtensionSha: "tls_extension_sha",
    tlsPreferredCiphers: "tls_preferred_ciphers",
    tlsJa3Fingerprint: "tls_ja3_fingerprint"
  });
};
var addServerDataToDetails = (details, serverData) => {
  transferExistingProperties(serverData, details, {
    region: "server_info_region",
    datacenter: "server_info_datacenter"
  });
};
var addRequestDataToDetails = (details, requestData) => {
  transferExistingProperties(requestData, details, {
    httpVersion: "http_version",
    method: "http_method",
    requestCookieNames: "request_cookie_names"
  });
  if (requestData.isUrlDifferentFromRawUrl) {
    details.raw_url = requestData.rawUrl;
  }
};
var addTokenDataToDetails = (details, { token, mobileData }) => {
  if (token) {
    if (token.isValidated) {
      details.px_cookie = token.payloadString;
      details.px_cookie_hmac = token.hmac;
    } else {
      details.px_orig_cookie = token.tokenString;
    }
  }
  if (mobileData) {
    transferExistingProperties(mobileData, details, {
      originalToken: "original_token",
      decodedOriginalToken: "px_decoded_original_token"
    });
    if (mobileData.originalTokenParseResult === TokenParseResult.DECRYPTION_FAILED) {
      details.original_token_error = "cookie_decryption_failed";
    } else if (mobileData.originalTokenParseResult === TokenParseResult.VALIDATION_FAILED) {
      details.original_token_error = "cookie_validation_failed";
    }
  }
};
var addRiskApiDataToAsyncActivityCommonDetails = (details, context) => {
  transferExistingProperties(context.riskApiData, details, {
    riskRtt: "risk_rtt",
    s2sCallReason: "s2s_call_reason",
    riskStartTime: "risk_start_time"
  });
  if (context.riskApiData.riskResponse?.additionalRiskInfo) {
    details.additional_risk_info = context.riskApiData.riskResponse.additionalRiskInfo;
  }
  if (context.productData[ProductName.CREDENTIAL_INTELLIGENCE]) {
    details.credentials_compromised = context.productData[ProductName.CREDENTIAL_INTELLIGENCE].isCompromised;
  }
};
var addResponseDataToAsyncActivityCommonDetails = (details, context) => {
  if (context.action !== Action.BLOCK) {
    transferExistingProperties(context.response, details, {
      status: "http_status_code"
    });
  }
};
var createPageRequestedActivityDetails = (context) => {
  const details = {};
  details.pass_reason = getReasonForHighestPriorityProduct(context.reasons);
  transferExistingProperties(context.riskApiData, details, {
    errorReason: "s2s_error_reason",
    errorHttpStatus: "s2s_error_http_status",
    errorMessage: "error_message"
  });
  return details;
};
var createBlockActivityDetails = (context) => {
  const details = {};
  details.block_reason = getReasonForHighestPriorityProduct(context.reasons);
  details.simulated_block = context.action === Action.SIMULATED_BLOCK;
  transferExistingProperties(context, details, {
    blockAction: "block_action",
    score: "block_score"
  });
  return details;
};
var createAdditionalS2SActivityDetails = ({ ciSendRawUsernameOnAdditionalS2SActivity }, { productData }) => {
  const { rawUsername, isCompromised, isLoginSuccessful } = productData.ci;
  const details = { login_successful: isLoginSuccessful };
  if (isCompromised && ciSendRawUsernameOnAdditionalS2SActivity && (isLoginSuccessful || typeof isLoginSuccessful !== "boolean")) {
    details.raw_username = rawUsername;
  }
  return details;
};
var toHeaderEntryArray = (headers) => {
  return Object.entries(headers).flatMap(([key, values]) => values.map((value) => ({
    name: key,
    value
  })));
};

// node_modules/perimeterx-js-core/lib/esm/activities/constants.js
var ACTIVITIES_ENDPOINT = "/api/v1/collector/s2s";

// node_modules/perimeterx-js-core/lib/esm/activities/HttpActivityClient.js
var HttpActivityClient = class {
  config;
  httpClient;
  constructor(config, httpClient) {
    this.config = config;
    this.httpClient = httpClient;
  }
  async sendActivities(context) {
    try {
      const activities = this.createActivities(context);
      return await this.postActivities(activities, context.logger);
    } catch (e) {
      context.logger.error(`unable to send activities - ${e}`);
      return false;
    }
  }
  createActivities(context) {
    const activities = [];
    if (this.shouldCreateBlockActivity(context)) {
      activities.push(this.createBlockActivity(context));
    }
    if (this.shouldCreatePageRequestedActivity(context)) {
      activities.push(this.createPageRequestedActivity(context));
    }
    if (this.shouldCreateAdditionalS2SActivity(context)) {
      activities.push(this.createAdditionalS2SActivity(context));
    }
    return activities.map(this.finalizeActivity);
  }
  shouldCreateBlockActivity(context) {
    return context.action === Action.BLOCK || context.action === Action.SIMULATED_BLOCK;
  }
  shouldCreatePageRequestedActivity(context) {
    return context.action === Action.PASS_REQUEST;
  }
  shouldCreateAdditionalS2SActivity(context) {
    return this.shouldCreatePageRequestedActivity(context) && context.productData.ci && this.config.ciAutomaticAdditionalS2SEnabled;
  }
  createBlockActivity(context) {
    return createAsyncActivity(ActivityType.BLOCK, this.config, context);
  }
  createPageRequestedActivity(context) {
    return createAsyncActivity(ActivityType.PAGE_REQUESTED, this.config, context);
  }
  createAdditionalS2SActivity(context) {
    return createAsyncActivity(ActivityType.ADDITIONAL_S2S, this.config, context);
  }
  /**
   * Allows for expansions or alterations to the async activity if needed.
   * @param activity
   * @returns AsyncActivity
   * @protected
   */
  finalizeActivity(activity) {
    return activity;
  }
  async postActivities(activities, logger) {
    const url = `${this.config.backendCollectorUrl}${ACTIVITIES_ENDPOINT}`;
    const method = HttpMethod.POST;
    const headers = {
      [CONTENT_TYPE_HEADER_NAME]: [ContentType.APPLICATION_JSON],
      [AUTHORIZATION_HEADER_NAME]: [getAuthorizationHeader(this.config.authToken)]
    };
    const body = activities.length === 1 ? JSON.stringify(activities[0]) : JSON.stringify(activities);
    logger.debug(`sending ${activities.map(({ type }) => `${type} activity`).join(", ")} to ${url}`);
    const req = new OutgoingRequestImpl({ url, method, headers, body });
    const res = await this.httpClient.send(req);
    return res?.status === 200;
  }
};

// node_modules/perimeterx-js-core/lib/esm/activities/HttpBatchedActivityClient.js
var HttpBatchedActivityClient = class extends HttpActivityClient {
  batchSize;
  timeoutMs;
  maxBufferSize;
  buffer;
  timeoutId;
  shouldKill;
  constructor(config, httpClient) {
    super(config, httpClient);
    this.buffer = [];
    this.batchSize = config.maxActivityBatchSize;
    this.timeoutMs = config.activityBatchTimeoutMs;
    this.maxBufferSize = this.batchSize * 2;
    this.shouldKill = false;
    this.startTimer();
  }
  stop() {
    this.shouldKill = true;
    this.stopTimer();
  }
  async postActivities(activities, logger) {
    this.addToBuffer(activities);
    return this.shouldFlush() ? this.triggerFlush(logger) : true;
  }
  addToBuffer(activities) {
    this.buffer = activities.concat(this.buffer);
    if (this.buffer.length > this.maxBufferSize) {
      this.buffer = this.buffer.slice(0, this.maxBufferSize);
    }
  }
  shouldFlush() {
    return this.buffer.length >= this.batchSize;
  }
  async triggerFlush(logger) {
    this.stopTimer();
    const sentSuccessfully = this.buffer.length > 0 && await this.flush(logger);
    if (!this.shouldKill) {
      this.startTimer();
    }
    return sentSuccessfully;
  }
  async flush(logger) {
    const bufferCopy = this.buffer.concat();
    this.clear();
    const sentSuccessfully = await super.postActivities(bufferCopy, logger);
    if (!sentSuccessfully) {
      this.buffer = this.buffer.concat(bufferCopy);
    }
    return sentSuccessfully;
  }
  clear() {
    this.buffer = [];
  }
  startTimer() {
    this.timeoutId = setTimeout(() => this.triggerFlush(this.config.logger), this.timeoutMs);
  }
  stopTimer() {
    clearTimeout(this.timeoutId);
    this.timeoutId = null;
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_api/constants.js
var RISK_API_ENDPOINT = "/api/v3/risk";

// node_modules/perimeterx-js-core/lib/esm/risk_api/client/PostRiskApiClientBase.js
var PostRiskApiClientBase = class {
  config;
  httpClient;
  constructor(config, httpClient) {
    this.config = config;
    this.httpClient = httpClient;
  }
  /**
   * Builds the Risk API activity, sends the request, and returns RiskApiData with the response.
   * @param context
   * @returns Promise<RiskApiData>
   */
  async executeRiskApi(context) {
    let response, riskResponse;
    const riskApiData = { riskApiCallResult: RiskApiCallResult.NONE };
    try {
      const riskActivity = this.createRiskActivity(context);
      response = await this.sendRiskActivity(riskActivity, riskApiData, context);
      if (response?.status !== 200) {
        return await this.handleS2SError(riskApiData, response);
      }
      riskResponse = this.createRiskResponse(response);
      riskApiData.riskResponse = riskResponse;
      if (!await riskResponse.validate()) {
        return await this.handleS2SError(riskApiData, response);
      }
      context.logger.debug(`received risk response, score: ${riskResponse.score}, rtt: ${riskApiData.riskRtt}`);
      return riskApiData;
    } catch (err) {
      if (err.name === EnforcerErrorName.ENFORCER_TIMEOUT_ERROR) {
        return this.handleS2STimeout(riskApiData);
      }
      context.logger.error(`caught error in risk api: ${err} - ${JSON.stringify(context.requestData.url)}`);
      return await this.handleS2SError(riskApiData, response, err);
    }
  }
  /**
   * Creates the RiskActivity payload
   * @param context
   * @returns RiskActivity
   * @protected
   */
  createRiskActivity(context) {
    const riskActivity = {
      vid: context.vid,
      client_uuid: context.uuid,
      pxhd: context.pxhd?.value,
      request: {
        socket_ip: context.requestData.ip,
        headers: this.formatRiskHeadersField(context.requestData.headers),
        url: context.requestData.url.href
      },
      additional: {
        ...createCommonActivityDetails(this.config, context),
        s2s_call_reason: context.riskApiData.s2sCallReason,
        risk_start_time: context.riskApiData.riskStartTime
      }
    };
    return this.finalizeRiskActivity(riskActivity);
  }
  /**
   * Protected function in case expansions or alterations to the risk activity are needed for certain platforms.
   * @param riskActivity
   * @returns RiskActivity
   * @protected
   */
  finalizeRiskActivity(riskActivity) {
    return riskActivity;
  }
  formatRiskHeadersField(headers) {
    const headersWithoutSensitive = removeSensitiveHeaders(headers, this.config.sensitiveHeaders);
    return toHeaderEntryArray(headersWithoutSensitive);
  }
  async sendRiskActivity(riskActivity, riskApiData, context) {
    const url = this.getRiskUrl();
    const headers = this.getRiskHeaders();
    const body = JSON.stringify(riskActivity);
    const method = HttpMethod.POST;
    const riskRequest = new OutgoingRequestImpl({ url, method, headers, body });
    context.logger.debug(`sending risk api to ${url}`);
    const startTime = Date.now();
    const response = await this.httpClient.send(riskRequest, { timeoutMs: this.config.s2sTimeout });
    const endTime = Date.now();
    riskApiData.riskApiCallResult = RiskApiCallResult.SUCCESSFUL;
    riskApiData.riskRtt = endTime - startTime;
    return response;
  }
  getRiskUrl() {
    return `${this.config.backendScoreApiUrl}${RISK_API_ENDPOINT}`;
  }
  getRiskHeaders() {
    return {
      [CONTENT_TYPE_HEADER_NAME]: [ContentType.APPLICATION_JSON],
      [AUTHORIZATION_HEADER_NAME]: [getAuthorizationHeader(this.config.authToken)]
    };
  }
  handleS2STimeout(riskApiData) {
    riskApiData.riskApiCallResult = RiskApiCallResult.TIMEOUT;
    return riskApiData;
  }
  async handleS2SError(riskApiData, response, error) {
    riskApiData.riskApiCallResult = RiskApiCallResult.ERROR;
    riskApiData.errorReason = S2SErrorReason.UNKNOWN_ERROR;
    if (response || riskApiData.riskResponse) {
      riskApiData.errorHttpStatus = response.status;
      riskApiData.errorMessage = riskApiData.riskResponse?.message || `response body: ${await response.text()}`;
      if (response.status === 200) {
        if (riskApiData.riskResponse?.status === RiskStatus.FAILURE) {
          riskApiData.errorReason = S2SErrorReason.REQUEST_FAILED_ON_SERVER;
        } else if (!await riskApiData.riskResponse?.validate()) {
          riskApiData.errorReason = S2SErrorReason.INVALID_RESPONSE;
        }
      } else if (response.status >= 400 && response.status < 500) {
        riskApiData.errorReason = S2SErrorReason.BAD_REQUEST;
      } else if (response.status >= 500 && response.status < 600) {
        riskApiData.errorReason = S2SErrorReason.SERVER_ERROR;
      }
    }
    if (error) {
      const errorMessage = `${error}`;
      const existingMessage = riskApiData.errorMessage;
      riskApiData.errorMessage = existingMessage ? `${existingMessage}, ${errorMessage}` : errorMessage;
    }
    return riskApiData;
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_api/client/PostRiskApiClientV2.js
var PostRiskApiClientV2 = class extends PostRiskApiClientBase {
  constructor(config, httpClient) {
    super(config, httpClient);
  }
  createRiskResponse(response) {
    return new DefaultRiskResponseV2(response);
  }
};

// node_modules/perimeterx-js-core/lib/esm/risk_api/client/PostRiskApiClientV3.js
var PostRiskApiClientV3 = class extends PostRiskApiClientBase {
  constructor(config, httpClient) {
    super(config, httpClient);
  }
  createRiskResponse(response) {
    return new DefaultRiskResponseV3(response);
  }
};

// node_modules/perimeterx-js-core/lib/esm/sensitive_request/SensitiveRequestUtils.js
var SensitiveRequestUtils;
(function(SensitiveRequestUtils2) {
  SensitiveRequestUtils2.isSensitiveRequest = async (config, context) => {
    return SensitiveRequestUtils2.isSensitiveRoute(context.requestData.url, config.sensitiveRoutes) || SensitiveRequestUtils2.isSensitiveGraphqlOperation(context.graphqlData) || await SensitiveRequestUtils2.invokeCustomIsSensitiveRequest(config, context);
  };
  SensitiveRequestUtils2.isSensitiveRoute = (url, sensitiveRoutes) => {
    return isRouteInPatterns(url.pathname, sensitiveRoutes);
  };
  SensitiveRequestUtils2.isSensitiveGraphqlOperation = (graphQLData) => {
    return !!graphQLData?.some((operation) => operation.sensitive);
  };
  SensitiveRequestUtils2.invokeCustomIsSensitiveRequest = async (config, context) => {
    if (config.customIsSensitiveRequest && typeof config.customIsSensitiveRequest === "function") {
      try {
        return await config.customIsSensitiveRequest(context.requestData.request.getUnderlyingRequest());
      } catch (err) {
        context.logger.debug(`caught custom sensitive request error - ${err}`);
      }
    }
    return false;
  };
})(SensitiveRequestUtils || (SensitiveRequestUtils = {}));

// node_modules/perimeterx-js-core/lib/esm/monitored_request/MonitoredRequestUtils.js
var MonitoredRequestUtils;
(function(MonitoredRequestUtils2) {
  MonitoredRequestUtils2.isMonitoredRequest = async (config, context) => {
    const { url, request } = context.requestData;
    const isEnforcedRequest = MonitoredRequestUtils2.isEnforcedRoute(url, config.enforcedRoutes) || await MonitoredRequestUtils2.invokeCustomIsEnforcedRequest(config, context);
    const monitoredRoute = !isEnforcedRequest && (MonitoredRequestUtils2.isMonitoredRoute(url, config.monitoredRoutes) || await MonitoredRequestUtils2.invokeCustomIsMonitoredRequest(config, context));
    const monitorMode = !isEnforcedRequest && config.moduleMode === ModuleMode.MONITOR;
    return (monitorMode || monitoredRoute) && !MonitoredRequestUtils2.isAllowedToBypassMonitor(config.bypassMonitorHeader, request);
  };
  MonitoredRequestUtils2.isMonitoredRoute = (url, isMonitoredRoute) => {
    return isRouteInPatterns(url.pathname, isMonitoredRoute);
  };
  MonitoredRequestUtils2.isEnforcedRoute = (url, enforcedRoutes) => {
    return isRouteInPatterns(url.pathname, enforcedRoutes);
  };
  MonitoredRequestUtils2.invokeCustomIsEnforcedRequest = async (config, context) => {
    if (config.customIsEnforcedRequest && typeof config.customIsEnforcedRequest === "function") {
      try {
        return await config.customIsEnforcedRequest(context.requestData.request.getUnderlyingRequest());
      } catch (err) {
        context.logger.debug(`caught custom enforced request error - ${err}`);
      }
    }
    return false;
  };
  MonitoredRequestUtils2.invokeCustomIsMonitoredRequest = async (config, context) => {
    if (config.customIsMonitoredRequest && typeof config.customIsMonitoredRequest === "function") {
      try {
        return await config.customIsMonitoredRequest(context.requestData.request.getUnderlyingRequest());
      } catch (err) {
        context.logger.debug(`caught custom monitored request error - ${err}`);
      }
    }
    return false;
  };
  MonitoredRequestUtils2.isAllowedToBypassMonitor = (bypassMonitorHeader, request) => {
    return !!bypassMonitorHeader && request.headers.get(bypassMonitorHeader) === BYPASS_MONITOR_HEADER_VALUE;
  };
})(MonitoredRequestUtils || (MonitoredRequestUtils = {}));

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/block/captcha/JsonCaptchaBlocker.js
var JsonCaptchaBlocker = class extends JsonBlockerBase {
  config;
  base64Utils;
  constructor(config, base64Utils) {
    super();
    this.config = config;
    this.base64Utils = base64Utils;
  }
  shouldBlock(context) {
    if (!this.config.advancedBlockingResponseEnabled) {
      return false;
    }
    return context.blockAction !== BlockAction.RATE_LIMIT && super.shouldBlock(context);
  }
  createJsonPayload(context) {
    const blockData = createBlockData(this.config, context, this.base64Utils);
    return {
      appId: blockData.appId,
      jsClientSrc: blockData.jsClientSrc,
      customLogo: blockData.customLogo,
      firstPartyEnabled: blockData.firstPartyEnabled,
      vid: blockData.vid,
      uuid: blockData.uuid,
      hostUrl: blockData.hostUrl,
      blockScript: blockData.blockScript,
      altBlockScript: blockData.altBlockScript
    };
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/block/templates/captcha_template.js
var CAPTCHA_TEMPLATE = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="px-captcha">
    <title>Access to this page has been denied</title>
    {{cssRef}}
</head>
<body>
<script>
    /* PerimeterX assignments */
    window._pxVid = '{{vid}}';
    window._pxUuid = '{{uuid}}';
    window._pxAppId = '{{appId}}';
    window._pxHostUrl = '{{hostUrl}}';
    window._pxCustomLogo = '{{customLogo}}';
    window._pxJsClientSrc = '{{jsClientSrc}}';
    window._pxMobile = {{isMobile}};
    window._pxFirstPartyEnabled = {{firstPartyEnabled}};
    var pxCaptchaSrc = '{{blockScript}}';
    var script = document.createElement('script');
    script.src = pxCaptchaSrc;
    script.onload = onScriptLoad;
    script.onerror = onScriptError;
    var onScriptErrorCalled;
    document.head.appendChild(script);
    var timeoutID = setTimeout(onScriptError, 5000);
    function onScriptLoad() {
        clearTimeout(timeoutID);
        setTimeout(function() {
            if (isCaptchaNotLoaded()) {
                onScriptError();
            }
        }, 1000);
    }
    function onScriptError() {
        if (onScriptErrorCalled) {
            return;
        }
        onScriptErrorCalled = true;
        script = document.createElement('script');
        script.src = '{{altBlockScript}}';
        script.onload = function() {
            clearTimeout(timeoutID);
        };
        script.onerror = window._pxOnError;
        document.head.appendChild(script);
        timeoutID = setTimeout(function() {
            if (isCaptchaNotLoaded()) {
                window._pxOnError();
            }
        }, 5000);
    }
    function isCaptchaNotLoaded() {
        return !document.querySelector('div');
    }
    window._pxOnError = function () {
        var style = document.createElement('style');
        style.innerText = '@import url(https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap);body{background-color:#fafbfc}.px-captcha-error-container{position:fixed;height:340px;background-color:#fff;font-family:Roboto,sans-serif}.px-captcha-error-header{color:#f0f1f2;font-size:29px;margin:67px 0 33px;font-weight:500;line-height:.83;text-align:center}.px-captcha-error-message{color:#f0f1f2;font-size:18px;margin:0 0 29px;line-height:1.33;text-align:center}.px-captcha-error-button{text-align:center;line-height:48px;width:253px;margin:auto;border-radius:50px;border:solid 1px #f0f1f2;font-size:20px;color:#f0f1f2}.px-captcha-error-wrapper{margin:18px 0 0}div.px-captcha-error{margin:auto;text-align:center;width:400px;height:30px;font-size:12px;background-color:#fcf0f2;color:#ce0e2d}img.px-captcha-error{margin:6px 8px -2px 0}.px-captcha-error-refid{border-top:solid 1px #f0eeee;height:27px;margin:13px 0 0;border-radius:0 0 3px 3px;background-color:#fafbfc;font-size:10px;line-height:2.5;text-align:center;color:#b1b5b8}@media (min-width:620px){.px-captcha-error-container{width:530px;top:50%;left:50%;margin-top:-170px;margin-left:-265px;border-radius:3px;box-shadow:0 2px 9px -1px rgba(0,0,0,.13)}}@media (min-width:481px) and (max-width:620px){.px-captcha-error-container{width:85%;top:50%;left:50%;margin-top:-170px;margin-left:-42.5%;border-radius:3px;box-shadow:0 2px 9px -1px rgba(0,0,0,.13)}}@media (max-width:480px){body{background-color:#fff}.px-captcha-error-header{color:#f0f1f2;font-size:29px;margin:55px 0 33px}.px-captcha-error-container{width:530px;top:50%;left:50%;margin-top:-170px;margin-left:-265px}.px-captcha-error-refid{position:fixed;width:100%;left:0;bottom:0;border-radius:0;font-size:14px;line-height:2}}@media (max-width:390px){div.px-captcha-error{font-size:10px}.px-captcha-error-refid{font-size:11px;line-height:2.5}}';
        document.head.appendChild(style);
        var div = document.createElement('div');
        div.className = 'px-captcha-error-container';
        div.innerHTML = '<div class="px-captcha-error-header">Before we continue...</div><div class="px-captcha-error-message">Press & Hold to confirm you are<br>a human (and not a bot).</div><div class="px-captcha-error-button">Press & Hold</div><div class="px-captcha-error-wrapper"><div class="px-captcha-error"><img class="px-captcha-error" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAAQCAMAAADDGrRQAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAABFUExURUdwTNYELOEGONQILd0AONwALtwEL+AAL9MFLfkJSNQGLdMJLdQJLdQGLdQKLtYFLNcELdUGLdcBL9gFL88OLdUFLNEOLglBhT4AAAAXdFJOUwC8CqgNIRgRoAS1dWWuR4RTjzgryZpYblfkcAAAAI9JREFUGNNdj+sWhCAIhAdvqGVa1r7/oy6RZ7eaH3D4ZACBIed9wlOOMtUnSrEmZ6cHa9YAIfsbCkWrdpi/c50Bk2CO9mNLdMAu03wJA3HpEnfpxbyOg6ruyx8JJi6KNstnslp1dbPd9GnqmuYq7mmcv1zjnbQw8cV0xzkqo+fX1zkjUOO7wnrInUTxJiruC3vtBNRoQQn2AAAAAElFTkSuQmCC">Please check your internet connection' + (window._pxMobile ? '' : ' or disable your ad-blocker') + '.</div></div><div class="px-captcha-error-refid">Reference ID ' + window._pxUuid + '</div>';
        document.body.appendChild(div);
        if (window._pxMobile) {
            setTimeout(function() {
                location.href = '/px/captcha_close?status=-1';
            }, 5000);
        }
    };
</script>
{{jsRef}}
</body>
</html>
`;

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/block/templates/rate_limit_template.js
var RATE_LIMIT_TEMPLATE = `<html>
<head>
    <title>Too Many Requests</title>
</head>
<body>
    <h1>Too Many Requests</h1>
    <p>Reached maximum requests limitation, try again soon.</p>
</body>
</html>
`;

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/block/captcha/MobileCaptchaBlocker.js
var MobileCaptchaBlocker = class extends MobileBlocker {
  constructor(config, base64Utils) {
    super(config, base64Utils, CAPTCHA_TEMPLATE);
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/block/captcha/HtmlCaptchaBlocker.js
var HtmlCaptchaBlocker = class extends BlockerBase {
  config;
  base64Utils;
  constructor(config, base64Utils) {
    super(ContentType.TEXT_HTML);
    this.config = config;
    this.base64Utils = base64Utils;
  }
  createBlockBody(context) {
    return renderHtml(CAPTCHA_TEMPLATE, createBlockData(this.config, context, this.base64Utils));
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/block/captcha/CaptchaBlocker.js
var CaptchaBlocker = class {
  config;
  jsonCaptchaBlocker;
  mobileCaptchaBlocker;
  htmlCaptchaBlocker;
  constructor(config, base64Utils) {
    this.config = config;
    this.jsonCaptchaBlocker = new JsonCaptchaBlocker(config, base64Utils);
    this.mobileCaptchaBlocker = new MobileCaptchaBlocker(config, base64Utils);
    this.htmlCaptchaBlocker = new HtmlCaptchaBlocker(config, base64Utils);
  }
  createBlockResponse(context) {
    if (this.mobileCaptchaBlocker.shouldBlock(context)) {
      return this.mobileCaptchaBlocker.createBlockResponse(context);
    }
    if (this.jsonCaptchaBlocker.shouldBlock(context)) {
      return this.jsonCaptchaBlocker.createBlockResponse(context);
    }
    return this.htmlCaptchaBlocker.createBlockResponse(context);
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/block/DefaultBotDefenderBlocker.js
var DefaultBotDefenderBlocker = class {
  config;
  captchaBlocker;
  constructor(config, base64Utils) {
    this.config = config;
    this.captchaBlocker = new CaptchaBlocker(config, base64Utils);
  }
  shouldBlock({ action, reasons, productData }) {
    return action === Action.BLOCK && !!reasons?.[ProductName.BOT_DEFENDER];
  }
  createBlockResponse(context) {
    switch (context.blockAction) {
      case BlockAction.RATE_LIMIT:
        return this.createRateLimitResponse();
      case BlockAction.CHALLENGE:
      case BlockAction.CAPTCHA:
      default:
        return this.createCaptchaResponse(context);
    }
  }
  createRateLimitResponse() {
    const status = 429;
    const headers = {
      [CONTENT_TYPE_HEADER_NAME]: [ContentType.TEXT_HTML]
    };
    return new MinimalResponseImpl({
      body: RATE_LIMIT_TEMPLATE,
      status,
      headers
    });
  }
  createCaptchaResponse(context) {
    return this.captchaBlocker.createBlockResponse(context);
  }
};

// node_modules/perimeterx-js-core/lib/esm/filter/FilterReason.js
var FilterReason;
(function(FilterReason2) {
  FilterReason2["NONE"] = "";
  FilterReason2["ROUTE"] = "route";
  FilterReason2["EXTENSION"] = "extension";
  FilterReason2["HTTP_METHOD"] = "http_method";
  FilterReason2["USER_AGENT"] = "user_agent";
  FilterReason2["IP"] = "ip";
  FilterReason2["CUSTOM"] = "custom";
  FilterReason2["TELEMETRY_REQUEST"] = "telemetry_request";
  FilterReason2["CORS_PREFLIGHT_REQUEST"] = "cors_preflight_request";
})(FilterReason || (FilterReason = {}));

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/filter/DefaultBotDefenderFilter.js
var DefaultBotDefenderFilter = class {
  config;
  ipRangeChecker;
  constructor(config, ipRangeChecker) {
    this.config = config;
    this.ipRangeChecker = ipRangeChecker;
  }
  async shouldFilter(context) {
    const filterReason = await this.getFilterReason(context);
    if (filterReason !== FilterReason.NONE) {
      context.logger.debug(`filter request due to ${filterReason}`);
      return true;
    }
    return false;
  }
  async getFilterReason(context) {
    const { requestData } = context;
    if (this.shouldFilterByExtension(requestData)) {
      return FilterReason.EXTENSION;
    }
    if (this.shouldFilterByRoute(requestData.url.pathname)) {
      return FilterReason.ROUTE;
    }
    if (this.shouldFilterByHttpMethod(requestData.method)) {
      return FilterReason.HTTP_METHOD;
    }
    if (this.shouldFilterByUserAgent(requestData.userAgent)) {
      return FilterReason.USER_AGENT;
    }
    if (this.shouldFilterByIp(requestData.ip)) {
      return FilterReason.IP;
    }
    if (await this.shouldFilterByCustomFunction(context)) {
      return FilterReason.CUSTOM;
    }
    return FilterReason.NONE;
  }
  shouldFilterByExtension(requestData) {
    if (requestData.method !== HttpMethod.GET && requestData.method !== HttpMethod.HEAD) {
      return false;
    }
    const ext = getExtension(requestData.url.href);
    return !!ext && this.config.filteredExtensions.includes(ext);
  }
  shouldFilterByHttpMethod(method) {
    return this.config.filteredHttpMethods.some((filteredMethod) => filteredMethod.toUpperCase() === method);
  }
  shouldFilterByIp(ip) {
    return this.config.filteredIps.some((range) => this.ipRangeChecker.isIpInRange(ip, range));
  }
  shouldFilterByRoute(route) {
    return isRouteInPatterns(route, this.config.filteredRoutes);
  }
  shouldFilterByUserAgent(userAgent) {
    return this.config.filteredUserAgents.includes(userAgent);
  }
  async shouldFilterByCustomFunction(context) {
    if (this.config.customIsFilteredRequest && typeof this.config.customIsFilteredRequest === "function") {
      try {
        return await this.config.customIsFilteredRequest(context.requestData.request.getUnderlyingRequest());
      } catch (err) {
        context.logger.debug(`caught custom filtered request error - ${err}`);
      }
    }
    return false;
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/first_party/FirstPartySuffix.js
var FirstPartySuffix;
(function(FirstPartySuffix2) {
  FirstPartySuffix2["SENSOR"] = "/init.js";
  FirstPartySuffix2["CAPTCHA"] = "/captcha";
  FirstPartySuffix2["XHR"] = "/xhr";
})(FirstPartySuffix || (FirstPartySuffix = {}));

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/first_party/utils.js
var getAllFirstPartyPaths = (config, suffix) => {
  const allPaths = [getFirstPartyPath(getDefaultFirstPartyPrefix(config.appId), suffix)];
  if (config.customFirstPartyPrefix) {
    allPaths.push(getFirstPartyPath(config.customFirstPartyPrefix, suffix));
  }
  const customEndpoint = getCustomEndpointFromFirstPartySuffix(config, suffix);
  if (customEndpoint) {
    allPaths.push(customEndpoint);
  }
  return allPaths;
};
var getCustomEndpointFromFirstPartySuffix = (config, suffix) => {
  switch (suffix) {
    case FirstPartySuffix.CAPTCHA:
      return config.customFirstPartyCaptchaEndpoint;
    case FirstPartySuffix.SENSOR:
      return config.customFirstPartySensorEndpoint;
    case FirstPartySuffix.XHR:
      return config.customFirstPartyXhrEndpoint;
    default:
      return "";
  }
};
var getMostCustomizedFirstPartyPath = (config, suffix) => {
  const customEndpoint = getCustomEndpointFromFirstPartySuffix(config, suffix);
  if (customEndpoint) {
    return customEndpoint;
  }
  if (config.customFirstPartyPrefix) {
    return getFirstPartyPath(config.customFirstPartyPrefix, suffix);
  }
  return getFirstPartyPath(getDefaultFirstPartyPrefix(config.appId), suffix);
};
var getFirstPartySensorScriptPaths = (config) => {
  return getAllFirstPartyPaths(config, FirstPartySuffix.SENSOR);
};
var getFirstPartyCaptchaScriptPathPrefixes = (config) => {
  return getAllFirstPartyPaths(config, FirstPartySuffix.CAPTCHA);
};
var getFirstPartyXhrPathPrefixes = (config) => {
  return getAllFirstPartyPaths(config, FirstPartySuffix.XHR);
};
var getDefaultFirstPartyPrefix = (appId) => appId.substring(2);
var getFirstPartyPath = (prefix, suffix) => `${addInitialSlashIfNeeded(prefix)}${suffix}`;
var addInitialSlashIfNeeded = (path) => path.startsWith("/") ? path : `/${path}`;

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/first_party/constants.js
var X_PX_ENFORCER_TRUE_IP_HEADER_NAME = "x-px-enforcer-true-ip";
var FIRST_PARTY_HEADER_NAME = "x-px-first-party";
var FIRST_PARTY_HEADER_VALUE = "1";
var DEFAULT_CLIENT_RESPONSE_OPTIONS = {
  body: "",
  status: 200,
  headers: {
    [CONTENT_TYPE_HEADER_NAME]: [ContentType.APPLICATION_JAVASCRIPT]
  }
};
var DEFAULT_XHR_RESPONSE = {
  content: "{}",
  options: {
    status: 200,
    headers: {
      [CONTENT_TYPE_HEADER_NAME]: [ContentType.APPLICATION_JAVASCRIPT]
    }
  }
};
var DEFAULT_GIF_RESPONSE = {
  content: "GIF89a\0\0\x80\0\0\xFF\xFF\xFF\0\0\0,\0\0\0\0\0\0\0D\0;",
  options: {
    status: 200,
    headers: {
      [CONTENT_TYPE_HEADER_NAME]: [ContentType.IMAGE_GIF]
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/first_party/DefaultBotDefenderFirstParty.js
var DefaultBotDefenderFirstParty = class _DefaultBotDefenderFirstParty {
  config;
  urlUtils;
  constructor(config, options) {
    this.config = config;
    this.urlUtils = options.urlUtils;
  }
  async handleFirstPartyRequest(context) {
    const { pathname } = context.requestData.url;
    if (getFirstPartySensorScriptPaths(this.config).includes(pathname)) {
      return await this.proxySensorScriptRequest(context);
    }
    const xhrPrefix = getFirstPartyXhrPathPrefixes(this.config).find((prefix) => pathname.startsWith(prefix));
    if (xhrPrefix) {
      return await this.proxyXhrRequest(context, xhrPrefix);
    }
    const captchaPrefix = getFirstPartyCaptchaScriptPathPrefixes(this.config).find((prefix) => pathname.startsWith(prefix));
    if (captchaPrefix) {
      return await this.proxyCaptchaScriptRequest(context);
    }
    return null;
  }
  async proxySensorScriptRequest(context) {
    const defaultResponse = new MinimalResponseImpl(DEFAULT_CLIENT_RESPONSE_OPTIONS);
    if (!this.config.firstPartyEnabled) {
      return { defaultResponse };
    }
    const url = this.getThirdPartySensorScriptUrl(context);
    if (!url) {
      return { defaultResponse };
    }
    const request = await this.getOutgoingRequest(url, context);
    context.logger.debug(`proxying first party sensor script ${context.requestData.url.pathname} to ${url}`);
    return { request, defaultResponse };
  }
  async proxyXhrRequest(context, prefix) {
    const defaultResponse = _DefaultBotDefenderFirstParty.getDefaultXhrResponse(context.requestData.url.pathname);
    if (!this.config.firstPartyEnabled) {
      return { defaultResponse };
    }
    const url = this.getThirdPartyXhrUrl(context, prefix);
    if (!url) {
      return { defaultResponse };
    }
    const request = await this.getOutgoingRequest(url, context);
    context.logger.debug(`proxying first party XHR request ${context.requestData.url.pathname} to ${url}`);
    return { request, defaultResponse };
  }
  static getDefaultXhrResponse(path) {
    const { content, options } = path.endsWith(".gif") ? DEFAULT_GIF_RESPONSE : DEFAULT_XHR_RESPONSE;
    return new MinimalResponseImpl({
      body: content,
      status: options.status,
      headers: options.headers
    });
  }
  async proxyCaptchaScriptRequest(context) {
    const defaultResponse = new MinimalResponseImpl(DEFAULT_CLIENT_RESPONSE_OPTIONS);
    if (!this.config.firstPartyEnabled) {
      return { defaultResponse };
    }
    const url = this.getThirdPartyCaptchaScriptUrl(context);
    if (!url) {
      return { defaultResponse };
    }
    const request = await this.getOutgoingRequest(url, context);
    context.logger.debug(`proxying first party captcha script ${context.requestData.url.pathname} to ${url}`);
    return { request, defaultResponse };
  }
  async getOutgoingRequest(url, context) {
    return new OutgoingRequestImpl({
      url: url.href,
      method: context.requestData.method,
      headers: this.prepareFirstPartyHeaders(url, context),
      body: context.requestData.request.body
    });
  }
  prepareFirstPartyHeaders(url, context) {
    const { requestData, vid } = context;
    let headers = toMutableHeaders(requestData.headers);
    try {
      headers = removeSensitiveHeaders(headers, this.config.sensitiveHeaders);
      this.setHostHeader(headers, url);
      this.setXffHeader(headers, requestData.ip);
      this.addFirstPartyHeaders(headers, requestData.ip);
      if (vid) {
        const newCookies = (headers[COOKIE_HEADER_NAME] || []).concat([`pxvid=${vid}`]);
        headers[COOKIE_HEADER_NAME] = [newCookies.join("; ")];
      }
    } catch (e) {
      context.logger.error(`Caught error preparing first party headers: ${e}`);
    }
    return headers;
  }
  setHostHeader(headers, url) {
    headers[HOST_HEADER_NAME] = [url.host];
  }
  setXffHeader(headers, ip) {
    const xffValue = headers[X_FORWARDED_FOR_HEADER_NAME] || [];
    headers[X_FORWARDED_FOR_HEADER_NAME] = xffValue.concat([ip]);
  }
  addFirstPartyHeaders(headers, ip) {
    headers[FIRST_PARTY_HEADER_NAME] = [FIRST_PARTY_HEADER_VALUE];
    headers[X_PX_ENFORCER_TRUE_IP_HEADER_NAME] = [ip];
  }
  getThirdPartySensorScriptUrl(context) {
    try {
      return this.urlUtils.createUrl(`${this.config.backendClientUrl}/${this.config.appId}/main.min.js`);
    } catch (e) {
      context.logger.debug(`unable to create third party sensor URL: ${e}`);
      return null;
    }
  }
  getThirdPartyCaptchaScriptUrl(context) {
    try {
      const originalUrl = context.requestData.url;
      const { appId, backendCaptchaUrl } = this.config;
      return this.urlUtils.createUrl(`${backendCaptchaUrl}/${appId}${FirstPartySuffix.CAPTCHA}.js${originalUrl.search}`);
    } catch (e) {
      context.logger.debug(`unable to create third party captcha URL: ${e}`);
      return null;
    }
  }
  getThirdPartyXhrUrl(context, prefix) {
    try {
      const originalUrl = context.requestData.url;
      const pathname = originalUrl.pathname.replace(prefix, "");
      const thirdPartyUrl = this.urlUtils.createUrl(`${this.config.backendCollectorUrl}${pathname}${originalUrl.search}`);
      const { host } = this.urlUtils.createUrl(this.config.backendCollectorUrl);
      if (!this.isValidThirdPartyUrl(thirdPartyUrl, host, pathname)) {
        context.logger.debug(`invalid third party url: ${thirdPartyUrl}`);
        return null;
      }
      return thirdPartyUrl;
    } catch (e) {
      context.logger.debug(`unable to create third party XHR URL: ${e}`);
      return null;
    }
  }
  isValidThirdPartyUrl(url, expectedHost, expectedPath) {
    return url.host.toLowerCase() === expectedHost.toLowerCase() && url.pathname.startsWith(expectedPath);
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/reasons/BotDefenderBlockReason.js
var BotDefenderBlockReason;
(function(BotDefenderBlockReason2) {
  BotDefenderBlockReason2["S2S_HIGH_SCORE"] = "s2s_high_score";
  BotDefenderBlockReason2["COOKIE_HIGH_SCORE"] = "cookie_high_score";
})(BotDefenderBlockReason || (BotDefenderBlockReason = {}));

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/reasons/BotDefenderPassReason.js
var BotDefenderPassReason;
(function(BotDefenderPassReason2) {
  BotDefenderPassReason2["COOKIE"] = "cookie";
  BotDefenderPassReason2["S2S"] = "s2s";
  BotDefenderPassReason2["S2S_ERROR"] = "s2s_error";
  BotDefenderPassReason2["S2S_TIMEOUT"] = "s2s_timeout";
})(BotDefenderPassReason || (BotDefenderPassReason = {}));

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/reasons/BotDefenderS2SCallReason.js
var BotDefenderS2SCallReason;
(function(BotDefenderS2SCallReason2) {
  BotDefenderS2SCallReason2["COOKIE_EXPIRED"] = "cookie_expired";
  BotDefenderS2SCallReason2["COOKIE_DECRYPTION_FAILED"] = "cookie_decryption_failed";
  BotDefenderS2SCallReason2["COOKIE_VALIDATION_FAILED"] = "cookie_validation_failed";
  BotDefenderS2SCallReason2["NO_COOKIE_WITH_VID"] = "no_cookie_w_vid";
  BotDefenderS2SCallReason2["NO_COOKIE"] = "no_cookie";
  BotDefenderS2SCallReason2["SENSITIVE_ROUTE"] = "sensitive_route";
  BotDefenderS2SCallReason2["MOBILE_ERROR_NO_COOKIE"] = "mobile_error_1";
  BotDefenderS2SCallReason2["MOBILE_ERROR_CONNECTION_ERROR"] = "mobile_error_2";
  BotDefenderS2SCallReason2["MOBILE_ERROR_CERTIFICATE_PINNING_ERROR"] = "mobile_error_3";
  BotDefenderS2SCallReason2["MOBILE_ERROR_BYPASS"] = "mobile_error_4";
})(BotDefenderS2SCallReason || (BotDefenderS2SCallReason = {}));

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/BotDefenderActionData.js
var BotDefenderActionData = class {
  action;
  reason;
  constructor(action, reason) {
    this.action = action;
    this.reason = reason;
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/BotDefenderUtils.js
var BotDefenderUtils;
(function(BotDefenderUtils2) {
  BotDefenderUtils2.getS2SCallReasonFromMobileError = (mobileError) => {
    switch (mobileError) {
      case MobileError.NO_COOKIE:
        return BotDefenderS2SCallReason.MOBILE_ERROR_NO_COOKIE;
      case MobileError.CONNECTION_ERROR:
        return BotDefenderS2SCallReason.MOBILE_ERROR_CONNECTION_ERROR;
      case MobileError.CERTIFICATE_PINNING_ERROR:
        return BotDefenderS2SCallReason.MOBILE_ERROR_CERTIFICATE_PINNING_ERROR;
      case MobileError.BYPASS:
        return BotDefenderS2SCallReason.MOBILE_ERROR_BYPASS;
      default:
        return `mobile_error_${mobileError}`;
    }
  };
})(BotDefenderUtils || (BotDefenderUtils = {}));

// node_modules/perimeterx-js-core/lib/esm/products/bot_defender/BotDefender.js
var BotDefender = class {
  config;
  firstParty;
  filter;
  blocker;
  constructor(config, options) {
    this.config = config;
    this.firstParty = options.firstParty ?? new DefaultBotDefenderFirstParty(config, { urlUtils: options.urlUtils });
    this.filter = options.filter ?? new DefaultBotDefenderFilter(config, options.ipRangeChecker);
    this.blocker = options.blocker ?? new DefaultBotDefenderBlocker(config, options.base64Utils);
  }
  async handleFirstPartyRequest(context) {
    return this.firstParty.handleFirstPartyRequest(context);
  }
  async shouldFilter(context) {
    return this.filter.shouldFilter(context);
  }
  async enrichContextFromRequest(context) {
    const isMonitoredRequest = await MonitoredRequestUtils.isMonitoredRequest(this.config, context);
    const isSensitiveRequest = await SensitiveRequestUtils.isSensitiveRequest(this.config, context);
    const actionData = await this.getTokenAction(context, isMonitoredRequest, isSensitiveRequest);
    return {
      ...actionData,
      isMonitoredRequest,
      isSensitiveRequest
    };
  }
  async enrichContextFromResponse(context) {
    return;
  }
  async getTokenAction(context, isMonitoredRequest, isSensitiveRequest) {
    switch (context.tokenData.tokenParseResult) {
      case TokenParseResult.NONE:
        return new BotDefenderActionData(Action.TRIGGER_RISK_API, this.getNoTokenS2SCallReason(context));
      case TokenParseResult.DECRYPTION_FAILED:
        return new BotDefenderActionData(Action.TRIGGER_RISK_API, BotDefenderS2SCallReason.COOKIE_DECRYPTION_FAILED);
      case TokenParseResult.VALIDATION_FAILED:
        return new BotDefenderActionData(Action.TRIGGER_RISK_API, BotDefenderS2SCallReason.COOKIE_VALIDATION_FAILED);
      case TokenParseResult.SUCCESSFUL:
        return this.getActionForSuccessfulTokenParse(context, isMonitoredRequest, isSensitiveRequest);
    }
  }
  getNoTokenS2SCallReason({ pxhd, isMobile, tokenData }) {
    if (isMobile && tokenData.mobileData?.mobileError) {
      return BotDefenderUtils.getS2SCallReasonFromMobileError(tokenData.mobileData.mobileError);
    }
    if (pxhd) {
      return BotDefenderS2SCallReason.NO_COOKIE_WITH_VID;
    }
    return BotDefenderS2SCallReason.NO_COOKIE;
  }
  getActionForSuccessfulTokenParse({ tokenData: { token } }, isMonitoredRequest, isSensitiveRequest) {
    if (token.isExpired()) {
      return new BotDefenderActionData(Action.TRIGGER_RISK_API, BotDefenderS2SCallReason.COOKIE_EXPIRED);
    }
    if (token.isHighScore()) {
      return new BotDefenderActionData(isMonitoredRequest ? Action.SIMULATED_BLOCK : Action.BLOCK, BotDefenderBlockReason.COOKIE_HIGH_SCORE);
    }
    if (isSensitiveRequest) {
      return new BotDefenderActionData(Action.TRIGGER_RISK_API, BotDefenderS2SCallReason.SENSITIVE_ROUTE);
    }
    return new BotDefenderActionData(Action.PASS_REQUEST, BotDefenderPassReason.COOKIE);
  }
  async enrichContextFromRiskApi(context) {
    return await this.getRiskApiActionData(context);
  }
  async getRiskApiActionData({ riskApiData, productData: { bd } }) {
    switch (riskApiData.riskApiCallResult) {
      case RiskApiCallResult.NONE:
        throw new EnforcerError("risk api call result should not be none!");
      case RiskApiCallResult.ERROR:
        return new BotDefenderActionData(Action.PASS_REQUEST, BotDefenderPassReason.S2S_ERROR);
      case RiskApiCallResult.TIMEOUT:
        return new BotDefenderActionData(Action.PASS_REQUEST, BotDefenderPassReason.S2S_TIMEOUT);
      case RiskApiCallResult.SUCCESSFUL:
        return this.getSuccessfulRiskApiAction(riskApiData.riskResponse, bd.isMonitoredRequest);
    }
  }
  getSuccessfulRiskApiAction(riskResponse, isMonitored) {
    if (riskResponse.score >= this.config.blockingScore) {
      return new BotDefenderActionData(isMonitored ? Action.SIMULATED_BLOCK : Action.BLOCK, BotDefenderBlockReason.S2S_HIGH_SCORE);
    }
    return new BotDefenderActionData(Action.PASS_REQUEST, BotDefenderPassReason.S2S);
  }
  shouldBlock(context) {
    return this.blocker.shouldBlock(context);
  }
  createBlockResponse(context) {
    return this.blocker.createBlockResponse(context);
  }
  async modifyIncomingRequest(context) {
  }
  async modifyOutgoingResponse(context) {
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/CredentialEndpoint.js
var CredentialEndpoint = class {
  matcher;
  extractor;
  protocol;
  loginSuccessfulParser;
  constructor(config, matcher, extractor, protocol, loginSuccessfulParser) {
    this.matcher = matcher;
    this.extractor = extractor;
    this.protocol = protocol;
    this.loginSuccessfulParser = loginSuccessfulParser;
  }
  matches(requestData) {
    return this.matcher.matches(requestData);
  }
  async getCredentialData(context) {
    try {
      const credentials = await this.extractor.extractCredentials(context.requestData.request);
      if (!credentials?.user && !credentials?.pass) {
        context.logger.debug("unable to extract credentials");
        return null;
      }
      context.logger.debug(`successfully extracted credentials`);
      return await this.protocol.hashCredentials(credentials);
    } catch (e) {
      context.logger.debug(`caught error extracting credentials: ${e}`);
      return null;
    }
  }
  async isLoginSuccessful(context) {
    try {
      return this.loginSuccessfulParser.isLoginSuccessful(context.response);
    } catch (e) {
      context.logger.debug(`caught error determining login successful: ${e}`);
      return null;
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/CredentialEndpointManager.js
var CredentialEndpointManager = class {
  config;
  endpoints;
  constructor(endpoints) {
    this.endpoints = endpoints;
  }
  getEndpointIndex({ requestData }) {
    return this.endpoints.findIndex((endpoint) => endpoint.matches(requestData));
  }
  async getCredentialsData(endpointIndex, context) {
    return await this.endpoints[endpointIndex]?.getCredentialData(context);
  }
  async isLoginSuccessful(endpointIndex, context) {
    if (!context.response) {
      return void 0;
    }
    return await this.endpoints[endpointIndex]?.isLoginSuccessful(context);
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/matcher/ExactPathEndpointMatcher.js
var ExactPathEndpointMatcher = class {
  pathname;
  method;
  constructor(pathname, method) {
    this.pathname = pathname;
    this.method = method;
  }
  matches({ method, url }) {
    return method === this.method && url.pathname === this.pathname;
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/matcher/RegexPathEndpointMatcher.js
var RegexPathEndpointMatcher = class {
  pathnameRegex;
  method;
  constructor(pathname, method) {
    this.pathnameRegex = pathname;
    this.method = method;
  }
  matches({ method, url }) {
    return method === this.method && this.pathnameRegex.test(url.pathname);
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/matcher/PathType.js
var PathType;
(function(PathType2) {
  PathType2["EXACT"] = "exact";
  PathType2["REGEX"] = "regex";
})(PathType || (PathType = {}));

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/matcher/CredentialIntelligenceEndpointMatcherFactory.js
var CredentialIntelligenceEndpointMatcherFactory = class {
  static create({ path_type, path, method }) {
    switch (path_type) {
      case PathType.REGEX:
        return new RegexPathEndpointMatcher(new RegExp(path), method.toUpperCase());
      case PathType.EXACT:
      default:
        return new ExactPathEndpointMatcher(path, method.toUpperCase());
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/extractor/BodyCredentialExtractor.js
var BodyCredentialExtractor = class {
  userField;
  passField;
  constructor(userField, passField) {
    this.userField = userField;
    this.passField = passField;
  }
  async extractCredentials(request) {
    const contentType = request.headers.get(CONTENT_TYPE_HEADER_NAME);
    if (!contentType) {
      throw new EnforcerError("cannot extract credentials from body without content-type!");
    }
    const credentials = await this.extractFromBody(contentType, request);
    return typeof credentials?.user === "string" || typeof credentials?.pass === "string" ? credentials : null;
  }
  async extractFromBody(contentType, request) {
    if (contentType.includes("json")) {
      return this.extractFromJson(await request.json());
    } else if (contentType.includes(ContentType.APPLICATION_X_WWW_FORM_URL_ENCODED)) {
      return this.extractFromUrlEncoded(await request.formUrlEncoded());
    } else if (contentType.includes(ContentType.MULTIPART_FORM_DATA)) {
      return this.extractFromMultipart(await request.formData());
    }
    return null;
  }
  extractFromJson(json) {
    if (!json) {
      return null;
    }
    const user = getPropertyFromObject(json, ...this.userField.split("."));
    const pass = getPropertyFromObject(json, ...this.passField.split("."));
    return { user, pass };
  }
  extractFromUrlEncoded(params) {
    const user = params.get(this.userField);
    const pass = params.get(this.passField);
    return { user, pass };
  }
  extractFromMultipart(formData) {
    const user = this.formDataEntryValueToString(formData.get(this.userField));
    const pass = this.formDataEntryValueToString(formData.get(this.passField));
    return { user, pass };
  }
  formDataEntryValueToString(entry) {
    return typeof entry === "string" ? entry : null;
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/extractor/CustomCredentialExtractor.js
var CustomCredentialExtractor = class {
  callback;
  constructor(callback) {
    this.callback = callback;
  }
  async extractCredentials(request) {
    return this.callback(request.getUnderlyingRequest());
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/extractor/SentThrough.js
var SentThrough;
(function(SentThrough2) {
  SentThrough2["BODY"] = "body";
  SentThrough2["HEADER"] = "header";
  SentThrough2["QUERY_PARAM"] = "query-param";
  SentThrough2["CUSTOM"] = "custom";
})(SentThrough || (SentThrough = {}));

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/extractor/HeaderCredentialExtractor.js
var HeaderCredentialExtractor = class {
  userField;
  passField;
  constructor(userField, passField) {
    this.userField = userField;
    this.passField = passField;
  }
  extractCredentials(request) {
    const user = request.headers.get(this.userField);
    const pass = request.headers.get(this.passField);
    return typeof user === "string" || typeof pass === "string" ? { user, pass } : null;
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/extractor/QueryParamCredentialExtractor.js
var QueryParamCredentialExtractor = class {
  userField;
  passField;
  urlUtils;
  constructor(userField, passField, urlUtils) {
    this.userField = userField;
    this.passField = passField;
    this.urlUtils = urlUtils;
  }
  async extractCredentials(request) {
    const { searchParams } = this.urlUtils.createUrl(request.url);
    if (!searchParams) {
      return null;
    }
    const user = searchParams.get(this.userField);
    const pass = searchParams.get(this.passField);
    return typeof user === "string" || typeof pass === "string" ? { user, pass } : null;
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/extractor/CredentialExtractorFactory.js
var CredentialExtractorFactory = class {
  static create(endpointConfig, urlUtils) {
    const { extract_credentials_callback, sent_through, user_field, pass_field } = endpointConfig;
    switch (sent_through) {
      case SentThrough.CUSTOM:
        return new CustomCredentialExtractor(extract_credentials_callback);
      case SentThrough.HEADER:
        return new HeaderCredentialExtractor(user_field, pass_field);
      case SentThrough.QUERY_PARAM:
        return new QueryParamCredentialExtractor(user_field, pass_field, urlUtils);
      case SentThrough.BODY:
      default:
        return new BodyCredentialExtractor(user_field, pass_field);
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/hash_protocol/SsoStep.js
var SsoStep;
(function(SsoStep2) {
  SsoStep2["USER"] = "user";
  SsoStep2["PASS"] = "pass";
})(SsoStep || (SsoStep = {}));

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/hash_protocol/CredentialIntelligenceVersion.js
var CredentialIntelligenceVersion;
(function(CredentialIntelligenceVersion2) {
  CredentialIntelligenceVersion2["SINGLE_STEP"] = "v2";
  CredentialIntelligenceVersion2["MULTI_STEP"] = "multistep_sso";
  CredentialIntelligenceVersion2["BOTH"] = "both";
})(CredentialIntelligenceVersion || (CredentialIntelligenceVersion = {}));

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/hash_protocol/MultistepHashProtocol.js
var MultistepHashProtocol = class {
  hashUtils;
  constructor(hashUtils) {
    this.hashUtils = hashUtils;
  }
  async hashCredentials({ user, pass }) {
    const rawUsername = user ?? null;
    const hashedPassword = typeof pass === "string" ? await this.hashUtils.hashString(pass, Algorithm.SHA256) : null;
    return {
      rawUsername,
      hashedUsername: rawUsername,
      hashedPassword,
      ciVersion: CredentialIntelligenceVersion.MULTI_STEP,
      ssoStep: user ? SsoStep.USER : SsoStep.PASS
    };
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/hash_protocol/SingleStepHashProtocol.js
var SingleStepHashProtocol = class {
  hashUtils;
  constructor(hashUtils) {
    this.hashUtils = hashUtils;
  }
  async hashCredentials({ user, pass }) {
    const normalizedUsername = isEmailAddress(user) ? this.normalizeEmailAddress(user) : user;
    const hashedUsername = await this.sha256(normalizedUsername);
    const hashedPassword = await this.sha256(hashedUsername + await this.sha256(pass));
    return {
      ciVersion: CredentialIntelligenceVersion.SINGLE_STEP,
      rawUsername: user,
      hashedUsername,
      hashedPassword
    };
  }
  normalizeEmailAddress(emailAddress) {
    const lowercaseEmail = emailAddress.trim().toLowerCase();
    const atIndex = lowercaseEmail.indexOf("@");
    const domain = lowercaseEmail.substring(atIndex);
    let normalizedUsername = lowercaseEmail.substring(0, atIndex);
    const plusIndex = normalizedUsername.indexOf("+");
    if (plusIndex > -1) {
      normalizedUsername = normalizedUsername.substring(0, plusIndex);
    }
    const GMAIL_DOMAIN = "@gmail.com";
    if (domain === GMAIL_DOMAIN) {
      normalizedUsername = normalizedUsername.replace(".", "");
    }
    return `${normalizedUsername}${domain}`;
  }
  async sha256(text) {
    return await this.hashUtils.hashString(text, Algorithm.SHA256);
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/hash_protocol/SingleStepAndMultistepHashProtocol.js
var SingleStepAndMultistepHashProtocol = class {
  singleStepHashProtocol;
  multistepHashProtocol;
  constructor(singleStepHashProtocol, multistepHashProtocol) {
    this.singleStepHashProtocol = singleStepHashProtocol;
    this.multistepHashProtocol = multistepHashProtocol;
  }
  async hashCredentials(credentials) {
    if (credentials.user && credentials.pass) {
      return this.singleStepHashProtocol.hashCredentials(credentials);
    } else {
      return this.multistepHashProtocol.hashCredentials(credentials);
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/hash_protocol/CredentialIntelligenceHashProtocolFactory.js
var CredentialIntelligenceHashProtocolFactory = class {
  static create(protocol, hashUtils) {
    switch (protocol) {
      case CredentialIntelligenceVersion.MULTI_STEP:
        return new MultistepHashProtocol(hashUtils);
      case CredentialIntelligenceVersion.SINGLE_STEP:
        return new SingleStepHashProtocol(hashUtils);
      case CredentialIntelligenceVersion.BOTH:
      default:
        return new SingleStepAndMultistepHashProtocol(new SingleStepHashProtocol(hashUtils), new MultistepHashProtocol(hashUtils));
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/login_successful/StatusLoginSuccessfulParser.js
var StatusLoginSuccessfulParser = class {
  statuses;
  constructor(statuses) {
    this.statuses = statuses;
  }
  async isLoginSuccessful(response) {
    return this.statuses.includes(response.status);
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/login_successful/BodyLoginSuccessfulParser.js
var BodyLoginSuccessfulParser = class {
  bodyRegex;
  constructor(regex) {
    this.bodyRegex = new RegExp(regex);
  }
  async isLoginSuccessful(response) {
    return this.bodyRegex.test(response.body);
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/login_successful/HeaderLoginSuccessfulParser.js
var HeaderLoginSuccessfulParser = class {
  headerName;
  headerValue;
  constructor(headerName, headerValue) {
    this.headerName = headerName;
    this.headerValue = headerValue || null;
  }
  async isLoginSuccessful(response) {
    if (this.headerValue) {
      return response.headers.get(this.headerName) === this.headerValue;
    }
    return response.headers.has(this.headerName);
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/login_successful/CustomLoginSuccessfulParser.js
var CustomLoginSuccessfulParser = class {
  callback;
  constructor(callback) {
    this.callback = callback;
  }
  async isLoginSuccessful(response) {
    try {
      const retVal = await this.callback(response.getUnderlyingResponse());
      return typeof retVal === "boolean" ? retVal : null;
    } catch {
      return null;
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/login_successful/LoginSuccessfulReportingMethod.js
var LoginSuccessfulReportingMethod;
(function(LoginSuccessfulReportingMethod2) {
  LoginSuccessfulReportingMethod2["BODY"] = "body";
  LoginSuccessfulReportingMethod2["STATUS"] = "status";
  LoginSuccessfulReportingMethod2["HEADER"] = "header";
  LoginSuccessfulReportingMethod2["CUSTOM"] = "custom";
})(LoginSuccessfulReportingMethod || (LoginSuccessfulReportingMethod = {}));

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/endpoint/login_successful/LoginSuccessfulParserFactory.js
var LoginSuccessfulParserFactory = class {
  static create(config, endpointConfig) {
    const { ciDefaultLoginSuccessfulReportingMethod, ciDefaultLoginSuccessfulBodyRegex, ciDefaultLoginSuccessfulStatus, ciDefaultLoginSuccessfulCustomCallback, ciDefaultLoginSuccessfulHeaderName, ciDefaultLoginSuccessfulHeaderValue } = config;
    const { login_successful_reporting_method, login_successful_callback, login_successful_statuses, login_successful_body_regex, login_successful_header_name, login_successful_header_value } = endpointConfig;
    const reportingMethod = login_successful_reporting_method ?? ciDefaultLoginSuccessfulReportingMethod ?? LoginSuccessfulReportingMethod.STATUS;
    switch (reportingMethod) {
      case LoginSuccessfulReportingMethod.BODY:
        return new BodyLoginSuccessfulParser(login_successful_body_regex ?? ciDefaultLoginSuccessfulBodyRegex);
      case LoginSuccessfulReportingMethod.CUSTOM:
        return new CustomLoginSuccessfulParser(login_successful_callback ?? ciDefaultLoginSuccessfulCustomCallback);
      case LoginSuccessfulReportingMethod.HEADER:
        return new HeaderLoginSuccessfulParser(login_successful_header_name ?? ciDefaultLoginSuccessfulHeaderName, login_successful_header_value ?? ciDefaultLoginSuccessfulHeaderValue);
      case LoginSuccessfulReportingMethod.STATUS:
        return new StatusLoginSuccessfulParser(login_successful_statuses ?? ciDefaultLoginSuccessfulStatus);
      default:
        throw new EnforcerError("unknown login successful reporting method defined");
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/constants.js
var DEFAULT_COMPROMISED_CREDENTIALS_HEADER_NAME = "px-compromised-credentials";
var COMPROMISED_CREDENTIALS_HEADER_VALUE = "1";
var ADDITIONAL_S2S_ACTIVITY_HEADER_NAME = "px-additional-activity";
var ADDITIONAL_S2S_URL_HEADER_NAME = "px-additional-activity-url";

// node_modules/perimeterx-js-core/lib/esm/products/credential_intelligence/CredentialIntelligence.js
var CredentialIntelligence = class {
  config;
  endpointManager;
  constructor(config, options) {
    this.config = config;
    this.endpointManager = new CredentialEndpointManager(this.initializeCredentialIntelligenceEndpoints(config, options));
  }
  async enrichContextFromRequest(context) {
    const endpointIndex = this.endpointManager.getEndpointIndex(context);
    if (endpointIndex === -1) {
      return null;
    }
    const data = await this.endpointManager.getCredentialsData(endpointIndex, context);
    if (!data) {
      return null;
    }
    return { ...data, endpointIndex, action: Action.TRIGGER_RISK_API, reason: "sensitive_route" };
  }
  async enrichContextFromRiskApi(context) {
    if (!context.productData.ci) {
      return;
    }
    const isCompromised = !!context.riskApiData.riskResponse?.dataEnrichment?.breached_account;
    return { action: void 0, reason: void 0, isCompromised };
  }
  async modifyIncomingRequest(context) {
    if (!context.productData.ci) {
      return;
    }
    const { productData: { ci: { isCompromised } }, requestData: { request } } = context;
    if (isCompromised) {
      this.setCompromisedCredentialHeader(request);
    }
    if (this.shouldSetAdditionalS2SActivityHeaders()) {
      this.setAdditionalS2SActivityHeaders(request, context);
    }
  }
  async enrichContextFromResponse(context) {
    if (!context.productData.ci) {
      return;
    }
    return { isLoginSuccessful: await this.isLoginSuccessful(context) };
  }
  async modifyOutgoingResponse(context) {
  }
  async isLoginSuccessful(context) {
    const { endpointIndex } = context.productData.ci;
    return await this.endpointManager.isLoginSuccessful(endpointIndex, context);
  }
  setCompromisedCredentialHeader(request) {
    request.headers.set(this.config.ciCompromisedCredentialsHeaderName, COMPROMISED_CREDENTIALS_HEADER_VALUE);
  }
  shouldSetAdditionalS2SActivityHeaders() {
    return !this.config.ciAutomaticAdditionalS2SEnabled && this.config.ciAdditionalS2SHeaderEnabled;
  }
  setAdditionalS2SActivityHeaders(request, context) {
    const activity = createAsyncActivity(ActivityType.ADDITIONAL_S2S, this.config, context);
    request.headers.set(ADDITIONAL_S2S_ACTIVITY_HEADER_NAME, JSON.stringify(activity));
    request.headers.set(ADDITIONAL_S2S_URL_HEADER_NAME, `${this.config.backendCollectorUrl}${ACTIVITIES_ENDPOINT}`);
  }
  initializeCredentialIntelligenceEndpoints(config, options) {
    return config.ciEndpoints.map((endpointConfig) => {
      const matcher = CredentialIntelligenceEndpointMatcherFactory.create(endpointConfig);
      const extractor = CredentialExtractorFactory.create(endpointConfig, options.urlUtils);
      const protocol = CredentialIntelligenceHashProtocolFactory.create(endpointConfig.protocol ?? config.ciDefaultVersion, options.hashUtils);
      const loginSuccessfulParser = LoginSuccessfulParserFactory.create(config, endpointConfig);
      return new CredentialEndpoint(config, matcher, extractor, protocol, loginSuccessfulParser);
    });
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/account_defender/constants.js
var CROSS_TAB_SESSION_COOKIE_NAME = "pxcts";

// node_modules/perimeterx-js-core/lib/esm/products/account_defender/AccountDefender.js
var AccountDefender = class {
  config;
  base64Utils;
  constructor(config, options) {
    this.config = config;
    this.base64Utils = options.base64Utils;
  }
  async enrichContextFromRequest(context) {
    const crossTabSession = context.requestData.cookies[CROSS_TAB_SESSION_COOKIE_NAME];
    const jwtData = this.getJwtData(context);
    return { crossTabSession, ...jwtData };
  }
  async enrichContextFromRiskApi(context) {
    return;
  }
  async enrichContextFromResponse(context) {
    return;
  }
  async modifyIncomingRequest(context) {
    return;
  }
  async modifyOutgoingResponse(context) {
    return;
  }
  getJwtData(context) {
    let jwtToken;
    let userIdFieldName;
    let additionalFieldNames;
    const { requestData } = context;
    if (this.config.jwtCookieName) {
      jwtToken = requestData.cookies[this.config.jwtCookieName];
      if (jwtToken) {
        userIdFieldName = this.config.jwtCookieUserIdFieldName;
        additionalFieldNames = this.config.jwtCookieAdditionalFieldNames;
      }
    }
    if (!jwtToken && this.config.jwtHeaderName) {
      jwtToken = requestData.headers[this.config.jwtHeaderName]?.[0];
      if (jwtToken) {
        userIdFieldName = this.config.jwtHeaderUserIdFieldName;
        additionalFieldNames = this.config.jwtHeaderAdditionalFieldNames;
      }
    }
    return jwtToken ? this.extractJwtData(jwtToken, userIdFieldName, additionalFieldNames, context) : null;
  }
  extractJwtData(jwt, userIdFieldName, additionalFieldNames, context) {
    try {
      const decodedJwt = this.getDecodedJwt(jwt, context);
      if (decodedJwt) {
        const appUserId = getPropertyFromObject(decodedJwt, ...userIdFieldName.split("."));
        const additionalFields = additionalFieldNames.reduce((matchedFields, fieldName) => {
          const fieldNameParts = fieldName.split(".");
          const value = getPropertyFromObject(decodedJwt, ...fieldNameParts);
          if (value) {
            matchedFields[fieldNameParts[fieldNameParts.length - 1]] = value;
          }
          return matchedFields;
        }, {});
        return { additionalFields, appUserId };
      }
    } catch (e) {
      context.logger.debug(`unable to get account defender JWT data: ${e}`);
    }
    return null;
  }
  getDecodedJwt(jwt, context) {
    try {
      const encodedPayload = jwt.split(".")?.[1];
      const base64 = encodedPayload.replace("-", "+").replace("_", "/");
      return JSON.parse(this.base64Utils.base64Decode(base64));
    } catch (e) {
      context.logger.debug(`unable to decode account defender jwt token: ${e}`);
      return null;
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/hype_sale_challenge/block/templates/hype_sale_challenge_template.js
var HYPE_SALE_CHALLENGE_TEMPLATE = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Please wait</title>
</head>
<body>
<script>
    window.frameElement.setAttribute('style', 'position: fixed; top: 0px; left: 0px; width: 100%; height: 100%; border: none; background-color: white; z-index: 2147483647;');
    window._pxAppId = '{{appId}}';
    window._pxJsClientSrc = '{{jsClientSrc}}';
    window._pxVid = '{{vid}}';
    window._pxUuid = '{{uuid}}';
    window._pxMobile = !!+'{{isMobile}}';
    var script = document.createElement('script');
    script.src = '{{jsTemplateScriptSrc}}';
    script.onerror = function () {
        if (window._pxMobile) {
            window.top.location.href = '/px/captcha_close?status=-1';
            return;
        }
        window._pxDisplayErrorMessage();
        var onFail = window.parent._pxOnHypeSaleChallengeFail;
        if (onFail) {
            onFail();
        }
    };
    document.head.appendChild(script);
    window._pxDisplayErrorMessage = function () {
        var style = document.createElement('style');
        style.innerText = '.outer-div{display:table;position:absolute;top:0;left:0;height:100%;width:100%}.inner-div{display:table-cell;vertical-align:middle;font-family:sans-serif}.cart-svg{display:block;margin:auto;padding:0 0 10px 0;opacity:.25}.progress-bar-div{width:245px;padding:20px;margin:auto;opacity:.5}.bar-span{padding:6px}.message-div{font-size:15px;text-align:center;color:#f03947;padding:0 0 95px 0}.message-p{margin:10px 80px}';
        document.head.appendChild(style);
        var div = document.createElement('div');
        div.className = 'outer-div';
        div.innerHTML = '<div class="inner-div"><div><svg class="cart-svg" xmlns="http://www.w3.org/2000/svg" width="103" height="86" viewBox="0 0 103 86"><g fill="none" fill-rule="evenodd"><path fill="#04CFFE" fill-rule="nonzero" d="M1 12c-.552 0-1 .448-1 1s.448 1 1 1h13.187l10.75 50.719c-.183.627.412 1.345 1.063 1.281h50c.528.01 1.014-.472 1.014-1s-.486-1.007-1.014-1H26.812l-2.125-10H80c.448 0 .87-.344.969-.781l7-30c.13-.58-.374-1.215-.969-1.219H17.906l-1.937-9.219c-.098-.437-.521-.778-.969-.781H1zm17.344 12H41v13H21.094l-2.75-13zM43 24h18v13H43V24zm20 0h22.75l-3.031 13H63V24zM21.5 39H41v13H24.25L21.5 39zM43 39h18v13H43V39zm20 0h19.25l-3.031 13H63V39zM36 70c-4.406 0-8 3.594-8 8 0 4.406 3.594 8 8 8 4.406 0 8-3.594 8-8 0-4.406-3.594-8-8-8zm30 0c-4.406 0-8 3.594-8 8 0 4.406 3.594 8 8 8 4.406 0 8-3.594 8-8 0-4.406-3.594-8-8-8zm-30 2c3.326 0 6 2.674 6 6s-2.674 6-6 6c-3.325 0-6-2.674-6-6s2.675-6 6-6zm30 0c3.326 0 6 2.674 6 6s-2.674 6-6 6c-3.325 0-6-2.674-6-6s2.675-6 6-6z" transform="translate(-627 -446) translate(627.005 446)"></path><g transform="translate(-627 -446) translate(627.005 446) translate(53.995)"><circle cx="24" cy="24" r="22" fill="#04CFFE" stroke="#FFF" stroke-width="4"></circle><path fill="#FFF" fill-rule="nonzero" d="M28.712 22.281v-1.664c0-2.541-2.122-4.617-4.721-4.617s-4.722 2.076-4.722 4.617v1.664C17.99 22.388 17 23.426 17 24.715v5.833C17 31.908 18.116 33 19.507 33h8.986C29.883 33 31 31.908 31 30.548v-5.833c0-1.289-1.007-2.327-2.288-2.434zm-3.623 7.48c.036.179-.092.34-.275.34H23.15c-.183 0-.311-.161-.274-.34l.549-2.112c-.458-.196-.787-.644-.787-1.18 0-.716.604-1.307 1.336-1.307.732 0 1.335.59 1.335 1.306 0 .52-.329.967-.786 1.181l.567 2.112zm1.226-7.498h-4.648v-1.628c0-1.253 1.043-2.273 2.324-2.273 1.28 0 2.324 1.02 2.324 2.273v1.628z"></path></g></g></svg></div><div class="progress-bar-div"><span class="bar-span"><svg xmlns="http://www.w3.org/2000/svg" width="69" height="7" viewBox="0 0 69 7"><g fill="none" fill-rule="evenodd"><g fill="#E0E4E5" transform="translate(-506 -142)"><rect width="69" height="7" x="506" y="142" rx="3.25"></rect></g></g></svg></span><span class="bar-span"><svg xmlns="http://www.w3.org/2000/svg" width="69" height="7" viewBox="0 0 69 7"><g fill="none" fill-rule="evenodd"><g fill="#E0E4E5" transform="translate(-506 -142)"><rect width="69" height="7" x="506" y="142" rx="3.25"></rect></g></g></svg></span><span class="bar-span"><svg xmlns="http://www.w3.org/2000/svg" width="69" height="7" viewBox="0 0 69 7"><g fill="none" fill-rule="evenodd"><g fill="#E0E4E5" transform="translate(-506 -142)"><rect width="69" height="7" x="506" y="142" rx="3.25"></rect></g></g></svg></span></div><div class="message-div"><p class="message-p">Please check your network connection</p><p class="message-p">or disable your ad-blocker.</p></div></div>';
        document.body.appendChild(div);
    };
</script>
</body>
</html>
`;

// node_modules/perimeterx-js-core/lib/esm/products/hype_sale_challenge/block/JsonHypeSaleChallengeBlocker.js
var JsonHypeSaleChallengeBlocker = class extends JsonBlockerBase {
  config;
  base64Utils;
  constructor(config, base64Utils) {
    super();
    this.config = config;
    this.base64Utils = base64Utils;
  }
  createJsonPayload(context) {
    const blockData = createBlockData(this.config, context, this.base64Utils);
    const html = renderHtml(HYPE_SALE_CHALLENGE_TEMPLATE, blockData);
    return {
      appId: this.config.appId,
      blockType: "pxHypeSaleChallenge",
      html
    };
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/hype_sale_challenge/block/MobileHypeSaleChallengeBlocker.js
var MobileHypeSaleChallengeBlocker = class extends MobileBlocker {
  constructor(config, base64Utils) {
    super(config, base64Utils, HYPE_SALE_CHALLENGE_TEMPLATE);
  }
};

// node_modules/perimeterx-js-core/lib/esm/products/hype_sale_challenge/utils.js
var X_PX_IS_HYPESALE_HEADER_NAME = "x-px-is-hypesale";
var IS_HYPESALE_PARAM_NAME = "is_hype_sale";
var SYNTHETIC_RESPONSE_DEFAULT_RESPONSE_CODE = 7190;
var addHypeSaleChallengeHeaders = (headers) => {
  return {
    ...headers,
    [X_PX_IS_HYPESALE_HEADER_NAME]: ["true"],
    [CACHE_CONTROL_HEADER_NAME]: ["no-cache, no-store"]
  };
};

// node_modules/perimeterx-js-core/lib/esm/products/hype_sale_challenge/HypeSaleChallenge.js
var HypeSaleChallenge = class {
  config;
  mobileHscBlocker;
  jsonHscBlocker;
  constructor(config, options) {
    this.config = config;
    this.mobileHscBlocker = new MobileHypeSaleChallengeBlocker(config, options.base64Utils);
    this.jsonHscBlocker = new JsonHypeSaleChallengeBlocker(config, options.base64Utils);
  }
  enrichContextFromRequest(context) {
    if (!this.isHypeSaleChallengeRequest(context)) {
      return;
    }
    const isTokenHscApproved = this.isTokenHscApproved(context.tokenData);
    return {
      isTokenHscApproved,
      isRiskResponseHscApproved: false,
      action: isTokenHscApproved ? Action.TRIGGER_RISK_API : Action.BLOCK,
      reason: "hsc_route"
    };
  }
  enrichContextFromRiskApi(context) {
    if (!this.isHypeSaleChallengeRequest(context)) {
      return;
    }
    const { isTokenHscApproved } = context.productData.hsc;
    const isRiskResponseHscApproved = this.isRiskResponseHscApproved(context.riskApiData);
    const shouldPass = isTokenHscApproved && isRiskResponseHscApproved;
    return {
      isTokenHscApproved,
      isRiskResponseHscApproved,
      action: shouldPass ? Action.PASS_REQUEST : Action.BLOCK,
      reason: shouldPass ? void 0 : "hsc_route"
    };
  }
  enrichContextFromResponse(context) {
    return;
  }
  modifyIncomingRequest(context) {
    return;
  }
  modifyOutgoingResponse(context) {
    return;
  }
  shouldBlock(context) {
    const hsc = context.productData.hsc;
    return this.isHypeSaleChallengeRequest(context) && (!hsc?.isTokenHscApproved || !hsc?.isRiskResponseHscApproved);
  }
  createBlockResponse(context) {
    const { status, body, headers } = this.mobileHscBlocker.shouldBlock(context) ? this.mobileHscBlocker.createBlockResponse(context) : this.jsonHscBlocker.createBlockResponse(context);
    return {
      status,
      body,
      headers: addHypeSaleChallengeHeaders(headers)
    };
  }
  isHypeSaleChallengeRequest({ customParameters }) {
    return customParameters?.[IS_HYPESALE_PARAM_NAME];
  }
  isTokenHscApproved({ tokenParseResult, token }) {
    return tokenParseResult === TokenParseResult.SUCCESSFUL && token?.isValidated && token.cpa;
  }
  isRiskResponseHscApproved({ riskApiCallResult, riskResponse }) {
    return riskApiCallResult === RiskApiCallResult.SUCCESSFUL && riskResponse?.drc !== SYNTHETIC_RESPONSE_DEFAULT_RESPONSE_CODE && riskResponse.action !== BlockAction.HYPE_SALE_CHALLENGE_LEGACY;
  }
};

// node_modules/perimeterx-js-core/lib/esm/action/utils.js
var getDecisionFromContext = (context) => {
  return getDecisionFromActions(getProductActions(context));
};
var getProductActions = (context) => {
  return Object.entries(context.productData).filter(([_, data]) => data?.action != null && data?.reason != null).map(([productName, data]) => ({
    action: data.action,
    reason: data.reason,
    productName
  }));
};
var getDecisionFromActions = (productActions) => {
  return createDecision(reduce(productActions));
};
var reduce = (actions) => {
  return actions.reduce((tally, { action, reason, productName }) => {
    if (!tally[action]) {
      tally[action] = {};
    }
    tally[action][productName] = reason;
    return tally;
  }, {});
};
var createDecision = (tally) => {
  for (const action of ACTION_PRIORITY_ORDER) {
    if (tally[action]) {
      return { action, reasons: tally[action] };
    }
  }
  return { action: Action.PASS_REQUEST };
};
var getReasonForHighestPriorityProduct = (reasons) => {
  return reasons[PRODUCT_PRIORITY_ORDER.find((product) => !!reasons[product])];
};

// node_modules/perimeterx-js-core/lib/esm/config/defaults/DefaultStaticConfigurationParams.js
var DEFAULT_STATIC_CONFIGURATION_PARAMS = {
  px_app_id: "",
  px_auth_token: "",
  px_cookie_secret: "",
  px_logger_auth_token: "",
  px_remote_config_auth_token: "",
  px_remote_config_secret: ""
};

// node_modules/perimeterx-js-core/lib/esm/config/defaults/DefaultRemoteConfigurationParams.js
var DEFAULT_REMOTE_CONFIGURATION_PARAMS = {
  px_remote_config_enabled: true,
  px_remote_config_id: "",
  px_remote_config_version: 0
};

// node_modules/perimeterx-js-core/lib/esm/logger/LoggerSeverity.js
var LoggerSeverity;
(function(LoggerSeverity2) {
  LoggerSeverity2["NONE"] = "none";
  LoggerSeverity2["ERROR"] = "error";
  LoggerSeverity2["DEBUG"] = "debug";
})(LoggerSeverity || (LoggerSeverity = {}));

// node_modules/perimeterx-js-core/lib/esm/logger/LoggerBase.js
var LoggerBase = class {
  loggerSeverity;
  shouldSaveLogs;
  logs;
  constructor(loggerSeverity = LoggerSeverity.ERROR, shouldSaveLogs, logs = []) {
    this.loggerSeverity = loggerSeverity;
    this.shouldSaveLogs = shouldSaveLogs;
    this.logs = logs;
  }
  debug(message, metadata) {
    this.recordLog(message, LoggerSeverity.DEBUG, metadata);
    if (this.loggerSeverity == LoggerSeverity.DEBUG) {
      this.logDebug(message);
    }
  }
  error(message, metadata) {
    this.recordLog(message, LoggerSeverity.ERROR, metadata);
    if (this.loggerSeverity != LoggerSeverity.NONE) {
      this.logError(message);
    }
  }
  getLoggerSeverity() {
    return this.loggerSeverity;
  }
  setLoggerSeverity(loggerSeverity) {
    this.loggerSeverity = loggerSeverity;
  }
  // default implementation, can be overridden
  logError(message) {
    this.log(message);
  }
  // default implementation, can be overridden
  logDebug(message) {
    this.log(message);
  }
  // default implementation, can be overridden
  getLogs() {
    return this.logs;
  }
  recordLog(message, loggerSeverity, metadata) {
    if (!this.shouldSaveLogs) {
      return;
    }
    const logRecord = {
      ...metadata,
      message,
      severity: loggerSeverity,
      messageTimestamp: Date.now()
    };
    this.logs.push(logRecord);
  }
  clearLogs() {
    this.logs = [];
  }
};

// node_modules/perimeterx-js-core/lib/esm/logger/constants.js
var X_PX_ENFORCER_LOG_HEADER = "x-px-enforcer-log";
var EXTERNAL_LOGGER_SERVICE_PATH = "/enforcer-logs/";

// node_modules/perimeterx-js-core/lib/esm/logger/HttpLogServiceClient.js
var HttpLogServiceClient = class {
  config;
  httpClient;
  constructor(config, httpClient) {
    this.config = config;
    this.httpClient = httpClient;
  }
  async sendLogs(context) {
    const logs = context.logger.getLogs();
    try {
      const logMetadata = this.getLogMetadata(context);
      const enrichedLogs = logs.map((log) => this.enrichLogRecord(log, logMetadata));
      await this.postLogs(enrichedLogs);
    } catch (e) {
      this.config.logger.error(`logs for ${context.requestId}: ${JSON.stringify(logs)}`);
      this.config.logger.error(`unable to send logs: ${e}`);
    }
  }
  getLogMetadata(context) {
    const { requestId, requestData: { method, url, rawUrl } } = context;
    const { appId, moduleVersion, remoteConfigId, remoteConfigVersion } = this.config;
    const logMetadata = {
      container: "enforcer",
      appID: appId,
      method,
      host: url.host,
      url: rawUrl,
      path: url.pathname + url.search,
      requestId,
      moduleVersion
    };
    if (remoteConfigId && remoteConfigVersion) {
      logMetadata.remoteConfigID = remoteConfigId;
      logMetadata.remoteConfigVersion = remoteConfigVersion;
    }
    return logMetadata;
  }
  enrichLogRecord(log, logMetadata) {
    return { ...logMetadata, ...log };
  }
  async postLogs(logRecords) {
    const url = `${this.config.backendScoreApiUrl}${EXTERNAL_LOGGER_SERVICE_PATH}`;
    const method = HttpMethod.POST;
    const headers = {
      [CONTENT_TYPE_HEADER_NAME]: [ContentType.APPLICATION_JSON],
      [AUTHORIZATION_HEADER_NAME]: [getAuthorizationHeader(this.config.loggerAuthToken)]
    };
    const body = JSON.stringify(logRecords);
    const req = new OutgoingRequestImpl({ url, method, headers, body });
    const res = await this.httpClient.send(req);
    return res?.status === 200;
  }
};

// node_modules/perimeterx-js-core/lib/esm/logger/DefaultLogger.js
var DefaultLogger = class extends LoggerBase {
  constructor(loggerSeverity, shouldSaveLogs) {
    super(loggerSeverity, shouldSaveLogs);
  }
  log(message) {
    console.log(message);
  }
};

// node_modules/perimeterx-js-core/lib/esm/config/defaults/DefaultCommonConfigurationParams.js
var DEFAULT_COMMON_CONFIGURATION_PARAMS = {
  px_s2s_timeout: 1e3,
  px_blocking_score: 100,
  px_user_agent_max_length: 8528,
  px_risk_cookie_max_length: 2048,
  px_risk_cookie_min_iterations: 500,
  px_risk_cookie_max_iterations: 5e3,
  px_logger_severity: LoggerSeverity.ERROR,
  px_ip_headers: [],
  px_module_enabled: true,
  px_module_mode: ModuleMode.MONITOR,
  px_additional_activity_handler: null,
  px_advanced_blocking_response_enabled: true,
  px_max_activity_batch_size: 0,
  px_batch_activities_timeout_ms: 1e3,
  px_bypass_monitor_header: "",
  px_enforced_routes: [],
  px_first_party_enabled: true,
  px_custom_first_party_prefix: "",
  px_custom_first_party_sensor_endpoint: "",
  px_custom_first_party_xhr_endpoint: "",
  px_custom_first_party_captcha_endpoint: "",
  px_first_party_timeout_ms: 4e3,
  px_backend_url: "",
  px_backend_collector_url: "",
  px_backend_captcha_url: "https://captcha.px-cdn.net",
  px_backend_client_url: "https://client.perimeterx.net",
  px_login_credentials_extraction_enabled: false,
  px_login_credentials_extraction: [],
  px_credentials_intelligence_version: CredentialIntelligenceVersion.BOTH,
  px_compromised_credentials_header: DEFAULT_COMPROMISED_CREDENTIALS_HEADER_NAME,
  px_send_raw_username_on_additional_s2s_activity: false,
  px_automatic_additional_s2s_activity_enabled: true,
  px_additional_s2s_activity_header_enabled: false,
  px_login_successful_reporting_method: LoginSuccessfulReportingMethod.STATUS,
  px_login_successful_body_regex: "",
  px_login_successful_header_name: "",
  px_login_successful_header_value: "",
  px_login_successful_status: [200],
  px_login_successful_custom_callback: null,
  px_monitored_routes: [],
  px_sensitive_headers: ["cookie", "cookies"],
  px_sensitive_routes: [],
  px_filter_by_extension: [
    ".css",
    ".bmp",
    ".tif",
    ".ttf",
    ".docx",
    ".woff2",
    ".js",
    ".pict",
    ".tiff",
    ".eot",
    ".xlsx",
    ".jpg",
    ".csv",
    ".eps",
    ".woff",
    ".xls",
    ".jpeg",
    ".doc",
    ".ejs",
    ".otf",
    ".pptx",
    ".gif",
    ".pdf",
    ".swf",
    ".svg",
    ".ps",
    ".ico",
    ".pls",
    ".midi",
    ".svgz",
    ".class",
    ".png",
    ".ppt",
    ".mid",
    ".webp",
    ".jar",
    ".json",
    ".xml"
  ],
  px_filter_by_http_method: [],
  px_filter_by_ip: [],
  px_filter_by_route: [],
  px_filter_by_user_agent: [],
  px_css_ref: "",
  px_js_ref: "",
  px_custom_cookie_header: "x-px-cookies",
  px_custom_logo: "",
  px_graphql_enabled: true,
  px_graphql_routes: ["/graphql"],
  px_sensitive_graphql_operation_names: [],
  px_sensitive_graphql_operation_types: [],
  px_enrich_custom_parameters: null,
  px_jwt_cookie_name: "",
  px_jwt_cookie_user_id_field_name: "",
  px_jwt_cookie_additional_field_names: [],
  px_jwt_header_name: "",
  px_jwt_header_user_id_field_name: "",
  px_jwt_header_additional_field_names: [],
  px_cors_support_enabled: false,
  px_cors_custom_preflight_handler: null,
  px_cors_preflight_request_filter_enabled: false,
  px_cors_create_custom_block_response_headers: null,
  px_remote_config_max_fetch_attempts: 5,
  px_remote_config_retry_interval_ms: 1e3,
  px_url_decode_reserved_characters: false,
  px_secured_pxhd_enabled: false,
  px_custom_is_sensitive_request: null,
  px_custom_is_monitored_request: null,
  px_custom_is_enforced_request: null,
  px_custom_is_filtered_request: null
};

// node_modules/perimeterx-js-core/lib/esm/config/defaults/DefaultConfigurationParams.js
var DEFAULT_CONFIGURATION_PARAMS = {
  ...DEFAULT_STATIC_CONFIGURATION_PARAMS,
  ...DEFAULT_REMOTE_CONFIGURATION_PARAMS,
  ...DEFAULT_COMMON_CONFIGURATION_PARAMS
};

// node_modules/perimeterx-js-core/lib/esm/config/ConfigurationBase.js
var ConfigurationBase = class {
  configParams;
  internalLogger;
  constructor(params, defaultParams) {
    this.configParams = this.initialize(params, {
      ...DEFAULT_CONFIGURATION_PARAMS,
      ...defaultParams
    });
    this.internalLogger = this.createInternalLogger(this.configParams.px_logger_severity);
  }
  initialize(params, defaultParams) {
    this.throwIfMissingRequiredField(params);
    const config = {};
    Object.keys(defaultParams).forEach((k) => {
      config[k] = this.getValidConfigValue(params, defaultParams, k);
    });
    return config;
  }
  throwIfMissingRequiredField(params) {
    const REQUIRED_FIELDS = ["px_app_id", "px_cookie_secret", "px_auth_token"];
    REQUIRED_FIELDS.forEach((key) => {
      if (!params[key]) {
        throw new EnforcerError(`${String(key)} cannot be empty!`);
      }
    });
  }
  getValidConfigValue(params, defaultParams, key) {
    if (params[key] != null && this.isValidConfigValue(params, defaultParams, key)) {
      return params[key];
    } else {
      return this.getDefaultConfigurationValue(params, defaultParams, key);
    }
  }
  isValidConfigValue(params, defaultParams, key) {
    switch (key) {
      case "px_logger_severity":
        return isValidEnumValue(LoggerSeverity, params[key]);
      case "px_module_mode":
        return isValidEnumValue(ModuleMode, params[key]);
      default:
        if (defaultParams[key] === null) {
          return typeof params[key] === "function";
        }
        if (Array.isArray(defaultParams[key])) {
          return Array.isArray(params[key]);
        }
        return typeof params[key] === typeof defaultParams[key];
    }
  }
  getDefaultConfigurationValue(params, defaultParams, key) {
    switch (key) {
      case "px_backend_url":
        return `https://${getScoreApiDomain(params.px_app_id)}`;
      case "px_backend_collector_url":
        return `https://${getCollectorDomain(params.px_app_id)}`;
      default:
        return defaultParams[key];
    }
  }
  createInternalLogger(loggerSeverity) {
    return new DefaultLogger(loggerSeverity, false);
  }
  toParams() {
    return Object.assign({}, this.configParams);
  }
  get moduleVersion() {
    return `${this.getModuleVersion()} (${CORE_MODULE_VERSION})`;
  }
  get logger() {
    return this.internalLogger;
  }
  get appId() {
    return this.configParams.px_app_id;
  }
  get authToken() {
    return this.configParams.px_auth_token;
  }
  get blockingScore() {
    return this.configParams.px_blocking_score;
  }
  get bypassMonitorHeader() {
    return this.configParams.px_bypass_monitor_header;
  }
  get cookieSecret() {
    return this.configParams.px_cookie_secret;
  }
  get customCookieHeader() {
    return this.configParams.px_custom_cookie_header;
  }
  get customLogo() {
    return this.configParams.px_custom_logo;
  }
  get enforcedRoutes() {
    return this.configParams.px_enforced_routes;
  }
  get customIsEnforcedRequest() {
    return this.configParams.px_custom_is_enforced_request;
  }
  get filteredExtensions() {
    return this.configParams.px_filter_by_extension.map((ext) => ext.startsWith(".") ? ext : `.${ext}`);
  }
  get filteredHttpMethods() {
    return this.configParams.px_filter_by_http_method;
  }
  get filteredIps() {
    return this.configParams.px_filter_by_ip;
  }
  get filteredRoutes() {
    return this.configParams.px_filter_by_route;
  }
  get filteredUserAgents() {
    return this.configParams.px_filter_by_user_agent;
  }
  get firstPartyEnabled() {
    return this.configParams.px_first_party_enabled;
  }
  get customIsFilteredRequest() {
    return this.configParams.px_custom_is_filtered_request;
  }
  get customFirstPartyPrefix() {
    return this.configParams.px_custom_first_party_prefix;
  }
  get customFirstPartySensorEndpoint() {
    return this.configParams.px_custom_first_party_sensor_endpoint;
  }
  get customFirstPartyXhrEndpoint() {
    return this.configParams.px_custom_first_party_xhr_endpoint;
  }
  get customFirstPartyCaptchaEndpoint() {
    return this.configParams.px_custom_first_party_captcha_endpoint;
  }
  get firstPartyTimeoutMs() {
    return this.configParams.px_first_party_timeout_ms;
  }
  get loggerSeverity() {
    return this.logger.getLoggerSeverity();
  }
  get moduleEnabled() {
    return this.configParams.px_module_enabled;
  }
  get moduleMode() {
    return this.configParams.px_module_mode;
  }
  get monitoredRoutes() {
    return this.configParams.px_monitored_routes;
  }
  get customIsMonitoredRequest() {
    return this.configParams.px_custom_is_monitored_request;
  }
  get s2sTimeout() {
    return this.configParams.px_s2s_timeout;
  }
  get sensitiveHeaders() {
    return this.configParams.px_sensitive_headers;
  }
  get sensitiveRoutes() {
    return this.configParams.px_sensitive_routes;
  }
  get customIsSensitiveRequest() {
    return this.configParams.px_custom_is_sensitive_request;
  }
  get advancedBlockingResponseEnabled() {
    return this.configParams.px_advanced_blocking_response_enabled;
  }
  get backendScoreApiUrl() {
    return this.configParams.px_backend_url;
  }
  get ipHeaders() {
    return this.configParams.px_ip_headers;
  }
  get backendCaptchaUrl() {
    return this.configParams.px_backend_captcha_url;
  }
  get backendClientUrl() {
    return this.configParams.px_backend_client_url;
  }
  get backendCollectorUrl() {
    return this.configParams.px_backend_collector_url;
  }
  get cssRef() {
    return this.configParams.px_css_ref;
  }
  get jsRef() {
    return this.configParams.px_js_ref;
  }
  get riskCookieMaxIterations() {
    return this.configParams.px_risk_cookie_max_iterations;
  }
  get riskCookieMinIterations() {
    return this.configParams.px_risk_cookie_min_iterations;
  }
  get riskCookieMaxLength() {
    return this.configParams.px_risk_cookie_max_length;
  }
  get userAgentMaxLength() {
    return this.configParams.px_user_agent_max_length;
  }
  get maxActivityBatchSize() {
    return this.configParams.px_max_activity_batch_size;
  }
  get activityBatchTimeoutMs() {
    return this.configParams.px_batch_activities_timeout_ms;
  }
  get graphqlEnabled() {
    return this.configParams.px_graphql_enabled;
  }
  get graphqlRoutes() {
    return this.configParams.px_graphql_routes;
  }
  get sensitiveGraphqlOperationNames() {
    return this.configParams.px_sensitive_graphql_operation_names;
  }
  get sensitiveGraphqlOperationTypes() {
    return this.configParams.px_sensitive_graphql_operation_types;
  }
  get enrichCustomParameters() {
    return this.configParams.px_enrich_custom_parameters || null;
  }
  get additionalActivityHandler() {
    return this.configParams.px_additional_activity_handler || null;
  }
  get altBackendCaptchaUrl() {
    return "https://captcha.px-cloud.net";
  }
  get corsSupportEnabled() {
    return this.configParams.px_cors_support_enabled;
  }
  get corsCustomPreflightHandler() {
    return this.configParams.px_cors_custom_preflight_handler || null;
  }
  get corsPreflightRequestFilterEnabled() {
    return this.configParams.px_cors_preflight_request_filter_enabled;
  }
  get corsCreateCustomBlockResponseHeaders() {
    return this.configParams.px_cors_create_custom_block_response_headers || null;
  }
  get jwtCookieAdditionalFieldNames() {
    return this.configParams.px_jwt_cookie_additional_field_names;
  }
  get jwtCookieName() {
    return this.configParams.px_jwt_cookie_name;
  }
  get jwtCookieUserIdFieldName() {
    return this.configParams.px_jwt_cookie_user_id_field_name;
  }
  get jwtHeaderAdditionalFieldNames() {
    return this.configParams.px_jwt_header_additional_field_names;
  }
  get jwtHeaderName() {
    return this.configParams.px_jwt_header_name;
  }
  get jwtHeaderUserIdFieldName() {
    return this.configParams.px_jwt_header_user_id_field_name;
  }
  get ciEnabled() {
    return this.configParams.px_login_credentials_extraction_enabled;
  }
  get loggerAuthToken() {
    return this.configParams.px_logger_auth_token;
  }
  get ciEndpoints() {
    return this.configParams.px_login_credentials_extraction;
  }
  get ciCompromisedCredentialsHeaderName() {
    return this.configParams.px_compromised_credentials_header;
  }
  get ciSendRawUsernameOnAdditionalS2SActivity() {
    return this.configParams.px_send_raw_username_on_additional_s2s_activity;
  }
  get ciAutomaticAdditionalS2SEnabled() {
    return this.configParams.px_automatic_additional_s2s_activity_enabled;
  }
  get ciAdditionalS2SHeaderEnabled() {
    return this.configParams.px_additional_s2s_activity_header_enabled;
  }
  get ciDefaultVersion() {
    return this.configParams.px_credentials_intelligence_version;
  }
  get ciDefaultLoginSuccessfulReportingMethod() {
    return this.configParams.px_login_successful_reporting_method;
  }
  get ciDefaultLoginSuccessfulStatus() {
    return this.configParams.px_login_successful_status;
  }
  get ciDefaultLoginSuccessfulBodyRegex() {
    return this.configParams.px_login_successful_body_regex;
  }
  get ciDefaultLoginSuccessfulHeaderName() {
    return this.configParams.px_login_successful_header_name;
  }
  get ciDefaultLoginSuccessfulHeaderValue() {
    return this.configParams.px_login_successful_header_value;
  }
  get ciDefaultLoginSuccessfulCustomCallback() {
    return this.configParams.px_login_successful_custom_callback;
  }
  get remoteConfigAuthToken() {
    return this.configParams.px_remote_config_auth_token;
  }
  get remoteConfigSecret() {
    return this.configParams.px_remote_config_secret;
  }
  get remoteConfigVersion() {
    return this.configParams.px_remote_config_version;
  }
  get remoteConfigId() {
    return this.configParams.px_remote_config_id;
  }
  get remoteConfigRetryIntervalMs() {
    return this.configParams.px_remote_config_retry_interval_ms;
  }
  get remoteConfigMaxFetchAttempts() {
    return this.configParams.px_remote_config_max_fetch_attempts;
  }
  get urlDecodeReservedCharacters() {
    return this.configParams.px_url_decode_reserved_characters;
  }
  get securedPxhdEnabled() {
    return this.configParams.px_secured_pxhd_enabled;
  }
};

// node_modules/perimeterx-js-core/lib/esm/config/remote_config/constants.js
var REMOTE_CONFIG_PUSH_DATA_FEATURE_NAME = "enforcer_config";
var REMOTE_CONFIG_ENDPOINT = "/config/";
var WRITE_REMOTE_CONFIG_ERROR_NAME = "write_remote_config";

// node_modules/perimeterx-js-core/lib/esm/config/remote_config/service_client/HttpRemoteConfigServiceClient.js
var HttpRemoteConfigServiceClient = class {
  config;
  httpClient;
  constructor(config, httpClient) {
    this.config = config;
    this.httpClient = httpClient;
  }
  async fetch(updateRequestData) {
    const request = this.createFetchRemoteConfigRequest(updateRequestData);
    const response = await this.httpClient.send(request);
    return this.extractConfigFromResponse(response);
  }
  createFetchRemoteConfigRequest(updateRequestData) {
    const url = `${this.config.backendScoreApiUrl}${REMOTE_CONFIG_ENDPOINT}`;
    const method = HttpMethod.GET;
    const headers = {
      [AUTHORIZATION_HEADER_NAME]: [`Bearer ${this.config.remoteConfigAuthToken}`],
      [ACCEPT_HEADER_NAME]: [ContentType.APPLICATION_JSON]
    };
    return new OutgoingRequestImpl({ url, method, headers });
  }
  extractConfigFromResponse(response) {
    return response?.json();
  }
};

// node_modules/perimeterx-js-core/lib/esm/config/remote_config/DefaultRemoteConfigUpdater.js
var DefaultRemoteConfigUpdater = class {
  config;
  serviceClient;
  storageClient;
  timestampHmacHeaderValidator;
  constructor(config, options) {
    this.config = config;
    this.serviceClient = options.serviceClient;
    this.storageClient = options.storageClient;
    this.timestampHmacHeaderValidator = options.timestampHmacHeaderValidator || new DefaultTimestampHmacHeaderValidator(config, config.remoteConfigSecret, options.base64Utils, options.hmacUtils);
  }
  isUpdateRemoteConfigRequest(context) {
    return context.isRemoteConfigUpdateRequest;
  }
  async updateRemoteConfig(context) {
    context.logger.debug("identified an update remote config request");
    const { requestData: { request } } = context;
    if (!await this.isUpdateRequestValid(request, context)) {
      return false;
    }
    const updateRequestData = await this.getUpdateRequestData(request, context);
    if (!updateRequestData) {
      return false;
    }
    const remoteConfig = await this.fetchRemoteConfig(updateRequestData, context);
    if (!remoteConfig) {
      return false;
    }
    await this.storageClient.save(remoteConfig);
    context.logger.debug(`successfully updated with remote config version ${remoteConfig.version}`);
    return true;
  }
  async isUpdateRequestValid(request, context) {
    const timestampHmacHeader = request.headers.get(PUSH_DATA_HMAC_HEADER_NAME);
    const isValid = await this.timestampHmacHeaderValidator.isValid(timestampHmacHeader, context.logger);
    if (!isValid) {
      context.logger.error(`invalid timestamp hmac header received: ${timestampHmacHeader}`, {
        errorType: WRITE_REMOTE_CONFIG_ERROR_NAME
      });
    }
    return isValid;
  }
  async getUpdateRequestData(request, context) {
    let updateRequestData;
    try {
      updateRequestData = await request.json();
    } catch (err) {
      context.logger.error(`could not parse update request body: ${err}`, {
        errorType: WRITE_REMOTE_CONFIG_ERROR_NAME
      });
      return null;
    }
    if (!updateRequestData?.version) {
      context.logger.error(`no version on update request body: ${updateRequestData}`, {
        errorType: WRITE_REMOTE_CONFIG_ERROR_NAME
      });
      return null;
    }
    return updateRequestData;
  }
  async fetchRemoteConfig(updateRequestData, context) {
    const { remoteConfigMaxFetchAttempts, remoteConfigRetryIntervalMs, remoteConfigVersion } = this.config;
    let errorText;
    let remoteConfigData;
    for (let i = 0; i < remoteConfigMaxFetchAttempts; i++) {
      try {
        remoteConfigData = await this.serviceClient.fetch(updateRequestData);
        if (remoteConfigData && this.isDesiredRemoteConfigVersion(updateRequestData, remoteConfigData)) {
          return remoteConfigData;
        } else {
          await this.sleepBetweenFetchAttempts(remoteConfigRetryIntervalMs);
        }
      } catch (err) {
        errorText = `unable to fetch remote config version ${updateRequestData.version}: ${err}`;
      }
    }
    errorText = errorText ?? `no config version ${updateRequestData.version} found after ${remoteConfigMaxFetchAttempts} attempts, current: ${remoteConfigVersion}, received: ${remoteConfigData?.version}`;
    context.logger.error(errorText, { errorType: WRITE_REMOTE_CONFIG_ERROR_NAME });
  }
  isDesiredRemoteConfigVersion({ version }, remoteConfigData) {
    return version === remoteConfigData.version;
  }
  async sleepBetweenFetchAttempts(ms) {
    await sleep(ms);
  }
};

// node_modules/perimeterx-js-core/lib/esm/config/remote_config/RemoteConfigUtils.js
var RemoteConfigUtils;
(function(RemoteConfigUtils2) {
  RemoteConfigUtils2.isRemoteConfigUpdateRequest = (request) => request.method === HttpMethod.PATCH && request.headers.get(PUSH_DATA_FEATURE_HEADER_NAME) === REMOTE_CONFIG_PUSH_DATA_FEATURE_NAME && !!request.headers.get(PUSH_DATA_HMAC_HEADER_NAME);
})(RemoteConfigUtils || (RemoteConfigUtils = {}));

// node_modules/perimeterx-js-core/lib/esm/pxhd/PXHDUtils.js
var PXHDUtils;
(function(PXHDUtils2) {
  PXHDUtils2.PXHD_SAMESITE_VALUE = "Lax";
  PXHDUtils2.PXHD_PATH_VALUE = "/";
  PXHDUtils2.addPxhdToOutgoingResponse = (config, context, response) => {
    if (!context?.pxhd) {
      return;
    }
    const setPxhdCookie = PXHDUtils2.getPxhdCookieValue(context.pxhd, config.securedPxhdEnabled);
    response.headers.append(SET_COOKIE_HEADER_NAME, setPxhdCookie);
  };
  PXHDUtils2.addPxhdToMinimalResponse = (config, context, response) => {
    if (context?.pxhd) {
      const setPxhdCookie = PXHDUtils2.getPxhdCookieValue(context.pxhd, config.securedPxhdEnabled);
      return MinimalResponseUtils.appendHeader(response, SET_COOKIE_HEADER_NAME, setPxhdCookie);
    }
    return response;
  };
  PXHDUtils2.getPxhdCookieValue = (pxhd, isSecure) => {
    const value = `${PXHD_COOKIE_NAME}=${pxhd.value}`;
    const secure = isSecure ? "Secure" : "";
    const domain = pxhd.domain && `domain=${pxhd.domain}`;
    const path = `path=${PXHDUtils2.PXHD_PATH_VALUE}`;
    const sameSite = `SameSite=${PXHDUtils2.PXHD_SAMESITE_VALUE}`;
    return [value, secure, domain, path, sameSite].filter(Boolean).join("; ");
  };
})(PXHDUtils || (PXHDUtils = {}));

// node_modules/perimeterx-js-core/lib/esm/pxhd/model/PXHDSource.js
var PXHDSource;
(function(PXHDSource2) {
  PXHDSource2["COOKIE"] = "cookie";
  PXHDSource2["RISK"] = "risk";
})(PXHDSource || (PXHDSource = {}));

// node_modules/perimeterx-js-core/lib/esm/context/DefaultContext.js
var DefaultContext = class {
  requestId;
  tokenOrigin;
  isRemoteConfigUpdateRequest;
  shouldSendLogs;
  requestData;
  tokenData;
  riskApiData;
  tlsData;
  serverData;
  productData;
  uuid;
  vid;
  vidSource;
  action;
  reasons;
  score;
  blockAction;
  pxhd;
  pxde;
  pxdeVerified;
  customParameters;
  graphqlData;
  response;
  enforcerStartTime;
  logger;
  config;
  urlUtils;
  constructor(config, request, options) {
    this.enforcerStartTime = Date.now();
    this.config = config;
    this.urlUtils = options.urlUtils;
    this.tokenData = {
      tokenParseResult: TokenParseResult.NONE
    };
    this.riskApiData = {
      riskApiCallResult: RiskApiCallResult.NONE
    };
    this.tlsData = {};
    this.serverData = {};
    this.productData = {};
    this.requestId = options.requestIdGenerator.generateRequestId();
    this.blockAction = BlockAction.CAPTCHA;
    this.pxdeVerified = false;
    this.isRemoteConfigUpdateRequest = RemoteConfigUtils.isRemoteConfigUpdateRequest(request);
    this.shouldSendLogs = this.isRemoteConfigUpdateRequest || this.isHeaderBasedLoggerRequest(config, request);
    this.logger = this.createContextLogger(config, this.shouldSendLogs);
    this.requestData = this.createRequestData(config, request, options.cookieParser);
    this.tokenOrigin = this.getTokenOrigin(request);
    if (!this.isMobile) {
      this.setCookiesOnContext();
    }
  }
  get isMobile() {
    return this.tokenOrigin === TokenOrigin.HEADER;
  }
  createContextLogger(config, shouldSaveLogs) {
    return new DefaultLogger(config.loggerSeverity, shouldSaveLogs);
  }
  createRequestData(config, request, cookieParser = new StringSplitCookieParser()) {
    const rawUrl = request.url;
    const url = this.normalizeUrl(rawUrl);
    const isUrlDifferentFromRawUrl = rawUrl !== url.href;
    const method = request.method;
    const cookies = cookieParser.parseCookies(request.headers.get(COOKIE_HEADER_NAME), request.headers.get(config.customCookieHeader));
    const requestCookieNames = Object.keys(cookies);
    const readOnlyHeaders = toReadonlyHeaders(request.headers);
    const userAgent = this.extractUserAgentFromHeader(config, readOnlyHeaders);
    const ip = this.extractIpFromHeader(config, readOnlyHeaders) || request.clientIP;
    const httpVersion = request.httpVersion;
    return {
      url,
      rawUrl,
      method,
      headers: readOnlyHeaders,
      cookies,
      ip,
      userAgent,
      requestCookieNames,
      request,
      httpVersion,
      isUrlDifferentFromRawUrl
    };
  }
  normalizeUrl(rawUrl) {
    let url = this.urlUtils.createUrl(rawUrl);
    if (this.config.urlDecodeReservedCharacters) {
      try {
        url = this.urlUtils.createUrl(`${url.origin}${this.urlUtils.decodeUriComponent(url.pathname)}${url.search}`);
      } catch (e) {
        this.logger.debug(`unable to URL decode reserved characters: ${e}`);
      }
    }
    url.pathname = url.pathname.replace(/\/+$/, "").replace(/\/+/g, "/");
    return url;
  }
  extractUserAgentFromHeader(config, headers) {
    let userAgent = headers[USER_AGENT_HEADER_NAME]?.[0] || "";
    if (userAgent.length > config.userAgentMaxLength) {
      userAgent = userAgent.substring(0, config.userAgentMaxLength);
    }
    return userAgent;
  }
  extractIpFromHeader(config, headers) {
    let ip;
    config.ipHeaders.some((ipHeader) => {
      const headerValue = headers[ipHeader]?.[0];
      if (headerValue) {
        ip = headerValue;
        return true;
      }
    });
    return ip;
  }
  getTokenOrigin(request) {
    return request.headers.get(X_PX_AUTHORIZATION_HEADER_NAME) ? TokenOrigin.HEADER : TokenOrigin.COOKIE;
  }
  setCookiesOnContext() {
    this.vid = this.requestData.cookies[PXVID_COOKIE_NAME];
    const pxhdCookie = this.requestData.cookies[PXHD_COOKIE_NAME];
    if (pxhdCookie) {
      this.pxhd = {
        value: pxhdCookie,
        source: PXHDSource.COOKIE
      };
    }
  }
  isHeaderBasedLoggerRequest(config, request) {
    return config.loggerAuthToken && config.loggerAuthToken === request.headers.get(X_PX_ENFORCER_LOG_HEADER);
  }
  toJSON() {
    return {
      action: this.action,
      reasons: this.reasons,
      isMobile: this.isMobile,
      isRemoteConfigUpdateRequest: this.isRemoteConfigUpdateRequest,
      productData: this.productData,
      requestData: {
        ...this.requestData,
        request: void 0,
        url: this.requestData.url.href
      },
      requestId: this.requestId,
      riskApiData: this.riskApiData,
      serverData: this.serverData,
      shouldSendLogs: this.shouldSendLogs,
      tlsData: this.tlsData,
      tokenData: this.tokenData,
      tokenOrigin: this.tokenOrigin,
      pxhd: this.pxhd,
      pxde: this.pxde,
      score: this.score,
      customParameters: this.customParameters,
      graphqlData: this.graphqlData,
      vid: this.vid,
      vidSource: this.vidSource,
      uuid: this.uuid,
      enforcerStartTime: this.enforcerStartTime,
      blockAction: this.blockAction,
      pxdeVerified: this.pxdeVerified
    };
  }
};

// node_modules/perimeterx-js-core/lib/esm/context/SerializedContext.js
var SerializedContext = class {
  isMobile;
  isRemoteConfigUpdateRequest;
  logger;
  productData;
  requestData;
  requestId;
  riskApiData;
  serverData;
  shouldSendLogs;
  tlsData;
  tokenData;
  enforcerStartTime;
  action;
  score;
  reasons;
  blockAction;
  pxhd;
  pxde;
  pxdeVerified;
  customParameters;
  graphqlData;
  vid;
  vidSource;
  tokenOrigin;
  uuid;
  constructor(config, contextJson, request, urlUtils) {
    this.action = contextJson.action;
    this.reasons = contextJson.reasons;
    this.isMobile = contextJson.isMobile;
    this.requestId = contextJson.requestId;
    this.isRemoteConfigUpdateRequest = contextJson.isRemoteConfigUpdateRequest;
    this.logger = this.createLogger(config, contextJson.shouldSendLogs);
    this.productData = contextJson.productData;
    this.requestData = this.createRequestData(contextJson, request, urlUtils);
    this.riskApiData = this.createRiskApiData(contextJson);
    this.serverData = contextJson.serverData;
    this.shouldSendLogs = contextJson.shouldSendLogs;
    this.tlsData = contextJson.tlsData;
    this.tokenData = this.createTokenData(contextJson, config);
    this.tokenOrigin = contextJson.tokenOrigin;
    this.uuid = contextJson.uuid;
    this.vid = contextJson.vid;
    this.vidSource = contextJson.vidSource;
    this.pxhd = contextJson.pxhd;
    this.pxde = contextJson.pxde;
    this.pxdeVerified = contextJson.pxdeVerified;
    this.score = contextJson.score;
    this.customParameters = contextJson.customParameters;
    this.graphqlData = contextJson.graphqlData;
    this.enforcerStartTime = contextJson.enforcerStartTime;
    this.blockAction = contextJson.blockAction;
  }
  createRequestData({ requestData }, request, urlUtils) {
    return {
      ...requestData,
      url: urlUtils.createUrl(requestData.url),
      request
    };
  }
  createTokenData({ tokenData }, config) {
    return {
      ...tokenData,
      token: tokenData.token ? new SerializedToken(config, tokenData.token) : void 0,
      mobileData: tokenData.mobileData ? {
        ...tokenData.mobileData,
        originalToken: tokenData.mobileData.originalToken ? new SerializedToken(config, tokenData.mobileData.originalToken) : void 0
      } : {}
    };
  }
  createRiskApiData({ riskApiData }) {
    return {
      ...riskApiData,
      riskResponse: riskApiData.riskResponse ? new SerializedRiskResponse(riskApiData.riskResponse) : void 0
    };
  }
  createLogger(config, shouldSendLogs) {
    return new DefaultLogger(config.loggerSeverity, shouldSendLogs);
  }
};

// node_modules/perimeterx-js-core/lib/esm/custom_parameters/CustomParametersUtils.js
var CustomParametersUtils;
(function(CustomParametersUtils2) {
  CustomParametersUtils2.createCustomParameters = async (config, context) => {
    if (config.enrichCustomParameters && typeof config.enrichCustomParameters === "function") {
      try {
        const parameters = await config.enrichCustomParameters(config.toParams(), context.requestData.request.getUnderlyingRequest());
        return CustomParametersUtils2.normalizeCustomParams(parameters);
      } catch (e) {
        context.logger.error(`unable to enrich custom params: ${e}`);
      }
    }
    return null;
  };
  CustomParametersUtils2.normalizeCustomParams = (customParameters) => {
    const normalizedParams = {};
    if (customParameters && typeof customParameters === "object") {
      const paramKeyRegex = /^custom_param([1-9]|10)$/;
      Object.entries(customParameters).forEach(([param, value]) => {
        if (param.match(paramKeyRegex) && value !== "") {
          normalizedParams[param] = value;
        }
      });
      if (IS_HYPESALE_PARAM_NAME in customParameters && typeof customParameters[IS_HYPESALE_PARAM_NAME] === "boolean") {
        normalizedParams[IS_HYPESALE_PARAM_NAME] = customParameters[IS_HYPESALE_PARAM_NAME];
      }
    }
    return Object.keys(normalizedParams).length === 0 ? null : normalizedParams;
  };
})(CustomParametersUtils || (CustomParametersUtils = {}));

// node_modules/perimeterx-js-core/lib/esm/cors/constants.js
var ORIGIN_HEADER = "origin";
var ACCESS_CONTROL_REQUEST_METHOD_HEADER = "access-control-request-method";

// node_modules/perimeterx-js-core/lib/esm/cors/DefaultCors.js
var DefaultCors = class {
  customBlockResponseHeaders;
  customPreflightHandler;
  logger;
  constructor(config) {
    this.customBlockResponseHeaders = config.corsCreateCustomBlockResponseHeaders;
    this.customPreflightHandler = config.corsCustomPreflightHandler;
    this.logger = config.logger;
  }
  isPreflightRequest(context) {
    const { requestData } = context;
    return !!(requestData.method.toUpperCase() === HttpMethod.OPTIONS && requestData.headers[ORIGIN_HEADER] && requestData.headers[ACCESS_CONTROL_REQUEST_METHOD_HEADER]);
  }
  async runPreflightCustomHandler(context) {
    if (this.customPreflightHandler && typeof this.customPreflightHandler === "function") {
      try {
        return await this.customPreflightHandler(context.requestData.request.getUnderlyingRequest());
      } catch (e) {
        this.logger.debug(`Exception occurred while executing custom preflight handler: ${e}`);
      }
    }
    return null;
  }
  isCorsRequest(context) {
    return !!context.requestData.headers[ORIGIN_HEADER];
  }
  async getCorsBlockHeaders(context) {
    if (this.customBlockResponseHeaders && typeof this.customBlockResponseHeaders === "function") {
      try {
        return await this.customBlockResponseHeaders(context.requestData.request.getUnderlyingRequest());
      } catch (e) {
        this.logger.debug(`Exception occurred in px_cors_create_custom_block_response_headers custom function: ${e}`);
      }
    }
    return this.getDefaultCorsHeaders(context);
  }
  getDefaultCorsHeaders(context) {
    return {
      "Access-Control-Allow-Origin": context.requestData.headers[ORIGIN_HEADER],
      "Access-Control-Allow-Credentials": ["true"]
    };
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/FirstPartyPhase.js
var FirstPartyPhase = class {
  config;
  httpClient;
  firstParties;
  constructor(config, httpClient, firstParties) {
    this.config = config;
    this.httpClient = httpClient;
    this.firstParties = firstParties;
  }
  async execute(context) {
    for (const firstParty of this.firstParties) {
      const firstPartyData = await firstParty.handleFirstPartyRequest(context);
      if (firstPartyData) {
        const response = await this.sendFirstPartyRequest(firstPartyData, context);
        return { done: true, response };
      }
    }
    return { done: false };
  }
  async sendFirstPartyRequest({ request, defaultResponse }, context) {
    if (!request) {
      context.logger.debug("no first party request provided, returning default response");
      return defaultResponse;
    }
    try {
      const response = await this.httpClient.send(request, { timeoutMs: this.config.firstPartyTimeoutMs });
      return MinimalResponseUtils.from(response);
    } catch (e) {
      context.logger.debug(`caught error, returning default first party response: ${e}`);
      return defaultResponse;
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/FilterPhase.js
var FilterPhase = class {
  filters;
  constructor(filters) {
    this.filters = filters;
  }
  async execute(context) {
    for (const filter of this.filters) {
      if (await filter.shouldFilter(context)) {
        return { done: true };
      }
    }
    return { done: false };
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/PreflightPhase.js
var PreflightPhase = class {
  corsSupportEnabled;
  filterPreflightRequestsEnabled;
  cors;
  constructor(config, cors) {
    this.corsSupportEnabled = config.corsSupportEnabled;
    this.filterPreflightRequestsEnabled = config.corsPreflightRequestFilterEnabled;
    this.cors = cors;
  }
  async execute(context) {
    if (!this.corsSupportEnabled || !this.cors.isPreflightRequest(context)) {
      return { done: false };
    }
    const response = await this.cors.runPreflightCustomHandler(context);
    if (response) {
      return { done: true, response };
    }
    return { done: this.filterPreflightRequestsEnabled };
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/TelemetryPhase.js
var TelemetryPhase = class {
  telemetry;
  constructor(telemetry) {
    this.telemetry = telemetry;
  }
  async execute(context) {
    if (await this.telemetry.isValidTelemetryRequest(context)) {
      await this.sendTelemetry(context);
      return { done: true };
    }
    return { done: false };
  }
  // Note: If await is not necessary, can be overridden
  async sendTelemetry(context) {
    await this.telemetry.sendTelemetry(context);
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/DecideActionPhase.js
var DecideActionPhase = class {
  async updateContextDecision(context) {
    const { action, reasons } = getDecisionFromContext(context);
    if (context.logger.getLoggerSeverity() === LoggerSeverity.DEBUG) {
      const productReasons = Object.entries(reasons).map(([prod, reason]) => `${prod} -> ${reason}`).join(", ");
      context.logger.debug(`decision: ${action}, reasons: ${productReasons}`);
    }
    context.action = action;
    context.reasons = reasons;
    this.modifyBlockActionIfNeeded(context);
  }
  modifyBlockActionIfNeeded(context) {
    const isHypeSaleChallengeBlock = context.reasons.hsc && (context.action === Action.BLOCK || context.action === Action.SIMULATED_BLOCK);
    if (isHypeSaleChallengeBlock) {
      context.blockAction = BlockAction.HYPE_SALE_CHALLENGE;
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/EnrichContextFromRequestPhase.js
var EnrichContextFromRequestPhase = class extends DecideActionPhase {
  config;
  products;
  dataEnrichment;
  graphQLParser;
  constructor(config, products, dataEnrichment, graphQLParser) {
    super();
    this.config = config;
    this.products = products;
    this.dataEnrichment = dataEnrichment;
    this.graphQLParser = graphQLParser;
  }
  async execute(context) {
    context.logger.debug("enrich context from request phase");
    await this.addPxdeToContext(context);
    await this.addGraphQLDataToContext(context);
    await this.addCustomParametersToContext(context);
    await this.addProductDataToContext(context);
    await this.updateContextDecision(context);
    return { done: false };
  }
  async addPxdeToContext(context) {
    const pxdeData = await this.dataEnrichment.handlePxde(context);
    if (pxdeData) {
      context.pxde = pxdeData.pxde;
      context.pxdeVerified = pxdeData.pxdeVerified;
    }
  }
  async addGraphQLDataToContext(context) {
    if (this.graphQLParser?.isGraphQLRequest(context)) {
      context.graphqlData = await this.graphQLParser.parseGraphQLRequest(context);
    }
  }
  async addProductDataToContext(context) {
    await Promise.all(Object.entries(this.products).map(async ([name, product]) => {
      context.productData[name] = await product?.enrichContextFromRequest(context);
    }));
  }
  async addCustomParametersToContext(context) {
    context.customParameters = await CustomParametersUtils.createCustomParameters(this.config, context);
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/ParseTokenPhase.js
var ParseTokenPhase = class {
  tokenParser;
  constructor(tokenParser) {
    this.tokenParser = tokenParser;
  }
  async execute(context) {
    const tokenData = await this.tokenParser.parseToken(context);
    this.addTokenDataToContext(context, tokenData);
    return { done: false };
  }
  addTokenDataToContext(context, tokenData) {
    Object.assign(context.tokenData, tokenData);
    if (tokenData.tokenParseResult === TokenParseResult.SUCCESSFUL) {
      transferExistingProperties(tokenData.token, context, {
        vid: "vid",
        uuid: "uuid",
        score: "score",
        action: "blockAction"
      });
      if (tokenData.token.vid) {
        context.vidSource = VidSource.RISK_COOKIE;
      }
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/RiskApiPhase.js
var RiskApiPhase = class extends DecideActionPhase {
  products;
  riskApiClient;
  constructor(config, products, riskApiClient) {
    super();
    this.products = products;
    this.riskApiClient = riskApiClient;
  }
  async execute(context) {
    if (this.shouldTriggerRiskApi(context)) {
      await this.triggerRiskApi(context);
      await this.enrichContextFromRiskApi(context);
      await this.updateContextDecision(context);
    }
    return { done: false };
  }
  shouldTriggerRiskApi(context) {
    return context.action === Action.TRIGGER_RISK_API;
  }
  async triggerRiskApi(context) {
    context.riskApiData.s2sCallReason = getReasonForHighestPriorityProduct(context.reasons);
    context.riskApiData.riskStartTime = Date.now();
    const riskApiData = await this.riskApiClient.executeRiskApi(context);
    Object.assign(context.riskApiData, riskApiData);
  }
  async enrichContextFromRiskApi(context) {
    this.addRiskApiDataToContext(context);
    await this.enrichContextWithProductDataFromRiskApi(context);
  }
  addRiskApiDataToContext(context) {
    const { riskResponse } = context.riskApiData;
    if (!riskResponse) {
      return;
    }
    transferExistingProperties(riskResponse, context, {
      score: "score",
      uuid: "uuid",
      action: "blockAction",
      dataEnrichment: "pxde"
    });
    if (riskResponse.dataEnrichment) {
      context.pxdeVerified = true;
    }
    if (riskResponse.pxhd) {
      context.pxhd = {
        value: riskResponse.pxhd,
        domain: riskResponse.pxhdDomain,
        source: PXHDSource.RISK
      };
    }
  }
  async enrichContextWithProductDataFromRiskApi(context) {
    await Promise.all(Object.entries(this.products).map(async ([name, product]) => {
      if (context.productData[name]) {
        Object.assign(context.productData[name], await product?.enrichContextFromRiskApi(context));
      }
    }));
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/CreateBlockResponsePhase.js
var CreateBlockResponsePhase = class {
  config;
  blockers;
  cors;
  constructor(config, blockers, cors) {
    this.config = config;
    this.blockers = blockers;
    this.cors = cors;
  }
  async execute(context) {
    if (context.action !== Action.BLOCK) {
      return { done: false };
    }
    context.logger.debug("create block response phase");
    let response = this.createBlockResponse(context);
    if (!response) {
      return { done: false };
    }
    response = await this.addHeadersToResponse(response, context);
    return { done: true, response };
  }
  createBlockResponse(context) {
    let response = null;
    for (const name of PRODUCT_PRIORITY_ORDER) {
      if (context.reasons[name]) {
        const blocker = this.blockers[name];
        if (blocker?.shouldBlock(context)) {
          context.logger.debug(`returning ${name} block response`);
          response = blocker.createBlockResponse(context);
          break;
        }
      }
    }
    return response;
  }
  async addHeadersToResponse(response, context) {
    if (!context.isMobile && context.pxhd?.source === PXHDSource.RISK) {
      response = PXHDUtils.addPxhdToMinimalResponse(this.config, context, response);
    }
    if (this.config.corsSupportEnabled && this.cors?.isCorsRequest(context)) {
      const corsHeaders = await this.cors.getCorsBlockHeaders(context);
      response = MinimalResponseUtils.appendHeaders(response, corsHeaders);
    }
    return response;
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/ModifyIncomingRequestPhase.js
var ModifyIncomingRequestPhase = class {
  products;
  constructor(products) {
    this.products = products;
  }
  async execute(context) {
    await Promise.all(this.products.map((product) => product?.modifyIncomingRequest(context)));
    return { done: false };
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/EnrichContextFromResponsePhase.js
var EnrichContextFromResponsePhase = class {
  config;
  products;
  constructor(config, products) {
    this.config = config;
    this.products = products;
  }
  async execute(context) {
    context.logger.debug("enrich context from response phase");
    await this.addProductDataToContext(context);
    return { done: false };
  }
  async addProductDataToContext(context) {
    await Promise.all(Object.entries(this.products).filter(([name, _]) => !!context.productData[name]).map(async ([name, product]) => {
      Object.assign(context.productData[name], await product?.enrichContextFromResponse(context));
    }));
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/ModifyOutgoingResponsePhase.js
var ModifyOutgoingResponsePhase = class {
  config;
  products;
  constructor(config, products) {
    this.config = config;
    this.products = products;
  }
  async execute(context) {
    await Promise.all(this.products.map((product) => product?.modifyOutgoingResponse(context)));
    if (context.pxhd?.source === PXHDSource.RISK) {
      PXHDUtils.addPxhdToOutgoingResponse(this.config, context, context.response);
    }
    return { done: false };
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/AdditionalActivityHandlerPhase.js
var AdditionalActivityHandlerPhase = class {
  config;
  constructor(config) {
    this.config = config;
  }
  async execute(context) {
    await AdditionalActivityHandlerUtils.invokeAdditionalActivityHandler(this.config, context);
    return { done: false };
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/CompositePhase.js
var CompositePhase = class {
  phases;
  constructor(phases) {
    this.phases = phases;
  }
  async execute(context) {
    let result;
    for (const phase of this.phases) {
      result = await phase.execute(context);
      if (result.done) {
        break;
      }
    }
    return result;
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/SendLogsPhase.js
var SendLogsPhase = class {
  config;
  logServiceClient;
  constructor(config, logServiceClient) {
    this.config = config;
    this.logServiceClient = logServiceClient;
  }
  async execute(context) {
    if (context.shouldSendLogs) {
      await this.logServiceClient?.sendLogs(context);
    }
    context.logger.clearLogs();
    return { done: false };
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/impl/UpdateRemoteConfigPhase.js
var UpdateRemoteConfigPhase = class {
  config;
  remoteConfigUpdater;
  constructor(config, remoteConfigUpdater) {
    this.config = config;
    this.remoteConfigUpdater = remoteConfigUpdater;
  }
  async execute(context) {
    if (this.remoteConfigUpdater.isUpdateRemoteConfigRequest(context)) {
      const isSuccessful = await this.remoteConfigUpdater.updateRemoteConfig(context);
      return { done: true, response: this.getUpdateConfigResponse(isSuccessful) };
    }
    return { done: false };
  }
  getUpdateConfigResponse(isSuccessful) {
    return {
      status: isSuccessful ? 200 : 400,
      body: isSuccessful ? "OK" : "Bad Request",
      headers: {}
    };
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/flow/FilterFlow.js
var FilterFlow = class extends CompositePhase {
  constructor(config, { httpClient, products, cors, telemetry, remoteConfigUpdater }) {
    const phases = [
      new FirstPartyPhase(config, httpClient, [products[ProductName.BOT_DEFENDER]]),
      new FilterPhase([products[ProductName.BOT_DEFENDER]]),
      new PreflightPhase(config, cors),
      new TelemetryPhase(telemetry)
    ];
    if (remoteConfigUpdater) {
      const updateRemoteConfigPhase = new UpdateRemoteConfigPhase(config, remoteConfigUpdater);
      phases.push(updateRemoteConfigPhase);
    }
    super(phases);
  }
};

// node_modules/perimeterx-js-core/lib/esm/phase/flow/EndEnforcerFlow.js
var EndEnforcerFlow = class extends CompositePhase {
  constructor(config, { logServiceClient }) {
    super([new SendLogsPhase(config, logServiceClient)]);
  }
};

// node_modules/perimeterx-js-core/lib/esm/telemetry/constants.js
var TELEMETRY_HEADER_NAME = "x-px-enforcer-telemetry";
var TELEMETRY_ENDPOINT = "/api/v2/risk/telemetry";
var TELEMETRY_UPDATE_REASON = "command";

// node_modules/perimeterx-js-core/lib/esm/telemetry/DefaultTelemetry.js
var DefaultTelemetry = class {
  config;
  httpClient;
  timestampHmacHeaderValidator;
  constructor(config, httpClient, base64Utils, hmacUtils) {
    this.config = config;
    this.httpClient = httpClient;
    this.timestampHmacHeaderValidator = new DefaultTimestampHmacHeaderValidator(config, config.cookieSecret, base64Utils, hmacUtils);
  }
  async isValidTelemetryRequest(context) {
    try {
      const telemetryHeader = this.getTelemetryHeader(context);
      return !!telemetryHeader && await this.isTelemetryHeaderValid(telemetryHeader, context);
    } catch (e) {
      context.logger.debug(`error validating telemetry - ${e}`);
      return false;
    }
  }
  async sendTelemetry(context) {
    try {
      await this.sendTelemetryActivity(context);
    } catch (e) {
      context.logger.debug(`error sending telemetry - ${e}`);
    }
  }
  getTelemetryHeader(context) {
    return context.requestData.request.headers.get(TELEMETRY_HEADER_NAME) || "";
  }
  async isTelemetryHeaderValid(headerValue, context) {
    context.logger.debug("received command to send enforcer telemetry");
    return this.timestampHmacHeaderValidator.isValid(headerValue, context.logger);
  }
  async sendTelemetryActivity(context) {
    const telemetryRequest = this.createTelemetryRequest(context);
    context.logger.debug(`sending telemetry to ${telemetryRequest.url}`);
    await this.httpClient.send(telemetryRequest);
  }
  createTelemetryRequest(context) {
    const url = `${this.config.backendScoreApiUrl}${TELEMETRY_ENDPOINT}`;
    const method = HttpMethod.POST;
    const headers = {
      [CONTENT_TYPE_HEADER_NAME]: [ContentType.APPLICATION_JSON],
      [AUTHORIZATION_HEADER_NAME]: [getAuthorizationHeader(this.config.authToken)]
    };
    const activity = this.createTelemetryActivity(context);
    return new OutgoingRequestImpl({ url, method, headers, body: JSON.stringify(activity) });
  }
  createTelemetryActivity(context) {
    const SENSITIVE_CONFIG_FIELDS = [
      "px_auth_token",
      "px_cookie_secret",
      "px_logger_auth_token"
    ];
    let config = this.config.toParams();
    config = removeSensitiveFields(config, SENSITIVE_CONFIG_FIELDS);
    const activity = {
      type: ActivityType.ENFORCER_TELEMETRY,
      timestamp: Date.now(),
      px_app_id: this.config.appId,
      details: {
        update_reason: TELEMETRY_UPDATE_REASON,
        module_version: this.config.moduleVersion,
        enforcer_configs: config
      }
    };
    transferExistingProperties(context.serverData, activity.details, {
      osName: "os_name",
      nodeName: "node_name"
    });
    return activity;
  }
};

// node_modules/perimeterx-js-core/lib/esm/pxde/constants.js
var PXDE_HMAC_INDEX = 0;
var PXDE_PAYLOAD_INDEX = 1;
var PXDE_COOKIE_PARTS_COUNT = 2;
var PXDE_COOKIE_DELIMITER = ":";

// node_modules/perimeterx-js-core/lib/esm/pxde/DefaultDataEnrichment.js
var DefaultDataEnrichment = class {
  config;
  base64Utils;
  hmacUtils;
  constructor(config, base64Utils, hmacUtils) {
    this.config = config;
    this.base64Utils = base64Utils;
    this.hmacUtils = hmacUtils;
  }
  async handlePxde(context) {
    try {
      const pxdeCookie = context.requestData.cookies[PXDE_COOKIE_NAME];
      if (pxdeCookie) {
        return await this.parsePxde(pxdeCookie, context);
      }
    } catch (e) {
      context.logger.debug(`unable to parse pxde cookie - ${e}`);
    }
    return null;
  }
  async parsePxde(pxdeCookie, context) {
    const pxdeParts = pxdeCookie.split(PXDE_COOKIE_DELIMITER);
    if (pxdeParts.length !== PXDE_COOKIE_PARTS_COUNT) {
      context.logger.debug(`malformed pxde cookie: ${pxdeCookie}`);
      return null;
    }
    const hmac = pxdeParts[PXDE_HMAC_INDEX];
    const encodedPayload = pxdeParts[PXDE_PAYLOAD_INDEX];
    if (!hmac || !encodedPayload) {
      context.logger.debug(`malformed pxde cookie: hmac: ${hmac}, payload: ${encodedPayload}`);
      return null;
    }
    return {
      pxde: await this.parsePxdePayload(encodedPayload, context),
      pxdeVerified: await this.verifyPxdeHmac(hmac, encodedPayload, context)
    };
  }
  async verifyPxdeHmac(givenHmac, encodedPayload, context) {
    try {
      return givenHmac === await this.hmacUtils.createHmac(Algorithm.SHA256, encodedPayload, this.config.cookieSecret);
    } catch (e) {
      context.logger.debug(`failed verifying pxde hmac: ${e}`);
      return false;
    }
  }
  async parsePxdePayload(encodedPayload, context) {
    try {
      const decodedPayload = this.base64Utils.base64Decode(encodedPayload);
      return JSON.parse(decodedPayload);
    } catch (e) {
      context.logger.debug(`failed parsing pxde payload: ${e}`);
      return null;
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/graphql/model/GraphQLOperationType.js
var GraphQLOperationType;
(function(GraphQLOperationType2) {
  GraphQLOperationType2["QUERY"] = "query";
  GraphQLOperationType2["MUTATION"] = "mutation";
  GraphQLOperationType2["SUBSCRIPTION"] = "subscription";
})(GraphQLOperationType || (GraphQLOperationType = {}));

// node_modules/perimeterx-js-core/lib/esm/graphql/DefaultGraphQLParser.js
var DefaultGraphQLParser = class {
  graphqlRoutes;
  sensitiveOperationTypes;
  sensitiveOperationNames;
  constructor(config) {
    this.graphqlRoutes = config.graphqlRoutes;
    this.sensitiveOperationNames = config.sensitiveGraphqlOperationNames;
    this.sensitiveOperationTypes = config.sensitiveGraphqlOperationTypes;
  }
  isGraphQLRequest({ requestData }) {
    return requestData.method === HttpMethod.POST && isRouteInPatterns(requestData.url.pathname, this.graphqlRoutes);
  }
  async parseGraphQLRequest(context) {
    try {
      const { requestData } = context;
      const graphQLOperations = await this.getGraphQLOperationsFromBody(requestData.request, context);
      if (!graphQLOperations) {
        context.logger.debug("unable to get graphql operations from request body");
        return null;
      }
      const data = this.parseGraphQLOperations(graphQLOperations);
      if (!data || data.length === 0) {
        context.logger.debug("unable to parse graphql operations");
        return null;
      }
      context.logger.debug(`${data.length} graphql operation${data.length === 1 ? "" : "s"} parsed successfully`);
      return data;
    } catch (e) {
      context.logger.debug(`unable to parse graphql request: ${e}`);
      return null;
    }
  }
  async getGraphQLOperationsFromBody(request, context) {
    try {
      let body = await request.json();
      if (!body) {
        return null;
      }
      return Array.isArray(body) ? body : [body];
    } catch (e) {
      context.logger.debug(`unable to parse body to json: ${e}`);
      return null;
    }
  }
  parseGraphQLOperations(operations) {
    return operations.map((operation) => this.parseGraphQlOperation(operation)).filter((x) => x);
  }
  parseGraphQlOperation(operation) {
    if (!operation.query || typeof operation.query !== "string") {
      return null;
    }
    const operationNameToTypeMap = this.getOperationNameToTypeMap(operation.query);
    if (!operationNameToTypeMap) {
      return null;
    }
    return this.getGraphQLData(operationNameToTypeMap, operation);
  }
  getOperationNameToTypeMap(query) {
    const operationTypesString = Object.values(GraphQLOperationType).join("|");
    const pattern = new RegExp(`\\s*(${operationTypesString})\\s+(\\w+)`, "gm");
    let match;
    const map = {};
    while ((match = pattern.exec(query)) !== null) {
      const operationType = match[1];
      const operationName = match[2];
      if (map[operationName]) {
        return null;
      } else {
        map[operationName] = operationType;
      }
    }
    return map;
  }
  getGraphQLData(operationNameToTypeMap, operation) {
    let name = operation.operationName || (Object.keys(operationNameToTypeMap).length === 1 ? Object.keys(operationNameToTypeMap)[0] : void 0);
    let type = operationNameToTypeMap[name];
    if (!type && /^\s*{/.test(operation.query)) {
      type = GraphQLOperationType.QUERY;
    }
    if (!type) {
      return null;
    }
    const data = { name, type };
    if (this.isSensitiveOperation(name, type)) {
      data.sensitive = true;
    }
    if (operation.variables && typeof operation.variables === "object") {
      data.variables = this.extractGraphQLVariableNames(operation.variables);
    }
    return data;
  }
  isSensitiveOperation(operationName, operationType) {
    return this.sensitiveOperationTypes.some((type) => type === operationType) || this.sensitiveOperationNames.some((name) => name === operationName);
  }
  extractGraphQLVariableNames(variables) {
    const processVariables = (variablesObj, prefix) => Object.entries(variablesObj).reduce((total, [key, value]) => {
      if (!value || typeof value !== "object" || Object.keys(value).length === 0) {
        total.push(prefix + key);
        return total;
      } else {
        return total.concat(processVariables(value, `${prefix}${key}.`));
      }
    }, []);
    return processVariables(variables, "");
  }
};

// node_modules/perimeterx-js-core/lib/esm/enforcer/utils.js
var createEnforcerInitializationBlock = (config, options) => {
  const { tokenVersion, httpClient, base64Utils, hmacUtils, hashUtils, urlUtils, ipRangeChecker } = options;
  const cipherUtils = tokenVersion === TokenVersion.V2 ? null : options.cipherUtils;
  const cors = options.cors || new DefaultCors(config);
  const telemetry = options.telemetry || new DefaultTelemetry(config, httpClient, base64Utils, hmacUtils);
  const dataEnrichment = options.dataEnrichment || new DefaultDataEnrichment(config, base64Utils, hmacUtils);
  const graphQLParser = options.graphQLParser || new DefaultGraphQLParser(config);
  const tokenParser = options.tokenParser || (tokenVersion === TokenVersion.V2 ? new DefaultTokenV2Parser(config, { base64Utils, hmacUtils }) : new DefaultTokenV3Parser(config, { cipherUtils, hmacUtils }));
  const riskApiClient = options.riskApiClient || (tokenVersion === TokenVersion.V2 ? new PostRiskApiClientV2(config, httpClient) : new PostRiskApiClientV3(config, httpClient));
  const activityClient = options.activityClient || (config.maxActivityBatchSize > 1 ? new HttpBatchedActivityClient(config, httpClient) : new HttpActivityClient(config, httpClient));
  const logServiceClient = options.logServiceClient || (config.loggerAuthToken ? new HttpLogServiceClient(config, httpClient) : null);
  const remoteConfigStorageClient = options.remoteConfigStorageClient;
  const remoteConfigServiceClient = options.remoteConfigServiceClient || (config.remoteConfigAuthToken ? new HttpRemoteConfigServiceClient(config, httpClient) : null);
  const remoteConfigUpdater = options.remoteConfigUpdater || (remoteConfigStorageClient && remoteConfigServiceClient ? new DefaultRemoteConfigUpdater(config, {
    serviceClient: remoteConfigServiceClient,
    storageClient: remoteConfigStorageClient,
    base64Utils,
    hmacUtils
  }) : null);
  const allOptions = {
    httpClient,
    base64Utils,
    hmacUtils,
    hashUtils,
    urlUtils,
    ipRangeChecker,
    cors,
    telemetry,
    dataEnrichment,
    graphQLParser,
    tokenParser,
    riskApiClient,
    activityClient,
    logServiceClient,
    remoteConfigStorageClient,
    remoteConfigServiceClient,
    remoteConfigUpdater
  };
  const products = createEnforcerProducts(config, options.products, base64Utils, hashUtils, urlUtils, ipRangeChecker);
  return { products, ...allOptions };
};
var createEnforcerProducts = (config, products, base64Utils, hashUtils, urlUtils, ipRangeChecker) => {
  const botDefender = products?.bd || new BotDefender(config, { base64Utils, ipRangeChecker, urlUtils });
  const accountDefender = products?.ad || new AccountDefender(config, { base64Utils });
  const credentialIntelligence = config.ciEnabled ? products?.ci || new CredentialIntelligence(config, { hashUtils, urlUtils }) : null;
  const hypeSaleChallenge = products?.hsc || new HypeSaleChallenge(config, { base64Utils });
  return {
    [ProductName.BOT_DEFENDER]: botDefender,
    [ProductName.ACCOUNT_DEFENDER]: accountDefender,
    [ProductName.CODE_DEFENDER]: products?.cd,
    [ProductName.CREDENTIAL_INTELLIGENCE]: credentialIntelligence,
    [ProductName.HYPE_SALE_CHALLENGE]: hypeSaleChallenge
  };
};

// node_modules/perimeterx-js-core/lib/esm/impl/cipher/CryptoCipherUtils.js
var crypto = __toESM(require("crypto"), 1);
var CryptoCipherUtils = class {
  crypto;
  constructor(cryptoModule = crypto) {
    this.crypto = cryptoModule;
  }
  async pbkdf2Decrypt(secret, encryptedString, iterations, salt, options) {
    const keylen = options?.keylen || 32;
    const ivlen = options?.ivlen || 16;
    const derivation = this.crypto.pbkdf2Sync(secret, Buffer.from(salt, "base64"), iterations, keylen + ivlen, algoToCryptoString(Algorithm.SHA256));
    const key = derivation.subarray(0, keylen);
    const iv = derivation.subarray(keylen);
    const cipher = this.crypto.createDecipheriv("aes-256-cbc", key, iv);
    let decrypted = cipher.update(encryptedString, "base64", "utf8");
    decrypted += cipher.final("utf8");
    return decrypted;
  }
};

// node_modules/perimeterx-js-core/lib/esm/impl/hmac/CryptoHmacUtils.js
var crypto2 = __toESM(require("crypto"), 1);
var CryptoHmacUtils = class {
  crypto;
  constructor(cryptoModule = crypto2) {
    this.crypto = cryptoModule;
  }
  createHmac(algo, payload, secret) {
    const hmac = this.crypto.createHmac(algoToCryptoString(algo), secret);
    hmac.setEncoding("hex");
    hmac.write(payload);
    hmac.end();
    return hmac.read();
  }
};

// node_modules/perimeterx-js-core/lib/esm/impl/hash/CryptoHashUtils.js
var crypto3 = __toESM(require("crypto"), 1);
var CryptoHashUtils = class {
  crypto;
  constructor(cryptoModule = crypto3) {
    this.crypto = cryptoModule;
  }
  async hashString(text, algo) {
    return this.crypto.createHash(algoToCryptoString(algo)).update(text).digest("hex");
  }
};

// node_modules/perimeterx-js-core/lib/esm/impl/ip_range_checker/DefaultIpRangeChecker.js
var import_ip_range_check = __toESM(require_ip_range_check(), 1);
var DefaultIpRangeChecker = class {
  isIpInRange(ip, range) {
    return (0, import_ip_range_check.default)(ip, range);
  }
};

// node_modules/perimeterx-js-core/lib/esm/impl/http/phin/PhinHttpClient.js
var import_http25 = require("http");
var import_https = require("https");
var import_phin = __toESM(require_phin(), 1);

// node_modules/perimeterx-js-core/lib/esm/impl/url/UrlSearchParamsImpl.js
var UrlSearchParamsImpl = class {
  _searchParamsArray;
  _searchParamsMap;
  urlUtils;
  constructor(urlUtils, init) {
    this.urlUtils = urlUtils;
    this._searchParamsArray = [];
    this._searchParamsMap = /* @__PURE__ */ new Map();
    if (init) {
      if (typeof init !== "object") {
        this._constructSearchParamsFromString(init);
      } else if (Array.isArray(init)) {
        this._constructSearchParamsFromArray(init);
      } else {
        this._constructSearchParamsFromObject(init);
      }
    }
  }
  append(name, value) {
    name = String(name);
    value = String(value);
    this._saveParam(name, value);
  }
  delete(name) {
    name = String(name);
    this._searchParamsMap.delete(name);
    this._searchParamsArray = this._searchParamsArray.filter((param) => param[0] !== name);
  }
  forEach(callback) {
    this._searchParamsArray.forEach((param) => {
      callback(param[1], param[0], this);
    });
  }
  get(name) {
    name = String(name);
    const value = this._searchParamsMap.get(name);
    return value ? value[0] : null;
  }
  getAll(name) {
    name = String(name);
    const value = this._searchParamsMap.get(name);
    return value ? value : [];
  }
  has(name) {
    name = String(name);
    return this._searchParamsMap.has(name);
  }
  set(name, value) {
    name = String(name);
    value = String(value);
    if (!this.has(name)) {
      this.append(name, value);
      return;
    }
    name = this.urlUtils.decodeUriComponent(name);
    value = this.urlUtils.decodeUriComponent(value);
    this._searchParamsMap.set(name, [value]);
    const searchParamIdx = this._searchParamsArray.findIndex((param) => param[0] === name);
    this._searchParamsArray[searchParamIdx][1] = value;
    this._searchParamsArray = this._searchParamsArray.filter((param, idx) => param[0] !== name || idx === searchParamIdx);
  }
  toString() {
    return this._searchParamsArray.map(([key, value]) => `${this.urlUtils.encodeUriComponent(key)}=${this.urlUtils.encodeUriComponent(value)}`).join("&");
  }
  _constructSearchParamsFromString(init) {
    let searchParams = String(init);
    if (searchParams.startsWith("?")) {
      searchParams = searchParams.slice(1);
    }
    searchParams.split("&").forEach((param) => {
      let [key, value] = param.split("=");
      if (!value) {
        value = "";
      }
      this._saveParam(key, value);
    });
  }
  _constructSearchParamsFromArray(init) {
    for (const param of init) {
      if (!Array.isArray(param || param.length !== 2)) {
        throw new Error("Failed to construct 'UrlSearchParamsImpl'");
      }
      const key = String(param[0]);
      const value = String(param[1]);
      this._saveParam(key, value);
    }
  }
  _constructSearchParamsFromObject(init) {
    if (init instanceof Set) {
      throw new Error("Failed to construct 'UrlSearchParamsImpl'");
    }
    for (const key of Object.keys(init)) {
      const value = String(init[key]);
      this._saveParam(key, value);
    }
  }
  _saveParam(key, value) {
    key = this.urlUtils.decodeUriComponent(key);
    value = this.urlUtils.decodeUriComponent(value);
    this._searchParamsArray.push([key, value]);
    this._storeParamInSearchParamsMap(key, value);
  }
  _storeParamInSearchParamsMap(key, value) {
    let values = this._searchParamsMap.get(key);
    if (!values) {
      values = [];
      this._searchParamsMap.set(key, values);
    }
    values.push(value);
  }
};

// node_modules/perimeterx-js-core/lib/esm/impl/url/CustomImplUrlUtils.js
var CustomImplUrlUtils = class {
  createUrl(rawUrl) {
    return new UrlImpl(rawUrl);
  }
  createUrlSearchParams(params) {
    return new UrlSearchParamsImpl(this, params);
  }
  decodeUriComponent(uriComponent) {
    let result = "";
    for (let i = 0; i < uriComponent.length; i++) {
      if (uriComponent.charAt(i) === "+") {
        result += " ";
        continue;
      }
      if (uriComponent.charAt(i) === "%" && uriComponent.charAt(i + 1) !== "%" && uriComponent.charAt(i + 2) !== "%") {
        const charCode = parseInt(uriComponent.charAt(i + 1) + uriComponent.charAt(i + 2), 16);
        const char = String.fromCharCode(charCode);
        result += char;
        i += 2;
        continue;
      }
      result += uriComponent.charAt(i);
    }
    return result;
  }
  encodeUriComponent(uriComponent) {
    let result = "";
    for (let i = 0; i < uriComponent.length; i++) {
      const c = uriComponent.charAt(i);
      if (this.isSafe(c)) {
        result += c;
      } else {
        result += "%" + c.charCodeAt(0).toString(16).toUpperCase();
      }
    }
    return result;
  }
  encodeUri(uri) {
    throw new EnforcerError("method not implemented: CustomImplUrlUtils.encodeUri()");
  }
  decodeUri(uri) {
    throw new EnforcerError("method not implemented: CustomImplUrlUtils.decodeUri()");
  }
  isSafe(c) {
    return c >= "a" && c <= "z" || c >= "A" && c <= "Z" || c >= "0" && c <= "9" || c == "-" || c == "_" || c == "." || c == "*" || c == "!";
  }
};

// node_modules/perimeterx-js-core/lib/esm/impl/url/UrlImpl.js
var UrlImpl = class {
  protocol;
  hostname;
  pathname;
  search;
  hash;
  username;
  password;
  _port;
  urlUtils;
  constructor(rawUrl) {
    const match = rawUrl.match(URL_REGEX);
    if (!match) {
      throw new Error(`Invalid UrlImpl: ${rawUrl}`);
    }
    this.protocol = match[1];
    this.username = match[3] || "";
    this.password = match[4] || "";
    this.hostname = match[6];
    this.port = match[7] || "";
    this.pathname = match[8] || "/";
    this.search = match[9] || "";
    this.hash = match[10] || "";
    this.urlUtils = new CustomImplUrlUtils();
  }
  get href() {
    return `${this.protocol}//${this.credentials}${this.host}${this.pathname}${this.search}${this.hash}`;
  }
  get origin() {
    return `${this.protocol}//${this.host}`;
  }
  get host() {
    return `${this.hostname}${this.port ? `:${this.port}` : ""}`;
  }
  set host(newHost) {
    const [host, port] = newHost.split(":");
    this.hostname = host;
    this.port = port;
  }
  get port() {
    return this._port;
  }
  set port(port) {
    if (port) {
      this._port = this.isDefaultPort(port) ? "" : port;
    }
  }
  get searchParams() {
    return new UrlSearchParamsImpl(this.urlUtils, this.search);
  }
  toJSON() {
    return this.href;
  }
  isDefaultPort(port) {
    const PROTOCOL_TO_DEFAULT_PORT = {
      "https:": "443",
      "http:": "80"
    };
    return PROTOCOL_TO_DEFAULT_PORT[this.protocol] === port;
  }
  get credentials() {
    if (!this.username && !this.password) {
      return "";
    }
    let credentials = "";
    if (this.username) {
      credentials += this.urlUtils.encodeUriComponent(this.username);
    }
    if (this.password) {
      credentials += `:${this.urlUtils.encodeUriComponent(this.password)}`;
    }
    return `${credentials}@`;
  }
};

// node_modules/perimeterx-js-core/lib/esm/impl/url/DefaultUrlUtils.js
var DefaultUrlUtils = class {
  createUrl(rawUrl) {
    try {
      return new URL(rawUrl);
    } catch (e) {
      return new UrlImpl(rawUrl);
    }
  }
  createUrlSearchParams(params) {
    return new URLSearchParams(params);
  }
  decodeUriComponent(uriComponent) {
    return decodeURIComponent(uriComponent);
  }
  encodeUriComponent(uriComponent) {
    return encodeURIComponent(uriComponent);
  }
  decodeUri(uri) {
    return decodeURI(uri);
  }
  encodeUri(uri) {
    return encodeURI(uri);
  }
};

// node_modules/perimeterx-js-core/lib/esm/impl/http/phin/PhinIncomingResponse.js
var PhinIncomingResponse = class {
  status;
  headers;
  body;
  constructor(response) {
    this.status = response.statusCode;
    this.body = response.body;
    this.headers = Object.fromEntries(Object.entries(response.headers).map(([key, val]) => [key, typeof val === "string" ? [val] : val]));
  }
  async formData() {
    return MultipartFormDataUtils.createFormDataWithoutFiles(await this.text(), this.headers[CONTENT_TYPE_HEADER_NAME]?.[0]);
  }
  async formUrlEncoded() {
    return new DefaultUrlUtils().createUrlSearchParams(await this.text());
  }
  async json() {
    return JSON.parse(await this.text());
  }
  async text() {
    return this.body.toString();
  }
};

// node_modules/perimeterx-js-core/lib/esm/impl/http/phin/PhinHttpClient.js
var PhinHttpClient = class {
  httpsKeepAliveAgent;
  constructor() {
    this.httpsKeepAliveAgent = new import_https.Agent({ keepAlive: true });
  }
  async send(request, options) {
    try {
      const res = await import_phin.default.promisified({
        url: request.url,
        method: request.method,
        headers: joinHeaderValues(request.headers),
        data: request.body,
        timeout: options?.timeoutMs || null,
        core: {
          agent: request.url.startsWith("https://") ? this.httpsKeepAliveAgent : new import_http25.Agent()
        }
      });
      return new PhinIncomingResponse(res);
    } catch (e) {
      const isTimeout = e.toString().toLowerCase().includes("timeout");
      throw isTimeout ? new EnforcerTimeoutError(options.timeoutMs) : e;
    }
  }
};

// node_modules/perimeterx-js-core/lib/esm/impl/base64/BufferBase64Utils.js
var BufferBase64Utils = class _BufferBase64Utils {
  static BASE_64_ENCODING = "base64";
  base64Decode(stringToDecode) {
    const buffer = Buffer.from(stringToDecode, _BufferBase64Utils.BASE_64_ENCODING);
    return buffer.toString("utf8");
  }
  base64Encode(stringToEncode) {
    const buffer = Buffer.from(stringToEncode, "utf8");
    return buffer.toString(_BufferBase64Utils.BASE_64_ENCODING);
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/phase/impl/SendAsyncActivitiesOnRequestPhase.js
var SendAsyncActivitiesOnRequestPhase = class {
  config;
  activityClient;
  constructor(activityClient, config) {
    this.config = config;
    this.activityClient = activityClient;
  }
  async execute(context) {
    if (context.action === Action.BLOCK || !this.config.deferredActivities) {
      await this.activityClient.sendActivities(context);
    }
    return { done: false };
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/phase/flow/AWSEnforceFlow.js
var AWSEnforceFlow = class extends CompositePhase {
  constructor(config, { dataEnrichment, tokenParser, riskApiClient, activityClient, cors, products, graphQLParser }) {
    super([
      //TODO: remove first party from filter flow
      new ParseTokenPhase(tokenParser),
      new EnrichContextFromRequestPhase(config, products, dataEnrichment, graphQLParser),
      new RiskApiPhase(config, products, riskApiClient),
      new AdditionalActivityHandlerPhase(config),
      new SendAsyncActivitiesOnRequestPhase(activityClient, config),
      new CreateBlockResponsePhase(config, {
        [ProductName.BOT_DEFENDER]: products[ProductName.BOT_DEFENDER],
        [ProductName.HYPE_SALE_CHALLENGE]: products[ProductName.HYPE_SALE_CHALLENGE]
      }, cors),
      new ModifyIncomingRequestPhase(Object.values(products))
    ]);
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/config/DefaultAWSAdditionalConfigurationParams.js
var DEFAULT_AWS_ADDITIONAL_CONFIGURATION_PARAMS = {
  px_deferred_activities: false,
  px_automatic_additional_s2s_activity_enabled: false
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/utils/constants.js
var CONTEXT_HEADER = "px-context";
var CLOUDFRONT_VIEWER_HTTP_VERSION_HEADER = "cloudfront-viewer-http-version";
var CLOUDFRONT_VIEWER_TLS_HEADER = "cloudfront-viewer-tls";
var AWS_REGION_ENV_VAR_NAME = "AWS_REGION";
var MODULE_VERSION = "AWS Lambda@Edge 4.1.0";

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/config/Configuration.js
var Configuration = class extends ConfigurationBase {
  constructor(params) {
    super(params, DEFAULT_AWS_ADDITIONAL_CONFIGURATION_PARAMS);
  }
  getModuleVersion() {
    return MODULE_VERSION;
  }
  get deferredActivities() {
    return this.configParams.px_deferred_activities;
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/utils/utils.js
var toCloudFrontHeaders = (headers) => {
  let headersResult = {};
  for (const [name, values] of Object.entries(headers)) {
    const valuesArray = Array.isArray(values) ? values : [values];
    headersResult[name] = valuesArray.map((value) => ({
      key: capitalizeHeaderName(name),
      value
    }));
  }
  return headersResult;
};
var createCloudFrontResponse = ({ headers, status, body }) => {
  let responseBody;
  let bodyEncoding;
  if (body instanceof Buffer) {
    responseBody = body.toString("base64");
    bodyEncoding = "base64";
  } else {
    responseBody = typeof body === "object" ? JSON.stringify(body) : body;
    bodyEncoding = "text";
  }
  return {
    status: `${status}`,
    statusDescription: "",
    headers: toCloudFrontHeaders(headers),
    bodyEncoding,
    body: responseBody
  };
};
var capitalizeHeaderName = (headerName) => {
  return headerName.replace(/(^|[\s-])\S/g, (match) => match.toUpperCase());
};
var shouldDeferActivities = (config, context) => {
  return config.deferredActivities || context.productData.ci && config.ciAutomaticAdditionalS2SEnabled;
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/context/AWSContext.js
var import_os = require("os");
var import_process = require("process");

// node_modules/perimeterx-js-core/node_modules/uuid/dist/esm-node/rng.js
var import_crypto = __toESM(require("crypto"));
var rnds8Pool = new Uint8Array(256);
var poolPtr = rnds8Pool.length;
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    import_crypto.default.randomFillSync(rnds8Pool);
    poolPtr = 0;
  }
  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}

// node_modules/perimeterx-js-core/node_modules/uuid/dist/esm-node/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];
}

// node_modules/perimeterx-js-core/node_modules/uuid/dist/esm-node/native.js
var import_crypto2 = __toESM(require("crypto"));
var native_default = {
  randomUUID: import_crypto2.default.randomUUID
};

// node_modules/perimeterx-js-core/node_modules/uuid/dist/esm-node/v4.js
function v4(options, buf, offset) {
  if (native_default.randomUUID && !buf && !options) {
    return native_default.randomUUID();
  }
  options = options || {};
  const rnds = options.random || (options.rng || rng)();
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default = v4;

// node_modules/perimeterx-js-core/lib/esm/impl/request_id_generator/UuidRequestIdGenerator.js
var UuidRequestIdGenerator = class {
  generateRequestId() {
    return v4_default();
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/http/AWSHeaders.js
var AWSHeaders = class {
  http;
  constructor(request) {
    this.http = request;
  }
  append(name, value) {
    const headerArray = this.http.headers[name.toLowerCase()];
    if (!headerArray || headerArray.length === 0) {
      this.set(name, value);
    } else {
      headerArray.push({ value });
    }
  }
  delete(name) {
    delete this.http.headers[name.toLowerCase()];
  }
  forEach(callbackfn, thisArg) {
    Object.keys(this.http.headers).forEach((key) => {
      this.http.headers[key.toLowerCase()].forEach((keyValuePair) => {
        callbackfn.call(thisArg, keyValuePair?.value, key, this);
      });
    });
  }
  get(name) {
    return this.http.headers[name.toLowerCase()]?.[0]?.value;
  }
  has(name) {
    return name in this.http.headers;
  }
  set(name, value) {
    this.http.headers[name.toLowerCase()] = [{ value }];
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/http/IncomingRequest.js
var IncomingRequest = class {
  url;
  headers;
  request;
  constructor(event) {
    this.request = event;
    const protocol = this.request.headers["x-forwarded-proto"] || "https";
    let querystring = this.request.querystring;
    let path = querystring ? this.request.uri + `?${querystring}` : this.request.uri;
    this.url = `${protocol}://${this.request.headers[HOST_HEADER_NAME]?.[0]?.value}${path}`;
    this.headers = new AWSHeaders(this.request);
  }
  get body() {
    return this.request.body?.data;
  }
  get method() {
    return this.request.method;
  }
  get clientIP() {
    return this.request.clientIp;
  }
  get httpVersion() {
    return this.headers.get(CLOUDFRONT_VIEWER_HTTP_VERSION_HEADER);
  }
  formData() {
    return MultipartFormDataUtils.createFormDataWithoutFiles(this.text(), this.headers.get(CONTENT_TYPE_HEADER_NAME));
  }
  formUrlEncoded() {
    return new URLSearchParams(this.text());
  }
  json() {
    return JSON.parse(this.text());
  }
  text() {
    if (this.request.body?.data) {
      if (this.request.body.encoding === "base64") {
        return new BufferBase64Utils().base64Decode(this.request.body.data);
      } else {
        return this.request.body.data;
      }
    }
    return null;
  }
  getUnderlyingRequest() {
    return this.request;
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/context/AWSContext.js
var AWSContext = class extends DefaultContext {
  constructor(config, request) {
    super(config, new IncomingRequest(request), {
      urlUtils: new DefaultUrlUtils(),
      requestIdGenerator: new UuidRequestIdGenerator()
    });
    this.serverData.nodeName = (0, import_os.hostname)();
    this.serverData.osName = (0, import_os.platform)();
    this.serverData.region = import_process.env[AWS_REGION_ENV_VAR_NAME];
    const tlsHeaderData = this.requestData.headers[CLOUDFRONT_VIEWER_TLS_HEADER]?.[0];
    if (tlsHeaderData) {
      const { protocol, cipher } = this.parseTlsData(tlsHeaderData);
      this.tlsData.tlsProtocol = protocol;
      this.tlsData.tlsCipher = cipher;
    }
  }
  parseTlsData(tlsHeaderData) {
    const [protocol, cipher] = tlsHeaderData.split(":");
    return { protocol: protocol?.replace("TLSv", ""), cipher };
  }
  normalizeUrl(rawUrl) {
    return super.normalizeUrl(this.urlUtils.decodeUri(rawUrl));
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/activities/EnforcerActivityClient.js
var EnforcerActivityClient = class extends HttpActivityClient {
  shouldCreatePageRequestedActivity(context) {
    return super.shouldCreatePageRequestedActivity(context) && !this.config.deferredActivities;
  }
  shouldCreateAdditionalS2SActivity() {
    return false;
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/enforcer/Enforcer.js
var Enforcer = class _Enforcer {
  config;
  filterFlow;
  enforceFlow;
  endEnforceFlow;
  constructor(config) {
    this.config = config;
    const httpClient = new PhinHttpClient();
    const initializationBlock = createEnforcerInitializationBlock(config, {
      httpClient,
      base64Utils: new BufferBase64Utils(),
      tokenVersion: TokenVersion.V3,
      cipherUtils: new CryptoCipherUtils(),
      urlUtils: new DefaultUrlUtils(),
      hmacUtils: new CryptoHmacUtils(),
      hashUtils: new CryptoHashUtils(),
      ipRangeChecker: new DefaultIpRangeChecker(),
      activityClient: new EnforcerActivityClient(config, httpClient)
    });
    this.filterFlow = new FilterFlow(config, initializationBlock);
    this.enforceFlow = new AWSEnforceFlow(config, initializationBlock);
    this.endEnforceFlow = new EndEnforcerFlow(config, initializationBlock);
  }
  static initialize(params) {
    return new _Enforcer(new Configuration(params));
  }
  async enforce(request) {
    let context;
    try {
      if (!this.config.moduleEnabled) {
        return null;
      }
      context = new AWSContext(this.config, request);
      return await this.doEnforce(context, request);
    } catch (e) {
      (context || this.config).logger.error(`caught error in enforce - ${e}`);
      return null;
    }
  }
  async doEnforce(context, request) {
    let result = await this.filterFlow.execute(context);
    if (result.done) {
      await this.endEnforceFlow.execute(context);
      return result.response ? createCloudFrontResponse(result.response) : null;
    }
    result = await this.enforceFlow.execute(context);
    if (this.shouldPreserveContext(result, context)) {
      this.preserveContext(context, request);
    }
    await this.endEnforceFlow.execute(context);
    return result.response ? createCloudFrontResponse(result.response) : null;
  }
  shouldPreserveContext(result, context) {
    if (result.response) {
      return false;
    }
    return shouldDeferActivities(this.config, context);
  }
  preserveContext(context, request) {
    request.headers[CONTEXT_HEADER] = [
      {
        key: CONTEXT_HEADER,
        value: JSON.stringify(context)
      }
    ];
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/phase/impl/SendAsyncActivitiesOnResponsePhase.js
var SendAsyncActivitiesOnResponsePhase = class {
  config;
  activityClient;
  constructor(activityClient, config) {
    this.config = config;
    this.activityClient = activityClient;
  }
  async execute(context) {
    if (shouldDeferActivities(this.config, context)) {
      await this.activityClient.sendActivities(context);
    }
    return { done: false };
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/phase/flow/AWSPostEnforceFlow.js
var AWSPostEnforceFlow = class extends CompositePhase {
  constructor(config, { products, activityClient }) {
    super([
      new EnrichContextFromResponsePhase(config, products),
      new ModifyOutgoingResponsePhase(config, Object.values(products)),
      new SendAsyncActivitiesOnResponsePhase(activityClient, config)
    ]);
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/http/OutgoingResponse.js
var OutgoingResponse = class {
  headers;
  response;
  constructor(response) {
    this.headers = new AWSHeaders(response);
    this.response = response;
  }
  get status() {
    return parseInt(this.response.status);
  }
  getUnderlyingResponse() {
    return this.response;
  }
  body() {
    return void 0;
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/activities/PostEnforcerActivityClient.js
var PostEnforcerActivityClient = class extends HttpActivityClient {
  shouldCreatePageRequestedActivity(context) {
    return super.shouldCreatePageRequestedActivity(context) && this.config.deferredActivities;
  }
  shouldCreateAdditionalS2SActivity(context) {
    return context.action === Action.PASS_REQUEST && context.productData.ci && this.config.ciAutomaticAdditionalS2SEnabled;
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/enforcer/PostEnforcer.js
var PostEnforcer = class _PostEnforcer {
  config;
  postEnforceFlow;
  endEnforceFlow;
  constructor(config) {
    const base64Utils = new BufferBase64Utils();
    const urlUtils = new DefaultUrlUtils();
    const products = createEnforcerProducts(config, {}, base64Utils, null, urlUtils, null);
    const httpClient = new PhinHttpClient();
    const activityClient = new PostEnforcerActivityClient(config, httpClient);
    const logServiceClient = new HttpLogServiceClient(config, httpClient);
    this.config = config;
    this.postEnforceFlow = new AWSPostEnforceFlow(config, { products, activityClient });
    this.endEnforceFlow = new EndEnforcerFlow(config, { logServiceClient });
  }
  static initialize(params) {
    return new _PostEnforcer(new Configuration(params));
  }
  async postEnforce(request, response) {
    let context;
    try {
      if (!this.config.moduleEnabled) {
        return;
      }
      context = this.retrieveContext(request);
      if (context) {
        context.response = new OutgoingResponse(response);
        await this.postEnforceFlow.execute(context);
        await this.endEnforceFlow.execute(context);
      }
    } catch (e) {
      (context || this.config).logger.error(`caught error in post enforce - ${e}`);
    }
  }
  retrieveContext(req) {
    const contextJson = req.headers[CONTEXT_HEADER]?.[0]?.value;
    if (!contextJson) {
      return null;
    }
    return new SerializedContext(this.config, JSON.parse(contextJson), new IncomingRequest(req), new DefaultUrlUtils());
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/createHumanEnforceHandler.js
var createHumanEnforceHandler = (config) => {
  const enforcer = Enforcer.initialize(config);
  return async function(event, context) {
    const request = event.Records[0].cf.request;
    const result = await enforcer.enforce(request);
    return result || request;
  };
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/config/FirstPartyConfiguration.js
var FirstPartyConfiguration = class extends Configuration {
  throwIfMissingRequiredField(params) {
    if (!params.px_app_id) {
      throw new EnforcerError("px_app_id cannot be empty!");
    }
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/first_party/FirstParty.js
var FirstParty = class _FirstParty {
  config;
  urlUtils;
  botDefenderFirstParty;
  sendLogsPhase;
  constructor(config) {
    this.config = config;
    this.urlUtils = new DefaultUrlUtils();
    this.botDefenderFirstParty = new DefaultBotDefenderFirstParty(config, { urlUtils: this.urlUtils });
    this.sendLogsPhase = new SendLogsPhase(config, new HttpLogServiceClient(config, new PhinHttpClient()));
  }
  static initialize(config) {
    return new _FirstParty(new FirstPartyConfiguration(config));
  }
  async handleFirstParty(req) {
    const context = new AWSContext(this.config, req);
    const retVal = await this.handleFirstPartyRequest(context);
    if (context.shouldSendLogs) {
      await this.sendLogsPhase.execute(context);
    }
    return retVal;
  }
  async handleFirstPartyRequest(context) {
    const { request, defaultResponse } = await this.botDefenderFirstParty.handleFirstPartyRequest(context);
    return request ? this.convertToRequest(request, context) : createCloudFrontResponse(defaultResponse);
  }
  convertToRequest({ body, headers, url, method }, context) {
    const firstPartyUrl = this.urlUtils.createUrl(url);
    const request = {
      uri: firstPartyUrl.pathname,
      method,
      headers: toCloudFrontHeaders(headers),
      clientIp: context.requestData.ip,
      querystring: firstPartyUrl.search,
      origin: {
        custom: {
          domainName: firstPartyUrl.host,
          port: 443,
          protocol: "https",
          sslProtocols: ["TLSv1.2"],
          path: "",
          readTimeout: 4,
          keepaliveTimeout: 5,
          customHeaders: {}
        }
      }
    };
    if (body) {
      request.body = body;
    }
    return request;
  }
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/createHumanFirstPartyHandler.js
var createHumanFirstPartyHandler = (config) => {
  const firstParty = FirstParty.initialize(config);
  return async (event, context) => {
    const request = event.Records[0].cf.request;
    return await firstParty.handleFirstParty(request);
  };
};

// node_modules/@humansecurity/aws-lambda-edge-enforcer/lib/esm/createHumanActivitiesHandler.js
var createHumanActivitiesHandler = (config) => {
  const enforcer = PostEnforcer.initialize(config);
  return async (event, context) => {
    const request = event.Records[0].cf.request;
    const response = event.Records[0].cf.response;
    await enforcer.postEnforce(request, response);
    return response;
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  HumanSecurityEnforcer,
  HumanSecurityPostEnforcer,
  createHumanActivitiesHandler,
  createHumanEnforceHandler,
  createHumanFirstPartyHandler
});
